fill ~ ~ ~ ~ ~ ~ glass_pane replace air
playsound block.glass.place block @a[distance=..8] ~ ~ ~ 1 1 0
kill @s
