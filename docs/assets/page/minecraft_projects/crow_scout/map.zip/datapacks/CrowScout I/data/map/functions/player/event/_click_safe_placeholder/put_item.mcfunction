item modify entity @s weapon.mainhand map:remove_item
execute at @e[type=interaction,tag=this.hitbox,limit=1] summon item_display run function map:player/event/_click_safe_placeholder/place
kill @e[type=interaction,tag=this.hitbox,limit=1]
scoreboard players set #Count tmp 0
execute as @e[type=item_display,tag=safe_key] run scoreboard players add #Count tmp 1
execute if score #Count tmp matches 4.. run function map:player/event/_click_safe_placeholder/unlock
playsound block.respawn_anchor.charge block @a 8 13 51 1 1 0
