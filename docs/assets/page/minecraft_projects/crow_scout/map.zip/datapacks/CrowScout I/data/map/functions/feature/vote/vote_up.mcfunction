scoreboard players reset @s vote_reset
tag @s add voted_for_reset
tellraw @a {"translate":"caption.crowscout.voted", "color":"yellow", "with":[{"selector":"@s"}]}
execute if entity @p[team=neighbor,tag=voted_for_reset] if entity @p[team=player,tag=voted_for_reset] run function lobby:setup
schedule function map:feature/vote/cancel 10s
