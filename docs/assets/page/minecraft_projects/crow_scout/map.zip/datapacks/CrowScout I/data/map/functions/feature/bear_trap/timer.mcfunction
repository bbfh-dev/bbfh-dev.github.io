scoreboard players remove @s timer 1
execute if score @s timer matches ..0 at @s run function map:feature/bear_trap/kill
execute at @s[tag=holds_player] run tp @p[team=player] ~ ~-.45 ~
