effect clear @s saturation
effect give @s hunger 30 255 true
effect give @s regeneration 30 255 true
tag @s add is_hungry

tellraw @s ["\n\n", {"translate":"task_punishment.crowscout.kitchen"}, "\n\n"]
schedule function map:feature/tasks/_punish/kitchen_end 60s replace
