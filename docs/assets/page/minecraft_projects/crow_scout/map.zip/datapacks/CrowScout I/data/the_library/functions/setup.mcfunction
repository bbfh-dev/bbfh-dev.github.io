execute unless score Mode status matches 2 run function the_library:backup_inventory

kill @e[tag=dream]
execute as @e[type=item_frame] run function the_library:setup_item
place template minecraft:variant_0/chunk_x1_z2_y0 -48 -63 000
place template minecraft:variant_0/chunk_x1_z3_y0 -48 -63 048
place template minecraft:variant_0/chunk_x2_z3_y0 000 -63 048
place template minecraft:variant_0/chunk_x2_z2_y0 000 -63 000

fill 13 -33 43 13 -32 43 air
setblock 13 -33 43 birch_door[half=lower,facing=east]
setblock 13 -32 43 birch_door[half=upper,facing=east]

# ::: Basics
kill @e[tag=crowscout,tag=dream]
gamerule doDaylightCycle false
time set night
clear @a
effect clear @a

# ::: Launch
tellraw @a[team=player] ["\n\n", {"translate":"tutorial.crowscout.the_library"}, "\n\n"]
execute as @a[team=player] positioned -11 -33 47 rotated 0 0 run function common:action/teleport_here
execute as @a[team=neighbor] positioned -11 -27 47 rotated 0 0 run function common:action/teleport_here
scoreboard players set Mode status 2
scoreboard players set WardenAI timer 0
scoreboard players set WardenChasing timer 0
scoreboard players set WardenTheme timer 0
scoreboard players set CloseBeating timer 0
scoreboard players set CloserBeating timer 0
scoreboard players set ClosestBeating timer 0
stopsound @a * crowscout:music.attack_theme_stay
stopsound @a * crowscout:music.attack_theme

effect give @a[team=neighbor] speed infinite 1 true
effect give @a[team=neighbor] jump_boost infinite 128 true
effect give @a[team=player] slowness infinite 1 true
effect give @a[team=player] jump_boost infinite 128 true
effect give @a[team=player] darkness infinite 128 true
effect give @a[team=player] glowing infinite 128 true

summon marker 11 -33 43 {Tags: ["crowscout", "dream", "ai_destination"]}
summon marker -19 -33 36 {Tags: ["crowscout", "dream", "ai_destination"]}
summon marker -4 -33 52 {Tags: ["crowscout", "dream", "ai_destination"]}
summon marker -11 -33 62 {Tags: ["crowscout", "dream", "ai_destination"]}
summon marker -27 -33 80 {Tags: ["crowscout", "dream", "ai_destination"]}
summon marker -9 -33 72 {Tags: ["crowscout", "dream", "ai_destination"]}
summon marker 8 -33 68 {Tags: ["crowscout", "dream", "ai_destination"]}

summon wandering_trader 8 -33 43 {Tags: ["crowscout", "dream", "ai"], Invulnerable: 1b, Attributes: [{Name: "minecraft:generic.movement_speed", Base: 0.5d}], ActiveEffects: [{Id: 14, Duration: -1, ShowParticles: 0b}], Silent: 1b, PersistenceRequired: 1b}
summon warden 8 -33 43 {Tags: ["crowscout", "dream"], Invulnerable: 1b, PersistenceRequired: 1b, NoAI: 1b}
playsound minecraft:entity.warden.emerge hostile @a 8 -33 43 10 1 0
team join neighbor @e[type=wandering_trader]

execute as @e[type=wandering_trader,tag=ai] at @s run function the_library:ai/select_new_location

# ::: Padlocks
scoreboard players set #PadlockID tmp 1
execute positioned 13 -33 43 rotated -90 0 run function map:load/_crowscout/place/padlock
execute positioned 13 -33 43 as @e[tag=padlock,distance=..3] run function the_library:load/_claim_padlock
scoreboard players set #PadlockID tmp 7
execute positioned -11 -33 46 rotated 0 0 run function map:load/_crowscout/place/padlock
execute positioned -11 -33 46 as @e[tag=padlock,distance=..3] run function the_library:load/_claim_padlock

# ::: Items
summon item_frame 21.50 -28.50 38.03 {Tags: ["item_placeholder", "dream"], Invisible: 1b, OnGround: 0b, Air: 300s, Invulnerable: 1b, FallDistance: 0.0f, Fixed: 0b, Motion: [0.0d, 0.0d, 0.0d], Rotation: [0.0f, 0.0f], Facing: 3b, TileZ: 38, Fire: -1s, PortalCooldown: 0, TileY: -29, TileX: 21}
summon item_frame 12.50 -30.97 37.50 {Tags: ["item_placeholder", "dream"], Invisible: 1b, OnGround: 0b, Air: 300s, Invulnerable: 1b, FallDistance: 0.0f, Fixed: 0b, Motion: [0.0d, 0.0d, 0.0d], Rotation: [0.0f, -90.0f], Facing: 1b, TileZ: 37, Fire: -1s, PortalCooldown: 0, TileY: -31, TileX: 12}
execute at @e[type=marker,tag=dream,tag=container_placeholder] run data modify block ~ ~ ~ Items set value []
execute as @e[type=item_frame,tag=dream,tag=item_placeholder] run data merge entity @s {Item: {id: ""}, Invulnerable: 1b}
function the_library:load/items
