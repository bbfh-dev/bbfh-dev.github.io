data remove entity @s interaction
data remove entity @s attack
tag @s add this.hitbox
