execute summon item_display run function call:crowscout/_setup_main_map/_place_vent/setup_model
execute summon interaction run function call:crowscout/_setup_main_map/_place_vent/setup_hitbox
