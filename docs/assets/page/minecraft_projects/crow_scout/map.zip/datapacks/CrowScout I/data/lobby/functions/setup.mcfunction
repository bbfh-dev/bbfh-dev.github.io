# ::: Basics
kill @e[type=!player]
bossbar set task visible false
tag @a remove is_hungry
tag @s remove voted_for_reset
team leave @a
effect clear @a
clear @a
advancement revoke @a everything
forceload add -96 -96 95 95
scoreboard players set Mode status 0
scoreboard players set RequiredDeaths status 20
gamerule doDaylightCycle false
time set 0t
execute as @a positioned -70 1 11 rotated -90 0 run function common:action/teleport_here
stopsound @a * crowscout:music.main_theme
stopsound @a * crowscout:music.intro_nostalgia
playsound crowscout:music.intro_nostalgia block @a -69 1 11 0.3 1 0.3

# FRONT
summon item_display -62.0 2 11 {Tags: ["crowscout", "lobby"], item: {id: "minecraft:spawner", Count: 1b, tag: {CustomModelData: 1}}, Rotation: [90f, 0f], width: 1f, height: 1f, item_display: "head", shadow_strength: 0f, brightness: {block: 15, sky: 15}}
summon text_display -62.0 1.33 12 {Tags: ["crowscout", "lobby"], text: '{"text":"by BubbleFish", "color":"dark_purple"}', Rotation: [90f, 0f], width: 1f, height: 1f, shadow: 1b, background: 0, shadow_strength: 0f, brightness: {block: 15, sky: 15}}
summon text_display -62.0 0.33 11 {Tags: ["crowscout", "lobby"], text: '["\\n", {"text":"Credits:\\n", "bold":true, "color":"white"}, {"text":"Taizaii/WhiteKnight \\u2192 ", "extra":[{"text":"[Interior Designer] ", "color":"green"}, "\\n"]}, {"text":"        TinyBuild\\u2122 \\u2192 ", "extra":[{"text":"[Inspiration/Audio]", "color":"yellow"}, "\\n"]}, {"text":"       XeKr \\u2192 ", "extra":[{"text":"[Paintings]   ", "color":"light_purple"}, "\\n"]}, {"text":"                        VanillaTweaks \\u2192 ", "extra":[{"text":"[Resourcepack Improvements]      ", "color":"gray"}, "\\n"]}]', Rotation: [90f, 0f], width: 1f, height: 1f, shadow: 1b, shadow_strength: 0f, brightness: {block: 15, sky: 15}, line_width: 800}

# LEFT
summon text_display -70 2.0 4.0 {Tags: ["crowscout", "lobby"], text: '["", {"text":"[ RULES ]", "color":"yellow", "bold":true}, "\\n", {"text":"Cheating / Bug abusing"}, {"text":" is not allowed!", "color":"red"}, "\\n", {"text":"Using any 3rd-party zoom (optifine/zoomify)"}, {"text":" is not allowed!", "color":"red"}, "\\n", {"text":"Using resourcepacks other than the map\'s one"}, {"text":" is not allowed!", "color":"red"}, "\\n", {"text":"Using gamma over 100% (night vision) "}, {"text":" is not allowed!", "color":"red"}, "\\n\\n", {"text":"[Put on volume to 50+] (Music - 0%) or [Turn on subtitles]"}, "\\n", {"text":"Play with [Entity distance] set to 100% or higher"}, "\\n", {"text":"Set render distance to 6+ chunks"}, "\\n", "Prefered to use Fabric/Forge/Vanilla because PvP clients tend to break vanilla features!", "\\n", "Neighbor MUST NEVER pickup/move player items!!", "\\n\\n", {"text":"Play with 2 players & have fun together!", "color":"light_purple"}]', Rotation: [0f, 0f], width: 1f, height: 1f, shadow: 1b, shadow_strength: 0f, brightness: {block: 15, sky: 15}, line_width: 500}

# RIGHT
summon text_display -70 1.5 19.0 {Tags: ["crowscout", "lobby"], text: '["", {"text":"[ HOW TO PLAY ]", "color":"yellow", "bold":true}, "\\n\\n", {"text":"NEIGHBOR ROLE:", "color":"red"}, "\\n", {"text":"Your goal is to prevent [Player] from getting inside of your basement marked with [EXIT] green sign!"}, "\\n\\n", {"text":"PLAYER ROLE:", "color":"green"}, "\\n", "Your goal is to get inside of the basement of [Neighbor].", "\\n\\n", {"text":"COMMON:", "color":"aqua"}, "\\n", "The items are generated randomly, allowing you to replay the map with different roles later for a different experience!\\n", {"text":"If you want to reset run: \'/trigger vote_reset\'!", "color":"yellow"}]', Rotation: [180f, 0f], width: 1f, height: 1f, shadow: 1b, shadow_strength: 0f, brightness: {block: 15, sky: 15}, line_width: 400}

# BEHIND
summon text_display -77.0 1.5 11 {Tags: ["crowscout", "lobby", "_large"], text: '["", {"text":"[ CHOOSE YOUR ROLE ]", "color":"yellow", "bold":true}]', Rotation: [-90f, 0f], width: 1f, height: 1f, shadow: 1b, shadow_strength: 0f, brightness: {block: 15, sky: 15}, line_width: 400}
summon text_display -77.0 1 9 {Tags: ["crowscout", "lobby", "_large"], text: '["", {"text":"Neighbor", "color":"red"}]', Rotation: [-90f, 0f], width: 1f, height: 1f, shadow: 1b, shadow_strength: 0f, brightness: {block: 15, sky: 15}, line_width: 400}
summon text_display -77.0 1 13 {Tags: ["crowscout", "lobby", "_large"], text: '["", {"text":"Player", "color":"green"}]', Rotation: [-90f, 0f], width: 1f, height: 1f, shadow: 1b, shadow_strength: 0f, brightness: {block: 15, sky: 15}, line_width: 400}
summon text_display -77.0 1 11 {Tags: ["crowscout", "lobby", "_large"], text: '["", {"text":"Play", "color":"gray"}]', Rotation: [-90f, 0f], width: 1f, height: 1f, shadow: 1b, shadow_strength: 0f, brightness: {block: 15, sky: 15}, line_width: 400}

execute as @e[type=text_display,tag=crowscout,tag=lobby,tag=!_large] run data merge entity @s {transformation: {scale: [0.5f, 0.5f, 0.5f]}}
summon item_frame -77.0 2.5 11.5 {Invisible: 1b, Tags: ["lobby", "crowscout"], ItemDropChance: 1.0f, Item: {id: "minecraft:horn_coral", Count: 1b, tag: {display: {Name: '[{"text":"20 Lifes", "color":"white", "italic":false, "extra":[{"text":" (Recommended)", "color":"green"}]}]'}}}, ItemRotation: 0b, OnGround: 0b, Air: 300s, Invulnerable: 1b, FallDistance: 0.0f, Fixed: 0b, Motion: [0.0d, 0.0d, 0.0d], Rotation: [270.0f, 0.0f], Facing: 5b, TileZ: 12, Fire: -1s, PortalCooldown: 0, TileY: 1, TileX: -77}
