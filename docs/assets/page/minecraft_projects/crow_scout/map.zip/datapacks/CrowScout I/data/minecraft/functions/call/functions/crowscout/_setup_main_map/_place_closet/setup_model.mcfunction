data merge entity @s {Tags: ["crowscout", "closet"], item: {id: "minecraft:spawner", Count: 1b, tag: {CustomModelData: 11}}, width: 1f, height: 2f, brightness: {sky: 15, block: 15}, item_display: "head", transformation: {translation: [0f, -1.5f, 0f]}}
tp @s ~ ~1.5 ~ ~ ~
