scoreboard players set NoVents status 0
