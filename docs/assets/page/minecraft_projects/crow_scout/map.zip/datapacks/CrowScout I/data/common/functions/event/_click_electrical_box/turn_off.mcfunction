data modify entity @e[type=item_display,tag=electrical_box,limit=1] item.tag.CustomModelData set value 10
function map:feature/power/turn_off
