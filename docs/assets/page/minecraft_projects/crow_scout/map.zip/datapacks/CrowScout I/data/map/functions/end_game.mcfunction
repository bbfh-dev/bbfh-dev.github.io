scoreboard players set Mode status -1
time set midnight
gamerule doDaylightCycle false
bossbar set task visible false
playsound crowscout:block.scary_creak master @a 0 0 0 1024 1 1
schedule function map:_end_game/_cutscene/1 30t replace
schedule function map:_end_game/_cutscene/2 60t replace
schedule function map:_end_game/_cutscene/3 90t replace
schedule function map:_end_game/_cutscene/4 120t replace
schedule function map:_end_game/_cutscene/5 150t replace
schedule function map:_end_game/_cutscene/6 180t replace
schedule function lobby:setup 250t replace
