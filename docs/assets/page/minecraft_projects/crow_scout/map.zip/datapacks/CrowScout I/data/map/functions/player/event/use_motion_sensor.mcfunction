advancement revoke @s only map:player/use_motion_sensor

scoreboard players set MotionSensorCooldown timer 5
execute anchored eyes positioned ^ ^ ^.25 run function map:player/event/_use_motion_sensor/raycast
