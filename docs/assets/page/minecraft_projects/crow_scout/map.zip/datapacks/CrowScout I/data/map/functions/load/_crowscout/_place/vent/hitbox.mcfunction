data merge entity @s {Tags: ["crowscout", "map", "vent"], width: 1f, height: 1f, response: 1b}
tp @s ^ ^ ^-.8 ~ ~
