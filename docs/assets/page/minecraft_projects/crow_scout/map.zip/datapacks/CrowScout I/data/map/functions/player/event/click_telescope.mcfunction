advancement revoke @s only map:player/click_telescope

title @s actionbar {"translate":"caption.crowscout.pincode", "with":[{"score":{"name": "Pin1", "objective": "status"}, "color":"green", "bold":true}, {"score":{"name": "Pin2", "objective": "status"}, "color":"green", "bold":true}, {"score":{"name": "Pin3", "objective": "status"}, "color":"green", "bold":true}, {"score":{"name": "Pin4", "objective": "status"}, "color":"green", "bold":true}]}
