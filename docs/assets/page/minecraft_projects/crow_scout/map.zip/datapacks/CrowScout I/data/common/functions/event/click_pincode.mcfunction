advancement revoke @s only map:common/click_pincode
function common:util/get_hitbox

execute if score Pin0 status matches 1 run scoreboard players operation Pin1 status = @e[type=interaction,tag=this.hitbox,limit=1] id
execute if score Pin0 status matches 2 run scoreboard players operation Pin2 status = @e[type=interaction,tag=this.hitbox,limit=1] id
execute if score Pin0 status matches 3 run scoreboard players operation Pin3 status = @e[type=interaction,tag=this.hitbox,limit=1] id
execute if score Pin0 status matches 4 run scoreboard players operation Pin4 status = @e[type=interaction,tag=this.hitbox,limit=1] id

execute if score Pin0 status matches ..4 run data modify entity @e[type=text_display,tag=pincode_lock,limit=1] text set value '[{"score":{"name":"Pin1", "objective":"status"}, "color":"yellow"}, " ", {"score":{"name":"Pin2", "objective":"status"}}, " ", {"score":{"name":"Pin3", "objective":"status"}}, " ", {"score":{"name":"Pin4", "objective":"status"}}]'
execute if score Pin0 status matches 4 run function common:event/_click_pincode/confirm
scoreboard players add Pin0 status 1

playsound ui.button.click block @s ~ ~ ~ 1 1 0

function common:util/end
