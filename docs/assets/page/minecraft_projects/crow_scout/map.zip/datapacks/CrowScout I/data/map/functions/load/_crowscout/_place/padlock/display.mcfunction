data merge entity @s {Tags: ["crowscout", "map", "padlock"], item: {id: "minecraft:spawner", Count: 1b, tag: {CustomModelData: 14}}, brightness: {block: 15, sky: 15}, width: 1f, height: 1f, item_display: "head"}
scoreboard players operation @s id = #PadlockID tmp
execute if score @s id matches 1 run data modify entity @s item.tag.Key set value {id: "minecraft:red_dye", tag: {display: {Name: '{"translate":"item.crowscout.red_key", "italic":false}'}}}
execute if score @s id matches 2 run data modify entity @s item.tag.Key set value {id: "minecraft:orange_dye", tag: {display: {Name: '{"translate":"item.crowscout.orange_key", "italic":false}'}}}
execute if score @s id matches 3 run data modify entity @s item.tag.Key set value {id: "minecraft:yellow_dye", tag: {display: {Name: '{"translate":"item.crowscout.yellow_key", "italic":false}'}}}
execute if score @s id matches 4 run data modify entity @s item.tag.Key set value {id: "minecraft:green_dye", tag: {display: {Name: '{"translate":"item.crowscout.green_key", "italic":false}'}}}
execute if score @s id matches 5 run data modify entity @s item.tag.Key set value {id: "minecraft:blue_dye", tag: {display: {Name: '{"translate":"item.crowscout.blue_key", "italic":false}'}}}
execute if score @s id matches 6 run data modify entity @s item.tag.Key set value {id: "minecraft:purple_dye", tag: {display: {Name: '{"translate":"item.crowscout.purple_key", "italic":false}'}}}
execute if score @s id matches 7 run data modify entity @s item.tag.Key set value {id: "minecraft:white_dye", tag: {display: {Name: '{"translate":"item.crowscout.white_key", "italic":false}'}}}
tp @s ~ ~.75 ~ ~ ~
