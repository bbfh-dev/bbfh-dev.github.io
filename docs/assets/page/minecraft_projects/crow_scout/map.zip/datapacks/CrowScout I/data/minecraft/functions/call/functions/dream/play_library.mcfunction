execute unless score Mode status matches 2 run function call:dream/_play_library/create_backup
scoreboard players set Mode status 2
tp @s -11 -33 47 0 0
effect clear @a
clear @s
kill @e[tag=crowscout,tag=crowscout_dream]
execute as @a at @s run playsound entity.horse.armor player @s ~ ~ ~ 1 1 0
execute as @a at @s run playsound block.iron_trapdoor.close block @s ~ ~ ~ 1 1 0
time set midnight
gamerule doDaylightCycle false

effect give @a blindness 1 0 true
effect give @s glowing infinite 0 true
effect give @s jump_boost infinite 128 true
effect give @s slowness infinite 2 true
effect give @a[team=neighbor] levitation infinite 127 true
effect give @a[team=neighbor] speed infinite 20 true
tp @a[team=neighbor] -11 -26.8 49

title @a subtitle {"text":"\u2b50 DREAM \u2b50", "color":"yellow", "bold":true}
title @a title {"text":"The Library", "color":"green"}

tellraw @s {"translate":"dream.crowscout.library.player", "with":[{"translate":"item.crowscout.umbrella"}, {"keybind":"key.jump"}]}

summon marker -9 -33 72 {Tags: ["crowscout", "crowscout_dream", "wandering_target"]}
summon marker -16 -33 68 {Tags: ["crowscout", "crowscout_dream", "wandering_target"]}
summon marker 0 -33 56 {Tags: ["crowscout", "crowscout_dream", "wandering_target"]}
summon marker 11 -33 43 {Tags: ["crowscout", "crowscout_dream", "wandering_target"]}
summon marker -7 -33 36 {Tags: ["crowscout", "crowscout_dream", "wandering_target"]}
summon marker -19 -33 52 {Tags: ["crowscout", "crowscout_dream", "wandering_target"]}
summon marker -11 -33 62 {Tags: ["crowscout", "crowscout_dream", "wandering_target"]}
summon marker -11 -33 62 {Tags: ["crowscout", "crowscout_dream", "wandering_target"]}
summon marker -27 -33 80 {Tags: ["crowscout", "crowscout_dream", "wandering_target"]}
summon marker -4 -33 52 {Tags: ["crowscout", "crowscout_dream", "wandering_target"]}
summon minecraft:glow_item_frame -23 -32 56 {Invisible: 1b, Item: {id: "minecraft:red_dye", Count: 1b}, Invulnerable: 0b, Rotation: [90f, 0f], Facing: 4b, Tags: ["crowscout", "crowscout_dream"]}
summon minecraft:glow_item_frame 20 -29 38 {Invisible: 1b, Item: {id: "minecraft:green_dye", Count: 1b}, Invulnerable: 0b, Rotation: [90f, 0f], Facing: 3b, Tags: ["crowscout", "crowscout_dream"]}

scoreboard players set #PadlockID block_id -2
execute positioned 13 -33 43 rotated -90 0 run function call:dream/_play_library/place_padlock
execute positioned -11 -33 46 rotated 0 0 run function call:dream/_play_library/place_padlock

summon wandering_trader 10 -33 43 {Tags: ["crowscout", "crowscout_dream", "warden_ai"], Invulnerable: 1b, Attributes: [{Name: "minecraft:generic.movement_speed", Base: 0.5d}], Silent: 1b, PersistenceRequired: 1b, ActiveEffects: [{Id: 14, Duration: -1, ShowParticles: 0b}]}
summon warden 10 -33 43 {Tags: ["crowscout", "crowscout_dream", "warden"], Invulnerable: 1b, PersistenceRequired: 1b, NoAI: 1b, Silent: 0b}
bossbar set task visible false

playsound minecraft:entity.warden.emerge hostile @a 10 -33 43 10 1 0
team join npc @e[type=wandering_trader,tag=warden_ai]
team join npc @e[type=warden,tag=warden]
function crowscout:library_dream/tick
