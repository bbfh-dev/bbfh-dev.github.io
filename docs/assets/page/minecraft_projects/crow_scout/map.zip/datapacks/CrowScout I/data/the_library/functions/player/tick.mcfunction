execute if block ~ ~ ~ light_weighted_pressure_plate run function the_library:leave
