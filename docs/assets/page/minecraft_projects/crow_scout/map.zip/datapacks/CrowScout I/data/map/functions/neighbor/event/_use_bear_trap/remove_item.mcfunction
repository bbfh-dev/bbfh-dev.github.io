scoreboard players set #Check tmp 0
execute if entity @s[nbt={SelectedItem: {id: "minecraft:ender_eye"}}] run scoreboard players set #Check tmp 1
execute if score #Check tmp matches 0 run item modify entity @s weapon.offhand map:remove_item
execute if score #Check tmp matches 1 run item modify entity @s weapon.mainhand map:remove_item
