scoreboard players set #Valid tmp 0
execute if score Pin1 status = SecretDigit1 status if score Pin2 status = SecretDigit2 status if score Pin3 status = SecretDigit3 status if score Pin4 status = SecretDigit4 status run scoreboard players set #Valid tmp 1

execute if score #Valid tmp matches 0 run function common:event/_click_pincode/invalid
execute if score #Valid tmp matches 1 run function common:event/_click_pincode/valid
