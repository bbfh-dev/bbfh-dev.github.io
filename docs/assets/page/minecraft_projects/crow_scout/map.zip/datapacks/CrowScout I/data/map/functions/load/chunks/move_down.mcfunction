execute store result score #Y tmp run data get entity @s TileY
scoreboard players remove #Y tmp 1
execute store result entity @s TileY int 1 run scoreboard players get #Y tmp
execute at @s run tp @s ~ ~-.5 ~
