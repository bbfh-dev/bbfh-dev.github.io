execute unless score Mode status matches 1.. run playsound crowscout:music.intro_nostalgia block @s -69 1 11 0.3 1 0.3
tellraw @s {"translate":"Make sure to install the resourcepack!", "color":"yellow", "bold":true}
