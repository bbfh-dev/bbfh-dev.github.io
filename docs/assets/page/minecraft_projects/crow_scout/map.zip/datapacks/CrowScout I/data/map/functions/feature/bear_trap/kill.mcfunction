particle item spawner{CustomModelData: 12} ~ ~.5 ~ 0.2 0.2 0.2 0.05 25
playsound block.chain.break block @a ~ ~ ~ 1 1 0
kill @s
