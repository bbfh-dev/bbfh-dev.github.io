execute as @e[type=marker,tag=open_doors_feature] at @s run function map:neighbor/feature/_open_doors/close_door
