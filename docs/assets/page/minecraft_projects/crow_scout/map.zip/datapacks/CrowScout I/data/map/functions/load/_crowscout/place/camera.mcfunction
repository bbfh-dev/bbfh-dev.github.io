scoreboard players add #CameraID tmp 1
execute rotated ~-45 0 summon item_display run function map:load/_crowscout/_place/camera/display
execute summon cave_spider run function map:load/_crowscout/_place/camera/spider
