summon minecraft:marker ~ ~ ~ {Tags: ["uuid"]}
execute store result score #LCG status run data get entity @e[type=marker,tag=uuid,limit=1] UUID[0]
execute store result score #UUID1 world run data get entity @e[type=marker,tag=uuid,limit=1] UUID[1]
execute store result score #UUID2 world run data get entity @e[type=marker,tag=uuid,limit=1] UUID[2]
execute store result score #UUID3 world run data get entity @e[type=marker,tag=uuid,limit=1] UUID[3]
scoreboard players operation #LCG status += #UUID1 world
scoreboard players operation #LCG status += #UUID2 world
scoreboard players operation #LCG status += #UUID3 world
kill @e[type=marker,tag=uuid]
