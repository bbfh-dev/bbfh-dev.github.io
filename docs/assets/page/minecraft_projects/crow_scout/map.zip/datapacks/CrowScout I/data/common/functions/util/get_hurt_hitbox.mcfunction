tag @s add this.player
execute positioned ^ ^1.6 ^2 as @e[type=interaction,distance=..2] if data entity @s attack run function common:util/_get_hitbox/mark_entity
