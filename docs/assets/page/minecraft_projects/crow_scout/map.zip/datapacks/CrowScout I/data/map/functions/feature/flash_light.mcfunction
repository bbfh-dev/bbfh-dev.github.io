bossbar set flash_light visible true
bossbar set flash_light players @s
scoreboard players set #Limit tmp 40
scoreboard players remove FlashBattery status 1
execute store result bossbar flash_light value run scoreboard players get FlashBattery status
function map:feature/_flash_light/loop
