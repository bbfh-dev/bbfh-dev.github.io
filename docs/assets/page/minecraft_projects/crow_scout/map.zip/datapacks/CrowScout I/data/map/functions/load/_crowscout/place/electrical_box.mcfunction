execute summon item_display run function map:load/_crowscout/_place/electrical_box/display
execute summon interaction run function map:load/_crowscout/_place/electrical_box/hitbox
