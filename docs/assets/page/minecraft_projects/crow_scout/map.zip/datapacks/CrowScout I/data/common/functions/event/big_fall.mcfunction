advancement revoke @s only map:common/big_fall

playsound crowscout:entity.fall neutral @a ~ ~ ~ 0.5 1 0
playsound entity.player.big_fall neutral @a ~ ~ ~ 1 1 0
effect give @s slowness 6 4 true
effect give @s jump_boost 6 128 true
effect give @s blindness 1 0 true
