kill @e[type=item]

fill -20 -2 39 -29 -2 49 redstone_lamp[lit=true] replace redstone_lamp[lit=false]
fill 3 24 37 0 24 46 air replace #walls
fill 2 23 46 7 29 40 air replace #walls
fill 5 28 37 5 29 38 air replace #walls
fill -23 1 26 24 34 65 waxed_exposed_cut_copper_slab replace campfire[lit=false]
fill 2 30 37 1 23 37 barrier
fill 1 30 37 1 23 45 barrier

execute as @a[team=player] positioned 0 7 -18 rotated -90 0 run function common:action/teleport_here
execute as @a[team=neighbor] positioned -21 -5 44 rotated 90 0 run function common:action/teleport_here
forceload remove -96 -96 95 95
scoreboard players set Mode status 1
playsound crowscout:music.main_theme block @a 3 8 -16 1 1 1
function map:player/update_lifes

setblock 24 1 18 dirt
setblock 14 19 39 air
setblock 13 18 39 air
gamerule playersSleepingPercentage 1
