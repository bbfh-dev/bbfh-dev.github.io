scoreboard players set #Limit tmp 12
scoreboard players set #Spawned tmp 0
function map:neighbor/event/_use_bear_trap/loop
execute if score #Spawned tmp matches 1 run function map:neighbor/event/_use_bear_trap/remove_item
