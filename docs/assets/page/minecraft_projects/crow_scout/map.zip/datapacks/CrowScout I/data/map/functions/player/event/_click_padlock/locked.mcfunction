playsound block.chest.locked block @s ~ ~ ~ 1 1 0
title @s actionbar {"translate":"caption.crowscout.door_is_locked", "with":[{"nbt":"Key.tag.display.Name", "storage":"crowscout", "interpret":true, "color":"yellow"}]}
