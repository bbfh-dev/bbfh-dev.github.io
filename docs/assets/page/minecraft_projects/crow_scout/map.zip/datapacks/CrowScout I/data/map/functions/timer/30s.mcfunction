scoreboard players set 30s timer 600

scoreboard players set #5 tmp 5
scoreboard players set ^From tmp 1
scoreboard players set ^To tmp 100
scoreboard players set #BearTraps tmp 100
execute as @e[type=interaction,tag=bear_trap,limit=19] run scoreboard players remove #BearTraps tmp 5
execute store result score #BearTrapCount tmp run clear @p[team=neighbor] ender_eye{CustomModelData: 1} 0
scoreboard players operation #BearTrapCount tmp *= #5 tmp
scoreboard players operation #BearTraps tmp -= #BearTrapCount tmp
function common:random/get_random_range
execute if score Random tmp <= #BearTraps tmp run give @a[team=neighbor] ender_eye{CustomModelData: 1, display: {Name: '{"translate":"block.crowscout.bear_trap", "italic":false}'}}
