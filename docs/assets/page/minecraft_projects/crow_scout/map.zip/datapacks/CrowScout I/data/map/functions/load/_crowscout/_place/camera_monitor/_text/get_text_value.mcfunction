execute store result score #Y tmp run data get entity @s Pos[1]

execute if score #Y tmp matches ..6 run scoreboard players set #Floor tmp 1
execute if score #Y tmp matches 7..11 run scoreboard players set #Floor tmp 2
execute if score #Y tmp matches 12..16 run scoreboard players set #Floor tmp 3
execute if score #Y tmp matches 17..21 run scoreboard players set #Floor tmp 4
execute if score #Y tmp matches 22.. run scoreboard players set #Floor tmp 5
