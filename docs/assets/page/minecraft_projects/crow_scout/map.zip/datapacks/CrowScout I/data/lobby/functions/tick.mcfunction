execute positioned -77 0 13 if block ~ ~ ~ minecraft:oak_button[powered=true] as @p run function lobby:feature/player_button/click
execute positioned -77 0 11 if block ~ ~ ~ minecraft:oak_button[powered=true] as @p run function lobby:feature/play_button/click
execute positioned -77 0 9 if block ~ ~ ~ minecraft:oak_button[powered=true] as @p run function lobby:feature/neighbor_button/click
execute as @a[scores={leave_game=1..}] at @s run playsound crowscout:music.intro_nostalgia block @s -69 1 11 0.3 1 0.3
tellraw @a[scores={leave_game=1..}] {"translate":"Make sure to install the resourcepack!", "color":"yellow", "bold":true}
gamemode adventure @a
