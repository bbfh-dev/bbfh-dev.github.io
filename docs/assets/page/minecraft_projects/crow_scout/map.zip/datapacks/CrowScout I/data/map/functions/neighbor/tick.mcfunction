bossbar set task players @a[team=neighbor]
tag @s remove inside_of_a_window
execute if score @s sneak_time matches 1.. run function map:neighbor/while_sneaking
execute rotated ~ 0 run function map:neighbor/feature/open_doors
execute positioned ~ ~1 ~ if entity @e[type=item_display,tag=pincode_lock,distance=..2] run title @s actionbar {"translate":"caption.crowscout.pincode", "with":[{"score":{"name": "SecretDigit1", "objective": "status"}, "color":"green", "bold":true}, {"score":{"name": "SecretDigit2", "objective": "status"}, "color":"green", "bold":true}, {"score":{"name": "SecretDigit3", "objective": "status"}, "color":"green", "bold":true}, {"score":{"name": "SecretDigit4", "objective": "status"}, "color":"green", "bold":true}]}
