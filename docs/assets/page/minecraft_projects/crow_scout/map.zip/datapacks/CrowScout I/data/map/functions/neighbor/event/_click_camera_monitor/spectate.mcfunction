execute summon marker run function map:neighbor/event/_click_camera_monitor/setup_return_marker
gamemode spectator @p[tag=this.player]
spectate @s @p[tag=this.player]
