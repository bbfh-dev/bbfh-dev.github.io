data modify entity @e[type=item_display,tag=electrical_box,limit=1] item.tag.CustomModelData set value 9
function map:feature/power/turn_on
