tag @s remove voted_for_reset
