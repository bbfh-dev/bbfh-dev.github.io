bossbar set task name {"translate":"task.crowscout.storage"}
scoreboard players set Task status 5
scoreboard players set Time tmp 1800

summon item_display -6 7 50 {Tags: ["crowscout", "map", "task"], item: {id: "minecraft:fire_charge", Count: 1b}, billboard: "center", Glowing: 1b}
