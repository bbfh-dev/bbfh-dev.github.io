data merge entity @s {Tags: ["crowscout", "map", "padlock"], width: 1.01f, height: 2f, response: 1b}
scoreboard players operation @s id = #PadlockID tmp
tp @s ~ ~ ~ ~ ~
