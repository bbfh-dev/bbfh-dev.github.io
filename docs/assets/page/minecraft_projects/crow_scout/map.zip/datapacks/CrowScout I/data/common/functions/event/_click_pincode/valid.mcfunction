data modify entity @e[type=text_display,tag=pincode_lock,limit=1] text set value '[{"score":{"name":"Pin1", "objective":"status"}, "color":"green"}, " ", {"score":{"name":"Pin2", "objective":"status"}}, " ", {"score":{"name":"Pin3", "objective":"status"}}, " ", {"score":{"name":"Pin4", "objective":"status"}}]'
setblock -6 8 46 redstone_block
schedule function common:event/_click_pincode/reset 5s replace
