bossbar set task name {"translate":"task.crowscout.power_outage"}
scoreboard players set Task status 2
scoreboard players set Time tmp 2400

summon item_display 10.5 19.0 57.5 {Tags: ["crowscout", "map", "task"], item: {id: "minecraft:fire_charge", Count: 1b}, billboard: "center", Glowing: 1b}
