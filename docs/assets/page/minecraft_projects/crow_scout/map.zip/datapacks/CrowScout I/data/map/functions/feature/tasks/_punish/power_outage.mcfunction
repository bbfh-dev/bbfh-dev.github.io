scoreboard players set PowerOutage status 1
function map:feature/power/turn_off

tellraw @s ["\n\n", {"translate":"task_punishment.crowscout.power_outage"}, "\n\n"]
schedule function map:feature/tasks/_punish/power_outage_end 60s replace
