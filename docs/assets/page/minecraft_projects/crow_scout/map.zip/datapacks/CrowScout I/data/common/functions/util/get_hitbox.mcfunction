tag @s add this.player
execute positioned ^ ^1.6 ^2 as @e[type=interaction,distance=..3] if data entity @s interaction run function common:util/_get_hitbox/mark_entity
