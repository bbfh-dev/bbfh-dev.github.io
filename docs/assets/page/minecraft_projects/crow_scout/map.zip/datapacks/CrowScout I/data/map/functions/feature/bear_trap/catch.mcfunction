effect give @s blindness 1 0 true
effect give @s slowness 7 25 true
effect give @s jump_boost 7 128 true
effect give @s glowing 3 0 true
tag @e[type=item_display,tag=bear_trap,distance=..1,limit=1] add holds_player
execute as @e[type=interaction,tag=bear_trap,distance=...5,limit=1] at @s run function map:feature/bear_trap/close
