scoreboard players set Mode status 1
kill @e[tag=crowscout,tag=crowscout_dream]
effect clear @a
clear @a
gamerule doDaylightCycle true
schedule clear crowscout:library_dream/tick
bossbar set task visible true
