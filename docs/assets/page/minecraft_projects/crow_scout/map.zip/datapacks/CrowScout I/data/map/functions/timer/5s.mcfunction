scoreboard players set 5s timer 100

# ::: Broken cameras
execute at @e[type=item_display,tag=is_broken] run particle lava ~ ~ ~ 0.2 0.2 0.2 1 5 normal @a
