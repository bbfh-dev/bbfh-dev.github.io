execute unless block ^ ^ ^.5 #map:air if block ~ ~ ~ #minecraft:air run function map:feature/_flash_light/place

scoreboard players remove #Limit tmp 1
execute unless score #Limit tmp matches 1.. if block ~ ~ ~ #minecraft:air run function map:feature/_flash_light/place
execute if score #Limit tmp matches 1.. positioned ^ ^ ^.5 run function map:feature/_flash_light/loop
