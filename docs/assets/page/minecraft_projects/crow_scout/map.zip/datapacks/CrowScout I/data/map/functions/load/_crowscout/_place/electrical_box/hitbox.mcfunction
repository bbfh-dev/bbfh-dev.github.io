data merge entity @s {Tags: ["crowscout", "map", "electrical_box"], width: 0.6f, height: 0.8f, response: 1b}
tp @s ^ ^-.5 ^-.6 ~ ~
