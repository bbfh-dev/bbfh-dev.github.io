tellraw @s ["\n\n", {"translate":"task_punishment.crowscout.graveyard"}, "\n\n"]
scoreboard players set ^From tmp 1
scoreboard players set ^To tmp 5
function common:random/get_random_range

execute if score Random tmp matches 1 run function map:feature/tasks/_punish/kitchen
execute if score Random tmp matches 2 run function map:feature/tasks/_punish/power_outage
execute if score Random tmp matches 3 run function map:feature/tasks/_punish/sleep
execute if score Random tmp matches 4 run function map:feature/tasks/_punish/refresh_water
execute if score Random tmp matches 5 run function map:feature/tasks/_punish/storage
