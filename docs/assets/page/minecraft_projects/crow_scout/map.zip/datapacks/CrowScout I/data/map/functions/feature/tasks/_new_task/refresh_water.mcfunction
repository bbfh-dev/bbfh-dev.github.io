bossbar set task name {"translate":"task.crowscout.refresh_water"}
scoreboard players set Task status 4
scoreboard players set Time tmp 1600

summon item_display -14 22 30 {Tags: ["crowscout", "map", "task"], item: {id: "minecraft:fire_charge", Count: 1b}, billboard: "center", Glowing: 1b}
