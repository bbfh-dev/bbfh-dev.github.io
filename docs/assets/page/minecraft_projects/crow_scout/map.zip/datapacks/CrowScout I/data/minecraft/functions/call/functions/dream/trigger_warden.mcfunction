data modify entity @e[tag=warden_ai,limit=1] WanderTarget.X set from entity @s Pos[0]
data modify entity @e[tag=warden_ai,limit=1] WanderTarget.Y set from entity @s Pos[1]
data modify entity @e[tag=warden_ai,limit=1] WanderTarget.Z set from entity @s Pos[2]
