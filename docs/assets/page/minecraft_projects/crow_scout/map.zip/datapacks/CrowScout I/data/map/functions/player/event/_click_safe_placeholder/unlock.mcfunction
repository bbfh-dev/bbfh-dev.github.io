kill @e[tag=safe]
kill @e[tag=safe_key]
fill 9 12 51 7 14 51 air replace barrier
playsound entity.generic.explode block @a 8 13 51 1 1 0
playsound entity.zombie.break_wooden_door block @a 8 13 51 1 1 0
particle item spawner{CustomModelData: 15} 8 13 51 0.6 0.6 0 0.2 50
particle ash 8 13 51 0.6 0.6 0 0.2 20
particle explosion_emitter 8 13 51 0.6 0.6 0 0.2 1
