data merge entity @s {Tags: ["crowscout", "camera_monitor"], item: {id: "minecraft:spawner", Count: 1b, tag: {CustomModelData: 7}}, transformation: {translation: [0f, 0.5f, 0f]}, width: 1.0f, height: 1.0f}
scoreboard players operation @s block_id = #MonitorID block_id
tp @s ~ ~ ~ ~180 ~
