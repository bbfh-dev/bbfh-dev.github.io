bossbar set crowscout value 0
bossbar set crowscout max 1
bossbar set crowscout name "Saving the map..."
kill @e[tag=crowscout]

setblock -96 -56 -96 structure_block[mode=save]{name: "minecraft:crowscout/main_map/chunk_x0_z0_under", ignoreEntities: 0b, mode: "SAVE", posX: 0, posY: 1, posZ: 0, powered: 0b, showboundingbox: 0b, sizeX: 48, sizeY: 48, sizeZ: 48}
setblock -48 -56 -96 structure_block[mode=save]{name: "minecraft:crowscout/main_map/chunk_x1_z0_under", ignoreEntities: 0b, mode: "SAVE", posX: 0, posY: 1, posZ: 0, powered: 0b, showboundingbox: 0b, sizeX: 48, sizeY: 48, sizeZ: 48}
setblock 000 -56 -96 structure_block[mode=save]{name: "minecraft:crowscout/main_map/chunk_x2_z_under", ignoreEntities: 0b, mode: "SAVE", posX: 0, posY: 1, posZ: 0, powered: 0b, showboundingbox: 0b, sizeX: 48, sizeY: 48, sizeZ: 48}
setblock 048 -56 -96 structure_block[mode=save]{name: "minecraft:crowscout/main_map/chunk_x3_z0_under", ignoreEntities: 0b, mode: "SAVE", posX: 0, posY: 1, posZ: 0, powered: 0b, showboundingbox: 0b, sizeX: 48, sizeY: 48, sizeZ: 48}

setblock -96 -56 -48 structure_block[mode=save]{name: "minecraft:crowscout/main_map/chunk_x0_z1_under", ignoreEntities: 0b, mode: "SAVE", posX: 0, posY: 1, posZ: 0, powered: 0b, showboundingbox: 0b, sizeX: 48, sizeY: 48, sizeZ: 48}
setblock -48 -56 -48 structure_block[mode=save]{name: "minecraft:crowscout/main_map/chunk_x1_z1_under", ignoreEntities: 0b, mode: "SAVE", posX: 0, posY: 1, posZ: 0, powered: 0b, showboundingbox: 0b, sizeX: 48, sizeY: 48, sizeZ: 48}
setblock 000 -56 -48 structure_block[mode=save]{name: "minecraft:crowscout/main_map/chunk_x2_z1_under", ignoreEntities: 0b, mode: "SAVE", posX: 0, posY: 1, posZ: 0, powered: 0b, showboundingbox: 0b, sizeX: 48, sizeY: 48, sizeZ: 48}
setblock 048 -56 -48 structure_block[mode=save]{name: "minecraft:crowscout/main_map/chunk_x3_z1_under", ignoreEntities: 0b, mode: "SAVE", posX: 0, posY: 1, posZ: 0, powered: 0b, showboundingbox: 0b, sizeX: 48, sizeY: 48, sizeZ: 48}

setblock -96 -56 000 structure_block[mode=save]{name: "minecraft:crowscout/main_map/chunk_x0_z2_under", ignoreEntities: 0b, mode: "SAVE", posX: 0, posY: 1, posZ: 0, powered: 0b, showboundingbox: 0b, sizeX: 48, sizeY: 48, sizeZ: 48}
setblock -48 -56 000 structure_block[mode=save]{name: "minecraft:crowscout/main_map/chunk_x1_z2_under", ignoreEntities: 0b, mode: "SAVE", posX: 0, posY: 1, posZ: 0, powered: 0b, showboundingbox: 0b, sizeX: 48, sizeY: 48, sizeZ: 48}
setblock 000 -56 000 structure_block[mode=save]{name: "minecraft:crowscout/main_map/chunk_x2_z2_under", ignoreEntities: 0b, mode: "SAVE", posX: 0, posY: 1, posZ: 0, powered: 0b, showboundingbox: 0b, sizeX: 48, sizeY: 48, sizeZ: 48}
setblock 048 -56 000 structure_block[mode=save]{name: "minecraft:crowscout/main_map/chunk_x3_z2_under", ignoreEntities: 0b, mode: "SAVE", posX: 0, posY: 1, posZ: 0, powered: 0b, showboundingbox: 0b, sizeX: 48, sizeY: 48, sizeZ: 48}

setblock -96 -56 048 structure_block[mode=save]{name: "minecraft:crowscout/main_map/chunk_x0_z3_under", ignoreEntities: 0b, mode: "SAVE", posX: 0, posY: 1, posZ: 0, powered: 0b, showboundingbox: 0b, sizeX: 48, sizeY: 48, sizeZ: 48}
setblock -48 -56 048 structure_block[mode=save]{name: "minecraft:crowscout/main_map/chunk_x1_z3_under", ignoreEntities: 0b, mode: "SAVE", posX: 0, posY: 1, posZ: 0, powered: 0b, showboundingbox: 0b, sizeX: 48, sizeY: 48, sizeZ: 48}
setblock 000 -56 048 structure_block[mode=save]{name: "minecraft:crowscout/main_map/chunk_x2_z3_under", ignoreEntities: 0b, mode: "SAVE", posX: 0, posY: 1, posZ: 0, powered: 0b, showboundingbox: 0b, sizeX: 48, sizeY: 48, sizeZ: 48}
setblock 048 -56 048 structure_block[mode=save]{name: "minecraft:crowscout/main_map/chunk_x3_z3_under", ignoreEntities: 0b, mode: "SAVE", posX: 0, posY: 1, posZ: 0, powered: 0b, showboundingbox: 0b, sizeX: 48, sizeY: 48, sizeZ: 48}


setblock -96 -8 -96 structure_block[mode=save]{name: "minecraft:crowscout/main_map/chunk_x0_z0", ignoreEntities: 0b, mode: "SAVE", posX: 0, posY: 1, posZ: 0, powered: 0b, showboundingbox: 0b, sizeX: 48, sizeY: 48, sizeZ: 48}
setblock -48 -8 -96 structure_block[mode=save]{name: "minecraft:crowscout/main_map/chunk_x1_z0", ignoreEntities: 0b, mode: "SAVE", posX: 0, posY: 1, posZ: 0, powered: 0b, showboundingbox: 0b, sizeX: 48, sizeY: 48, sizeZ: 48}
setblock 000 -8 -96 structure_block[mode=save]{name: "minecraft:crowscout/main_map/chunk_x2_z0", ignoreEntities: 0b, mode: "SAVE", posX: 0, posY: 1, posZ: 0, powered: 0b, showboundingbox: 0b, sizeX: 48, sizeY: 48, sizeZ: 48}
setblock 048 -8 -96 structure_block[mode=save]{name: "minecraft:crowscout/main_map/chunk_x3_z0", ignoreEntities: 0b, mode: "SAVE", posX: 0, posY: 1, posZ: 0, powered: 0b, showboundingbox: 0b, sizeX: 48, sizeY: 48, sizeZ: 48}

setblock -96 -8 -48 structure_block[mode=save]{name: "minecraft:crowscout/main_map/chunk_x0_z1", ignoreEntities: 0b, mode: "SAVE", posX: 0, posY: 1, posZ: 0, powered: 0b, showboundingbox: 0b, sizeX: 48, sizeY: 48, sizeZ: 48}
setblock -48 -8 -48 structure_block[mode=save]{name: "minecraft:crowscout/main_map/chunk_x1_z1", ignoreEntities: 0b, mode: "SAVE", posX: 0, posY: 1, posZ: 0, powered: 0b, showboundingbox: 0b, sizeX: 48, sizeY: 48, sizeZ: 48}
setblock 000 -8 -48 structure_block[mode=save]{name: "minecraft:crowscout/main_map/chunk_x2_z1", ignoreEntities: 0b, mode: "SAVE", posX: 0, posY: 1, posZ: 0, powered: 0b, showboundingbox: 0b, sizeX: 48, sizeY: 48, sizeZ: 48}
setblock 048 -8 -48 structure_block[mode=save]{name: "minecraft:crowscout/main_map/chunk_x3_z1", ignoreEntities: 0b, mode: "SAVE", posX: 0, posY: 1, posZ: 0, powered: 0b, showboundingbox: 0b, sizeX: 48, sizeY: 48, sizeZ: 48}

setblock -96 -8 000 structure_block[mode=save]{name: "minecraft:crowscout/main_map/chunk_x0_z2", ignoreEntities: 0b, mode: "SAVE", posX: 0, posY: 1, posZ: 0, powered: 0b, showboundingbox: 0b, sizeX: 48, sizeY: 48, sizeZ: 48}
setblock -48 -8 000 structure_block[mode=save]{name: "minecraft:crowscout/main_map/chunk_x1_z2", ignoreEntities: 0b, mode: "SAVE", posX: 0, posY: 1, posZ: 0, powered: 0b, showboundingbox: 0b, sizeX: 48, sizeY: 48, sizeZ: 48}
setblock 000 -8 000 structure_block[mode=save]{name: "minecraft:crowscout/main_map/chunk_x2_z2", ignoreEntities: 0b, mode: "SAVE", posX: 0, posY: 1, posZ: 0, powered: 0b, showboundingbox: 0b, sizeX: 48, sizeY: 48, sizeZ: 48}
setblock 048 -8 000 structure_block[mode=save]{name: "minecraft:crowscout/main_map/chunk_x3_z2", ignoreEntities: 0b, mode: "SAVE", posX: 0, posY: 1, posZ: 0, powered: 0b, showboundingbox: 0b, sizeX: 48, sizeY: 48, sizeZ: 48}

setblock -96 -8 048 structure_block[mode=save]{name: "minecraft:crowscout/main_map/chunk_x0_z3", ignoreEntities: 0b, mode: "SAVE", posX: 0, posY: 1, posZ: 0, powered: 0b, showboundingbox: 0b, sizeX: 48, sizeY: 48, sizeZ: 48}
setblock -48 -8 048 structure_block[mode=save]{name: "minecraft:crowscout/main_map/chunk_x1_z3", ignoreEntities: 0b, mode: "SAVE", posX: 0, posY: 1, posZ: 0, powered: 0b, showboundingbox: 0b, sizeX: 48, sizeY: 48, sizeZ: 48}
setblock 000 -8 048 structure_block[mode=save]{name: "minecraft:crowscout/main_map/chunk_x2_z3", ignoreEntities: 0b, mode: "SAVE", posX: 0, posY: 1, posZ: 0, powered: 0b, showboundingbox: 0b, sizeX: 48, sizeY: 48, sizeZ: 48}
setblock 048 -8 048 structure_block[mode=save]{name: "minecraft:crowscout/main_map/chunk_x3_z3", ignoreEntities: 0b, mode: "SAVE", posX: 0, posY: 1, posZ: 0, powered: 0b, showboundingbox: 0b, sizeX: 48, sizeY: 48, sizeZ: 48}

bossbar set crowscout value 1

bossbar set crowscout visible false
tellraw @a ["", {"nbt":"Logger", "storage":"crowscout", "interpret": true}, "The map was saved!"]
forceload remove all
