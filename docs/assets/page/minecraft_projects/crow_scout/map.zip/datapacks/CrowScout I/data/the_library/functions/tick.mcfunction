execute as @p[team=player] at @s run function the_library:player/tick
execute as @e[type=wandering_trader,tag=ai] at @s run function the_library:ai/tick
execute as @e[type=item_frame] unless data entity @s Item.id run data modify entity @s Invulnerable set value 1b
