data modify entity @e[type=text_display,tag=pincode_lock,limit=1] text set value '[{"score":{"name":"Pin1", "objective":"status"}, "color":"red"}, " ", {"score":{"name":"Pin2", "objective":"status"}}, " ", {"score":{"name":"Pin3", "objective":"status"}}, " ", {"score":{"name":"Pin4", "objective":"status"}}]'
playsound block.anvil.place block @a ~ ~ ~ 0.2 1 0
schedule function common:event/_click_pincode/reset 1s replace
