advancement revoke @s only map:neighbor/click_camera_monitor
function common:util/get_hitbox

execute as @e[type=cave_spider,tag=camera_view] if score @s id = @e[type=interaction,tag=this.hitbox,limit=1] id run function map:neighbor/event/_click_camera_monitor/attempt_to_spectate

function common:util/end
