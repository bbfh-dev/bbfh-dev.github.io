data merge entity @s {Tags: ["crowscout", "map", "pincode_lock"], width: 1.0f, height: 1.0f, text: '{"text":"0 0 0 0", "color":"gray"}', transformation: {scale: [0.75f, 0.75f, 0.75f]}, background: 0, line_width: 70, shadow: 1b}
tp @s ~ ~ ~ ~ ~
