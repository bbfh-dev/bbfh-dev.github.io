advancement revoke @s only map:neighbor/task/gravehard

function map:feature/tasks/complete_task
