bossbar set task name {"translate":"task.crowscout.completed", "color":"green"}
bossbar set task color green
playsound entity.player.levelup master @s ~ ~ ~ 1 1 1
scoreboard players set Task status 0
kill @e[type=item_display,tag=task]
