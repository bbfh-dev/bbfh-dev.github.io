data merge entity @s {Tags: ["crowscout", "map", "electrical_box"], item: {id: "minecraft:spawner", Count: 1b, tag: {CustomModelData: 9}}, width: 1f, height: 1f, item_display: "head"}
tp @s ~ ~ ~ ~ ~
