schedule function minecraft:loop/garbage_collection 10s replace

scoreboard players reset * tmp
