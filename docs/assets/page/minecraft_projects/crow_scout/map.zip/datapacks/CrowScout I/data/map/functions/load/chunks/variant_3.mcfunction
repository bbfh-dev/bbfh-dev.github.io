place template minecraft:variant_3/chunk_x1_z1_y1 -48 -15 -48
place template minecraft:variant_3/chunk_x1_z2_y1 -48 -15 000
place template minecraft:variant_3/chunk_x1_z3_y1 -48 -15 048
place template minecraft:variant_3/chunk_x2_z1_y1 000 -15 -48
place template minecraft:variant_3/chunk_x2_z2_y1 000 -15 000
place template minecraft:variant_3/chunk_x2_z3_y1 000 -15 048
