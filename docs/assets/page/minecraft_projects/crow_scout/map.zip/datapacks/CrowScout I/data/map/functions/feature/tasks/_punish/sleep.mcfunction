effect give @s darkness 30 0 true

tellraw @s ["\n\n", {"translate":"task_punishment.crowscout.sleep"}, "\n\n"]
