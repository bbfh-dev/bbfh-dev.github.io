tag @a remove is_hungry
