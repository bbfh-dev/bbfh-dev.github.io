scoreboard players add #MonitorID block_id 1
execute summon item_display run function call:crowscout/_setup_main_map/_place_monitor/setup_model
execute summon interaction run function call:crowscout/_setup_main_map/_place_monitor/setup_hitbox
execute summon text_display run function call:crowscout/_setup_main_map/_place_monitor/setup_text
