data modify entity @s PickupDelay set value 0
tag @s add marked
execute if entity @s[nbt={Item: {id: "minecraft:item_frame"}}] run kill @s
