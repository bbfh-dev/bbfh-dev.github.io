playsound minecraft:block.anvil.place block @p[tag=this.player] ~ ~ ~ 0.2 1 0
title @p[tag=this.player] actionbar {"translate":"options.narrator.notavailable", "color":"red"}
