tp @p[team=player] -9 -2 80 facing entity @p[team=neighbor] eyes
tp @p[team=neighbor] -11 1 78 facing entity @p[team=player] feet
effect give @a darkness 60 0 true
clear @a
effect clear @a
