execute if block ~ ~ ~ #map:doors[half=lower] if block ~ ~-1 ~ #map:floor run function map:neighbor/feature/_open_doors/iteration
execute positioned ^ ^ ^1 if block ~ ~ ~ #map:doors[half=lower] if block ~ ~-1 ~ #map:floor run function map:neighbor/feature/_open_doors/iteration
execute positioned ^ ^ ^2 if block ~ ~ ~ #map:doors[half=lower] if block ~ ~-1 ~ #map:floor run function map:neighbor/feature/_open_doors/iteration
