scoreboard players add BreakingWindow timer 1
execute if score BreakingWindow timer matches 1..4 run function map:feature/_break_window/progress
execute if score BreakingWindow timer matches 5.. run function map:feature/_break_window/break
