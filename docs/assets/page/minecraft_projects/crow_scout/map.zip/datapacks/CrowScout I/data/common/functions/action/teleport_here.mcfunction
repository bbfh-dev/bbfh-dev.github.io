effect give @s blindness 1 0 true
execute at @s run particle cloud ~ ~1 ~ 0.2 0.4 0.2 0.01 20 normal @a
execute at @s run playsound entity.enderman.teleport player @a[distance=..8] ~ ~ ~ 0.5 1 0
tp @s ~ ~ ~ ~ ~
execute at @s run playsound entity.horse.armor player @s ~ ~ ~ 1 1 0
execute at @s run playsound block.iron_trapdoor.close block @s ~ ~ ~ 1 1 0
