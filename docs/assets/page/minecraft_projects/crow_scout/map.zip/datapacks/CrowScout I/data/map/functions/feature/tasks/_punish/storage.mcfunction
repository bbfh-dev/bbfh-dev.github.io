fill -20 -5 44 -20 -3 44 iron_bars
execute positioned -21 -5 44 rotated 90 0 run function common:action/teleport_here

tellraw @s ["\n\n", {"translate":"task_punishment.crowscout.sleep"}, "\n\n"]
schedule function map:feature/tasks/_punish/storage_end 30s
