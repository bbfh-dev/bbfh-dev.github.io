playsound crowscout:block.detector block @a[team=player] ~ ~ ~ 1024 1 1
playsound crowscout:block.detector block @a[team=neighbor,distance=..8] ~ ~ ~ 1024 1 1
scoreboard players set SensorCooldown timer 100
title @a[team=player] actionbar {"translate":"caption.crowscout.motion_sensor", "color":"yellow"}
