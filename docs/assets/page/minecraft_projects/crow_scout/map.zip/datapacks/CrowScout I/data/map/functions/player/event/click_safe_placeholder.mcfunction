advancement revoke @s only map:player/click_safe_placeholder
function common:util/get_hitbox

execute if entity @s[nbt={SelectedItem: {id: "minecraft:spawner", tag: {CustomModelData: 16}}}] run function map:player/event/_click_safe_placeholder/put_item

function common:util/end
