playsound block.wooden_door.close block @s ~ ~ ~ 1 1 0
title @s actionbar {"translate":"caption.crowscout.closet_error", "color":"red"}
