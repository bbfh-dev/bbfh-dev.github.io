advancement revoke @s only map:neighbor/use_bear_trap

scoreboard players set BearTrapCooldown timer 10
execute anchored eyes positioned ^ ^ ^.25 run function map:neighbor/event/_use_bear_trap/raycast
