execute as @s[gamemode=spectator] run function map:neighbor/event/_click_camera_monitor/leave
execute as @s[gamemode=adventure] if block ~ ~ ~ glass_pane if block ~ ~1 ~ glass_pane run tag @s add inside_of_a_window
