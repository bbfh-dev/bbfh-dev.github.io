scoreboard players set #PIN_KeyID tmp -1
setblock ~ ~ ~ target
execute summon item_display run function map:load/_crowscout/_place/pincode_lock/display
execute positioned ^-.334 ^0.2175 ^ summon interaction run function map:load/_crowscout/_place/pincode_lock/key
execute positioned ^-.172 ^0.2175 ^ summon interaction run function map:load/_crowscout/_place/pincode_lock/key
execute positioned ^-.015 ^0.2175 ^ summon interaction run function map:load/_crowscout/_place/pincode_lock/key
execute positioned ^00.14 ^0.2175 ^ summon interaction run function map:load/_crowscout/_place/pincode_lock/key
execute positioned ^000.3 ^0.2175 ^ summon interaction run function map:load/_crowscout/_place/pincode_lock/key
execute positioned ^-.334 ^000000 ^ summon interaction run function map:load/_crowscout/_place/pincode_lock/key
execute positioned ^-.172 ^000000 ^ summon interaction run function map:load/_crowscout/_place/pincode_lock/key
execute positioned ^-.015 ^000000 ^ summon interaction run function map:load/_crowscout/_place/pincode_lock/key
execute positioned ^00.14 ^000000 ^ summon interaction run function map:load/_crowscout/_place/pincode_lock/key
execute positioned ^000.3 ^000000 ^ summon interaction run function map:load/_crowscout/_place/pincode_lock/key
execute positioned ^ ^0.63 ^.51 summon text_display run function map:load/_crowscout/_place/pincode_lock/text
