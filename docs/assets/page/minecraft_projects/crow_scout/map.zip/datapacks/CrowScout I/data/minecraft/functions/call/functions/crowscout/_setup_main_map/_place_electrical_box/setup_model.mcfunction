data merge entity @s {Tags: ["crowscout", "electrical_box"], item: {id: "minecraft:spawner", Count: 1b, tag: {CustomModelData: 9}}, transformation: {translation: [0f, 0.5f, 0f]}, width: 1.0f, height: 1.0f}
tp @s ~ ~ ~ ~180 ~
