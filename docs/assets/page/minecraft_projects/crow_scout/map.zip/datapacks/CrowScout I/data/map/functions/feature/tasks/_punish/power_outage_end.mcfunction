scoreboard players set PowerOutage status 0
function common:event/_click_electrical_box/turn_on
