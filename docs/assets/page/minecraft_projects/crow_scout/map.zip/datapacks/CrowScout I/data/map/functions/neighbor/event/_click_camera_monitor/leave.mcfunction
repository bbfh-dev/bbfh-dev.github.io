execute at @e[type=marker,tag=neighbor_return_marker] run tp @s ~ ~ ~ ~ ~
kill @e[type=marker,tag=neighbor_return_marker]
gamemode adventure @s
