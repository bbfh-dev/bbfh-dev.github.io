advancement revoke @s only map:player/hit_bear_trap
function common:util/get_hurt_hitbox

execute as @e[tag=this.hitbox] at @s run function map:feature/bear_trap/close

function common:util/end
