fill ~ ~ ~ ~ ~1 ~ air replace glass_pane
summon marker ~ ~ ~ {Tags: ["crowscout", "map", "broken_glass"]}
summon marker ~ ~1 ~ {Tags: ["crowscout", "map", "broken_glass"]}
particle block glass_pane ~ ~.5 ~ 0.2 0.4 0.2 1 10 normal @a
playsound block.glass.break block @a ~ ~ ~ 1 1 0
