advancement revoke @s only lobby:change_lifes

execute store result score #ItemRotation tmp run data get entity @e[type=item_frame,tag=lobby,limit=1] ItemRotation

execute if score #ItemRotation tmp matches 0 run data modify entity @e[type=item_frame,tag=lobby,limit=1] Item.tag.display.Name set value '[{"text":"20 Lifes", "color":"white", "italic":false, "extra":[{"text":" (Recommended)", "color":"green"}]}]'
execute if score #ItemRotation tmp matches 1 run data modify entity @e[type=item_frame,tag=lobby,limit=1] Item.tag.display.Name set value '[{"text":"25 Lifes", "color":"white", "italic":false}]'
execute if score #ItemRotation tmp matches 2 run data modify entity @e[type=item_frame,tag=lobby,limit=1] Item.tag.display.Name set value '[{"text":"30 Lifes", "color":"white", "italic":false}]'
execute if score #ItemRotation tmp matches 3 run data modify entity @e[type=item_frame,tag=lobby,limit=1] Item.tag.display.Name set value '[{"text":"\\u221e Lifes", "color":"white", "italic":false}]'
execute if score #ItemRotation tmp matches 4 run data modify entity @e[type=item_frame,tag=lobby,limit=1] Item.tag.display.Name set value '[{"text":"15 Lifes", "color":"white", "italic":false}]'
execute if score #ItemRotation tmp matches 5 run data modify entity @e[type=item_frame,tag=lobby,limit=1] Item.tag.display.Name set value '[{"text":"10 Lifes", "color":"white", "italic":false}]'
execute if score #ItemRotation tmp matches 6 run data modify entity @e[type=item_frame,tag=lobby,limit=1] Item.tag.display.Name set value '[{"text":"5 Lifes", "color":"white", "italic":false}]'
execute if score #ItemRotation tmp matches 7 run data modify entity @e[type=item_frame,tag=lobby,limit=1] Item.tag.display.Name set value '[{"text":"1 Life", "color":"white", "italic":false}]'

execute if score #ItemRotation tmp matches 0 run scoreboard players set RequiredDeaths status 20
execute if score #ItemRotation tmp matches 1 run scoreboard players set RequiredDeaths status 25
execute if score #ItemRotation tmp matches 2 run scoreboard players set RequiredDeaths status 30
execute if score #ItemRotation tmp matches 3 run scoreboard players set RequiredDeaths status 2147483647
execute if score #ItemRotation tmp matches 4 run scoreboard players set RequiredDeaths status 15
execute if score #ItemRotation tmp matches 5 run scoreboard players set RequiredDeaths status 10
execute if score #ItemRotation tmp matches 6 run scoreboard players set RequiredDeaths status 5
execute if score #ItemRotation tmp matches 7 run scoreboard players set RequiredDeaths status 1
