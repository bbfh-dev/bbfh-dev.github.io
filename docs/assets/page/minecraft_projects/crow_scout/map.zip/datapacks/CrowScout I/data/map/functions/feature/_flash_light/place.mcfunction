setblock ~ ~ ~ light[level=15]
summon marker ~ ~ ~ {Tags: ["light"]}
scoreboard players set #Limit tmp 0
