data merge entity @s {Tags: ["crowscout", "map", "camera"], item: {id: "minecraft:spawner", Count: 1b, tag: {CustomModelData: 2}}, transformation: {translation: [0f, 0.5f, 0f]}, width: 1.0f, height: 1.0f, item_display: "head"}
scoreboard players operation @s id = #CameraID tmp
tp @s ~ ~ ~ ~ ~
