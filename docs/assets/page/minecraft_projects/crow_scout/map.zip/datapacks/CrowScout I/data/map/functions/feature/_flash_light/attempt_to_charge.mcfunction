execute store success score #Clear tmp run clear @s bone_meal 1
execute if score #Clear tmp matches 0 run title @s actionbar {"translate":"caption.crowscout.flashlight_recharge", "color":"red"}
execute if score #Clear tmp matches 1 run scoreboard players set FlashBattery status 180

