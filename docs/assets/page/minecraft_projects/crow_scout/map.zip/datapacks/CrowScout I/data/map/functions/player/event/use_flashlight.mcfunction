advancement revoke @s only map:player/use_flashlight

scoreboard players set FlashlightCooldown timer 10

scoreboard players add FlashOn status 1
execute if score FlashOn status matches 2.. run scoreboard players set FlashOn status 0

execute if score FlashOn status matches 0 run function map:player/event/_use_flashlight/turn_off
execute if score FlashOn status matches 1 run function map:player/event/_use_flashlight/turn_on
playsound ui.button.click master @s ~ ~ ~ 1 1 0
