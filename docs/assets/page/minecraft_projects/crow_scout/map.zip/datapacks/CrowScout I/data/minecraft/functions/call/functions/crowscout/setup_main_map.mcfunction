kill @e[tag=crowscout]
scoreboard players set #CameraID block_id 0
scoreboard players set #MonitorID block_id 0
scoreboard players set #PadlockID block_id 0

# ::: Cameras
execute positioned -6 5 50 rotated 135 25 run function call:crowscout/_setup_main_map/place_camera
execute positioned -9 6 32 rotated -135 25 run function call:crowscout/_setup_main_map/place_camera
execute positioned 15 10 52 rotated 45 25 run function call:crowscout/_setup_main_map/place_camera
execute positioned -12 10 47 rotated -45 25 run function call:crowscout/_setup_main_map/place_camera
execute positioned 13 15 40 rotated 45 25 run function call:crowscout/_setup_main_map/place_camera
execute positioned 5 20 34 rotated 135 25 run function call:crowscout/_setup_main_map/place_camera
execute positioned 1 20 46 rotated 45 25 run function call:crowscout/_setup_main_map/place_camera
execute positioned 18 20 50 rotated 135 25 run function call:crowscout/_setup_main_map/place_camera
execute positioned -6 24 44 rotated 135 25 run function call:crowscout/_setup_main_map/place_camera
execute positioned 18 26 61 rotated 135 25 run function call:crowscout/_setup_main_map/place_camera

# ::: Camera monitors
execute positioned -28 -3 46 rotated -90 0 run function call:crowscout/_setup_main_map/place_monitor
execute positioned -28 -3 45 rotated -90 0 run function call:crowscout/_setup_main_map/place_monitor
execute positioned -28 -3 44 rotated -90 0 run function call:crowscout/_setup_main_map/place_monitor
execute positioned -28 -3 43 rotated -90 0 run function call:crowscout/_setup_main_map/place_monitor
execute positioned -28 -3 42 rotated -90 0 run function call:crowscout/_setup_main_map/place_monitor
execute positioned -28 -4 46 rotated -90 0 run function call:crowscout/_setup_main_map/place_monitor
execute positioned -28 -4 45 rotated -90 0 run function call:crowscout/_setup_main_map/place_monitor
execute positioned -28 -4 44 rotated -90 0 run function call:crowscout/_setup_main_map/place_monitor
execute positioned -28 -4 43 rotated -90 0 run function call:crowscout/_setup_main_map/place_monitor
execute positioned -28 -4 42 rotated -90 0 run function call:crowscout/_setup_main_map/place_monitor

# ::: Electrical box
execute positioned 11 19 57 rotated -90 0 run function call:crowscout/_setup_main_map/place_electrical_box

# ::: Closets
execute positioned -11 2 39 rotated 180 0 run function call:crowscout/_setup_main_map/place_closet
execute positioned 7 2 -18 rotated 90 0 run function call:crowscout/_setup_main_map/place_closet
execute positioned -2 7 -14 rotated -90 0 run function call:crowscout/_setup_main_map/place_closet
execute positioned 0 2 40 rotated 180 0 run function call:crowscout/_setup_main_map/place_closet

# ::: Vents
execute positioned -8 10 38 rotated 90 0 run function call:crowscout/_setup_main_map/place_vent

# ::: Door padlocks
execute positioned 1 2 45 rotated -90 0 run function call:crowscout/_setup_main_map/place_padlock
execute positioned 1 2 46 rotated -90 0 run function call:crowscout/_setup_main_map/place_dublicate_padlock
execute positioned -4 1 53 rotated 0 0 run function call:crowscout/_setup_main_map/place_padlock
execute positioned -12 2 44 rotated -90 0 run function call:crowscout/_setup_main_map/place_padlock

# ::: Dream triggers
summon marker -11 7 46 {Tags: ["crowscout", "dream_trigger", "library_dream"]}

# ::: The library riddle
summon item_frame 8.03 24.50 49.50 {Tags: ["crowscout", "the_library_riddle", "part_red"], Invisible: 1b, Item: {id: "minecraft:red_candle", Count: 1b, tag: {display: {Name: '{"translate":"block.minecraft.red_candle"}'}}}, ItemRotation: 0b, Invulnerable: 1b, Fixed: 0b, Rotation: [270.0f, 0.0f], Facing: 5b, TileZ: 49, TileY: 24, TileX: 8}
summon item_frame 8.03 24.50 48.50 {Tags: ["crowscout", "the_library_riddle", "part_yellow"], Invisible: 1b, Item: {id: "minecraft:yellow_candle", Count: 1b, tag: {display: {Name: '{"translate":"block.minecraft.yellow_candle"}'}}}, ItemRotation: 0b, Invulnerable: 1b, Fixed: 0b, Rotation: [270.0f, 0.0f], Facing: 5b, TileZ: 48, TileY: 24, TileX: 8}
summon item_frame 8.03 24.50 47.50 {Tags: ["crowscout", "the_library_riddle", "part_green"], Invisible: 1b, Item: {id: "minecraft:lime_candle", Count: 1b, tag: {display: {Name: '{"translate":"block.minecraft.green_candle"}'}}}, ItemRotation: 0b, Invulnerable: 1b, Fixed: 0b, Rotation: [270.0f, 0.0f], Facing: 5b, TileZ: 47, TileY: 24, TileX: 8}
summon item_frame 8.03 23.50 49.50 {Tags: ["crowscout", "the_library_riddle", "part_blue"], Invisible: 1b, Item: {id: "minecraft:light_blue_candle", Count: 1b, tag: {display: {Name: '{"translate":"block.minecraft.blue_candle"}'}}}, ItemRotation: 0b, Invulnerable: 1b, Fixed: 0b, Rotation: [270.0f, 0.0f], Facing: 5b, TileZ: 49, TileY: 23, TileX: 8}
summon item_frame 8.03 23.50 47.50 {Tags: ["crowscout", "the_library_riddle", "part_purple"], Invisible: 1b, Item: {id: "minecraft:purple_candle", Count: 1b, tag: {display: {Name: '{"translate":"block.minecraft.purple_candle"}'}}}, ItemRotation: 0b, Invulnerable: 1b, Fixed: 0b, Rotation: [270.0f, 0.0f], Facing: 5b, TileZ: 47, TileY: 23, TileX: 8}
summon item_frame 8.03 22.50 49.50 {Tags: ["crowscout", "the_library_riddle", "part_black"], Invisible: 1b, Item: {id: "minecraft:black_candle", Count: 1b, tag: {display: {Name: '{"translate":"block.minecraft.black_candle"}'}}}, ItemRotation: 0b, Invulnerable: 1b, Fixed: 0b, Rotation: [270.0f, 0.0f], Facing: 5b, TileZ: 49, TileY: 22, TileX: 8}
summon item_frame 8.03 22.50 48.50 {Tags: ["crowscout", "the_library_riddle", "part_gray"], Invisible: 1b, Item: {id: "minecraft:gray_candle", Count: 1b, tag: {display: {Name: '{"translate":"block.minecraft.gray_candle"}'}}}, ItemRotation: 0b, Invulnerable: 1b, Fixed: 0b, Rotation: [270.0f, 0.0f], Facing: 5b, TileZ: 48, TileY: 22, TileX: 8}
summon item_frame 8.03 22.50 47.50 {Tags: ["crowscout", "the_library_riddle", "part_pink"], Invisible: 1b, Item: {id: "minecraft:pink_candle", Count: 1b, tag: {display: {Name: '{"translate":"block.minecraft.pink_candle"}'}}}, ItemRotation: 0b, Invulnerable: 1b, Fixed: 0b, Rotation: [270.0f, 0.0f], Facing: 5b, TileZ: 47, TileY: 22, TileX: 8}
summon item_frame 8.03 23.50 48.50 {Tags: ["crowscout", "the_library_riddle"], Invisible: 1b, ItemDropChance: 1.0f, Item: {id: "minecraft:book", Count: 1b}, ItemRotation: 0b, Invulnerable: 1b, Fixed: 1b, Rotation: [270.0f, 0.0f], Facing: 5b, TileZ: 48, TileY: 23, TileX: 8}
fill 7 22 49 7 24 47 white_concrete_powder
fill -11 7 46 -11 8 46 bookshelf replace air
