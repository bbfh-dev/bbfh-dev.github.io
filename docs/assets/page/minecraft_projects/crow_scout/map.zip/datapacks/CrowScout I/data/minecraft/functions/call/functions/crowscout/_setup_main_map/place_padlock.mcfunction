scoreboard players add #PadlockID block_id 1
function call:crowscout/_setup_main_map/place_dublicate_padlock
