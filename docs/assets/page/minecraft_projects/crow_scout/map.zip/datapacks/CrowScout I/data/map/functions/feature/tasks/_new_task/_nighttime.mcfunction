summon marker 0 0 0 {Tags: ["random_task", "task_sleep"]}
summon marker 0 0 0 {Tags: ["random_task", "task_sleep"]}
summon marker 0 0 0 {Tags: ["random_task", "task_sleep"]}
summon marker 0 0 0 {Tags: ["random_task", "task_sleep"]}
summon marker 0 0 0 {Tags: ["random_task", "task_kitchen"]}
summon marker 0 0 0 {Tags: ["random_task", "task_power_outage"]}
summon marker 0 0 0 {Tags: ["random_task", "task_graveyard"]}
summon marker 0 0 0 {Tags: ["random_task", "task_refresh_water"]}
execute as @e[type=marker,tag=random_task,limit=1,sort=random] run function map:feature/tasks/_new_task/_ngihttime_task
