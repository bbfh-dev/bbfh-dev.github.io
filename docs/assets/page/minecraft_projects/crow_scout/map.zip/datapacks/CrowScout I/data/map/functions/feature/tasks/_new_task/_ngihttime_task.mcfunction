execute as @s[tag=task_sleep] run function map:feature/tasks/_new_task/sleep
execute as @s[tag=task_kitchen] run function map:feature/tasks/_new_task/kitchen
execute as @s[tag=task_power_outage] run function map:feature/tasks/_new_task/power_outage
execute as @s[tag=task_graveyard] run function map:feature/tasks/_new_task/graveyard
execute as @s[tag=task_refresh_water] run function map:feature/tasks/_new_task/refresh_water
