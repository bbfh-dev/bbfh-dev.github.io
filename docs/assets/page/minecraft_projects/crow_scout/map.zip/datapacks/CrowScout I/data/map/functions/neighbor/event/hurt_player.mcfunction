advancement revoke @s only map:neighbor/hurt_player

tag @e remove holds_player
execute as @a[team=player] positioned 0 7 -18 rotated -90 0 run function common:action/teleport_here
playsound crowscout:entity.catch master @a ~ ~ ~ 1024 1 1
title @a[team=player] title "-1 \u2764"
scoreboard players remove Lifes status 1
function map:player/update_lifes
execute if score Lifes status matches ..0 run function map:end_game
