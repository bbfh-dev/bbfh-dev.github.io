setblock ~ ~ ~ oak_button[facing=east,powered=false,face=wall] replace
team join player @s
tellraw @a {"translate":"caption.crowscout.now_playing_as", "with":[{"selector":"@s"}, {"translate":"Player", "color":"green"}]}
