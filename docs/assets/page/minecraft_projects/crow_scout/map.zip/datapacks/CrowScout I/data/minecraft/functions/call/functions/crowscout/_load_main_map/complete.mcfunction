bossbar set crowscout value 0
bossbar set crowscout max 8
bossbar set crowscout name "Loading the map..."
kill @e[type=!player]

place template minecraft:crowscout/main_map/chunk_x0_z0_under -96 -55 -96
place template minecraft:crowscout/main_map/chunk_x1_z0_under -48 -55 -96
place template minecraft:crowscout/main_map/chunk_x2_z0_under 000 -55 -96
place template minecraft:crowscout/main_map/chunk_x3_z0_under 048 -55 -96
bossbar set crowscout value 1

place template minecraft:crowscout/main_map/chunk_x0_z1_under -96 -55 -48
place template minecraft:crowscout/main_map/chunk_x1_z1_under -48 -55 -48
place template minecraft:crowscout/main_map/chunk_x2_z1_under 000 -55 -48
place template minecraft:crowscout/main_map/chunk_x3_z1_under 048 -55 -48
bossbar set crowscout value 2

place template minecraft:crowscout/main_map/chunk_x0_z2_under -96 -55 000
place template minecraft:crowscout/main_map/chunk_x1_z2_under -48 -55 000
place template minecraft:crowscout/main_map/chunk_x2_z2_under 000 -55 000
place template minecraft:crowscout/main_map/chunk_x3_z2_under 048 -55 000
bossbar set crowscout value 3

place template minecraft:crowscout/main_map/chunk_x0_z3_under -96 -55 048
place template minecraft:crowscout/main_map/chunk_x1_z3_under -48 -55 048
place template minecraft:crowscout/main_map/chunk_x2_z3_under 000 -55 048
place template minecraft:crowscout/main_map/chunk_x3_z3_under 048 -55 048
bossbar set crowscout value 4

place template minecraft:crowscout/main_map/chunk_x0_z0 -96 -7 -96
place template minecraft:crowscout/main_map/chunk_x1_z0 -48 -7 -96
place template minecraft:crowscout/main_map/chunk_x2_z0 000 -7 -96
place template minecraft:crowscout/main_map/chunk_x3_z0 048 -7 -96
bossbar set crowscout value 5

place template minecraft:crowscout/main_map/chunk_x0_z1 -96 -7 -48
place template minecraft:crowscout/main_map/chunk_x1_z1 -48 -7 -48
place template minecraft:crowscout/main_map/chunk_x2_z1 000 -7 -48
place template minecraft:crowscout/main_map/chunk_x3_z1 048 -7 -48
bossbar set crowscout value 6

place template minecraft:crowscout/main_map/chunk_x0_z2 -96 -7 000
place template minecraft:crowscout/main_map/chunk_x1_z2 -48 -7 000
place template minecraft:crowscout/main_map/chunk_x2_z2 000 -7 000
place template minecraft:crowscout/main_map/chunk_x3_z2 048 -7 000
bossbar set crowscout value 7

place template minecraft:crowscout/main_map/chunk_x0_z3 -96 -7 048
place template minecraft:crowscout/main_map/chunk_x1_z3 -48 -7 048
place template minecraft:crowscout/main_map/chunk_x2_z3 000 -7 048
place template minecraft:crowscout/main_map/chunk_x3_z3 048 -7 048
bossbar set crowscout value 8
bossbar set crowscout visible false

bossbar set crowscout name "Setting up the map"
function call:crowscout/setup_main_map

tellraw @a ["", {"nbt":"Logger", "storage":"crowscout", "interpret": true}, "The map was loaded!"]
forceload remove all
