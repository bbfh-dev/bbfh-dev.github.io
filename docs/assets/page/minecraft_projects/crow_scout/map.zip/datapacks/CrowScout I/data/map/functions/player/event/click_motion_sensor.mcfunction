advancement revoke @s only map:player/click_motion_sensor
function common:util/get_hitbox

kill @e[tag=motion_sensor]
give @s ender_eye{CustomModelData: 3, display: {Name: '{"translate":"block.crowscout.motion_sensor", "italic":false}'}}
playsound ui.stonecutter.take_result block @a ~ ~ ~ 1 1 0

function common:util/end
