data merge entity @s {Tags: ["crowscout", "vent"], width: 1f, height: 1f, response: 1b}
tp @s ~ ~ ~ ~ ~
tp @s ^ ^ ^-0.875
