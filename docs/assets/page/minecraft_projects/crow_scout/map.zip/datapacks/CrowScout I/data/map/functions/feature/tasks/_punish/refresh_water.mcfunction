scoreboard players set NoVents status 1

tellraw @s ["\n\n", {"translate":"task_punishment.crowscout.refresh_water"}, "\n\n"]
schedule function map:feature/tasks/_punish/refresh_water_end 60s replace
