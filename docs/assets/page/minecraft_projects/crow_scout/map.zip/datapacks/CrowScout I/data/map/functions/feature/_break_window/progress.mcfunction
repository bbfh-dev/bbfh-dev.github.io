playsound block.glass.break block @a[distance=..8] ~ ~ ~ 1 1 0
execute align xyz run particle block glass_pane ~.5 ~1.5 ~.5 0.2 0.4 0.2 1 40 normal @a
