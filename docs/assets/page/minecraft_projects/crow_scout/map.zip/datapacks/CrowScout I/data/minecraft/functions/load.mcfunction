setworldspawn -70 1 11 -90
gamerule maxCommandChainLength 65535

# ::: Scoreboards
scoreboard objectives add status dummy
scoreboard objectives add timer dummy
scoreboard objectives add tmp dummy
scoreboard objectives add id dummy
scoreboard objectives add vote_reset trigger "Vote for Reset"
scoreboard objectives add sneak_time minecraft.custom:minecraft.sneak_time
scoreboard objectives add leave_game minecraft.custom:minecraft.leave_game

# ::: Teams
team add player {"translate":"Player"}
team modify player color green
team modify player seeFriendlyInvisibles false
team modify player nametagVisibility never
team modify player collisionRule never
team modify player prefix "[\u263b] "

team add neighbor {"translate":"Neighbor"}
team modify neighbor color red
team modify neighbor seeFriendlyInvisibles false
team modify neighbor nametagVisibility never
team modify neighbor collisionRule never
team modify neighbor prefix "[\u2620] "

# ::: Bossbar
bossbar add task "Task"
bossbar set task style progress
bossbar add flash_light {"translate":"caption.crowscout.flashlight_charge"}
bossbar set flash_light style progress
bossbar set flash_light max 1800
bossbar set flash_light color yellow

# ::: First launch
execute unless score Mode status matches 1.. unless score Mode status matches -1 run function lobby:setup

# ::: Garbage collection
schedule function minecraft:loop/garbage_collection 10s replace
