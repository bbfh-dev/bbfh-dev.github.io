data merge entity @s {Tags: ["crowscout", "crowscout_dream", "padlock"], width: 1.01f, height: 2f, response: 1b}
scoreboard players operation @s block_id = #PadlockID block_id
tp @s ~ ~ ~ ~ ~
