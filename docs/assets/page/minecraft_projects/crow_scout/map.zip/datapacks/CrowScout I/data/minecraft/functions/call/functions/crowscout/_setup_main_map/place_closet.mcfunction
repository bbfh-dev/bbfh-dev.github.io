fill ~ ~ ~ ~ ~1 ~ tinted_glass
execute summon item_display run function call:crowscout/_setup_main_map/_place_closet/setup_model
execute summon interaction run function call:crowscout/_setup_main_map/_place_closet/setup_hitbox
