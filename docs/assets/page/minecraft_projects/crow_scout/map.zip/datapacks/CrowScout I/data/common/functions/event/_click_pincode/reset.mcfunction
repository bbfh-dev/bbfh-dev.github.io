scoreboard players set Pin0 status 1
scoreboard players set Pin1 status 0
scoreboard players set Pin2 status 0
scoreboard players set Pin3 status 0
scoreboard players set Pin4 status 0
data modify entity @e[type=text_display,tag=pincode_lock,limit=1] text set value '[{"score":{"name":"Pin1", "objective":"status"}, "color":"gray"}, " ", {"score":{"name":"Pin2", "objective":"status"}}, " ", {"score":{"name":"Pin3", "objective":"status"}}, " ", {"score":{"name":"Pin4", "objective":"status"}}]'
setblock -6 8 46 target
