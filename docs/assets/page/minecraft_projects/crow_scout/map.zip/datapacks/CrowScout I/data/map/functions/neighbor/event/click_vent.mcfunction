advancement revoke @s only map:neighbor/click_vent
function common:util/get_hitbox

execute unless score NoVents status matches 1 positioned -21 -5 44 rotated 90 0 run function common:action/teleport_here

function common:util/end
