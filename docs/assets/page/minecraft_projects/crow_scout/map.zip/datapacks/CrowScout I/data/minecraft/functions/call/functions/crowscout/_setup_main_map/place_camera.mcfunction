scoreboard players add #CameraID block_id 1
execute rotated ~-45 0 summon item_display run function call:crowscout/_setup_main_map/_place_camera/setup_model
execute summon cave_spider run function call:crowscout/_setup_main_map/_place_camera/setup_lens
