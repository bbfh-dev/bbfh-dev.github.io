setblock ~ ~ ~ terracotta
kill @s
