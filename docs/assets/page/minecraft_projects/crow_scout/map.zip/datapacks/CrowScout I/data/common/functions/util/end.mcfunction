tag @e remove this.hitbox
tag @s remove this.player
