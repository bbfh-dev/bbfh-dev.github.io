tag @e remove placeholder
tag @e[tag=dream,tag=item_placeholder] add placeholder
tag @e[tag=dream,tag=container_placeholder] add placeholder

# ::: White key
scoreboard players set ^From tmp 1
scoreboard players set ^To tmp 100
function common:random/get_random_range
execute if score Random tmp matches 1..50 positioned 21 -29 38 run loot replace entity @e[type=item_frame,distance=..2,sort=nearest,limit=1] container.0 loot the_library:item/white_key
execute if score Random tmp matches 1..50 positioned 21 -29 38 run data modify entity @e[type=item_frame,distance=..2,sort=nearest,limit=1] Invulnerable set value 0b
execute if score Random tmp matches 51..100 positioned 12 -31 37 run loot replace entity @e[type=item_frame,distance=..2,sort=nearest,limit=1] container.0 loot the_library:item/white_key
execute if score Random tmp matches 51..100 positioned 12 -31 37 run data modify entity @e[type=item_frame,distance=..2,sort=nearest,limit=1] Invulnerable set value 0b
 
# ::: Red key
execute as @e[tag=placeholder,limit=1,sort=random] at @s run function the_library:load/_items/place_red_key
