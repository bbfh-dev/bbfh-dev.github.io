execute if entity @e[type=marker,tag=dream_point,tag=the_library,distance=...5] run function the_library:setup
execute if entity @e[type=marker,tag=dream_point,tag=the_end,distance=...5] run function the_end:setup
