advancement revoke @s only map:player/click_closet
function common:util/get_hitbox

execute unless entity @e[type=item_display,tag=holds_player] unless score AttackCooldown timer matches 60.. at @e[type=interaction,tag=this.hitbox] as @e[type=item_display,tag=closet,distance=..2,sort=nearest,limit=1] run function map:player/event/_click_closet/hide
execute if score AttackCooldown timer matches 60.. run function map:player/event/_click_closet/unable

function common:util/end
