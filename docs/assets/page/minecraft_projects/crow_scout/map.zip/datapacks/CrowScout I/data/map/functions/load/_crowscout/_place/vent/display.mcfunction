data merge entity @s {Tags: ["crowscout", "map", "vent"], item: {id: "minecraft:spawner", Count: 1b, tag: {CustomModelData: 11}}, width: 1f, height: 1f, item_display: "head", transformation: {translation: [0f, 0.5f, 0f]}}
tp @s ~ ~ ~ ~ ~
