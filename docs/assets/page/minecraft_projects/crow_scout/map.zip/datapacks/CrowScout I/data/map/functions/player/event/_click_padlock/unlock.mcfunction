execute as @e[distance=..4,tag=padlock] if score @s id = @e[type=interaction,tag=this.hitbox,limit=1] id run kill @s
kill @e[type=interaction,tag=this.hitbox,limit=1]
playsound block.iron_door.open block @a ~ ~ ~ 1 1 0
playsound crowscout:block.door_open block @a ~ ~ ~ 1 1 0
particle flash ~ ~.75 ~ 0 0 0 1 1
fill ~-1 ~-1 ~-1 ~1 ~1 ~1 air replace iron_door
