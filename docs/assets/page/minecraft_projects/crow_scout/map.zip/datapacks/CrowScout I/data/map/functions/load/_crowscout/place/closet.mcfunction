fill ~ ~ ~ ~ ~1 ~ black_stained_glass
execute summon item_display run function map:load/_crowscout/_place/closet/display
execute summon interaction run function map:load/_crowscout/_place/closet/hitbox
