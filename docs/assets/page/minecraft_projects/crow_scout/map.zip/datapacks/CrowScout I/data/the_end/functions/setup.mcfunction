scoreboard players set Mode status -2
title @a title {"text":"Player won!", "color":"green"}
schedule function lobby:setup 5s replace
