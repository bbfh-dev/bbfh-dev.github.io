data merge entity @s {Tags: ["crowscout", "camera_monitor"], width: 0.9f, height: 0.6f, response: 1b}
scoreboard players operation @s block_id = #MonitorID block_id
tp @s ~ ~ ~ ~ ~
tp @s ^ ^.2 ^-0.7
