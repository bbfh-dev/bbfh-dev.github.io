advancement revoke @s only map:neighbor/task/power_outage

function map:feature/tasks/complete_task
