item replace entity @s weapon.mainhand with crossbow{Charged: 1b, display: {Name: '{"translate":"item.crowscout.umbrella", "italic":false}'}}
function map:feature/umbrella
