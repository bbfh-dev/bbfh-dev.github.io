execute as @e[type=marker,tag=ai_destination,limit=1,sort=random,distance=9..] run function the_library:ai/follow_this_entity
attribute @e[type=wandering_trader,tag=ai,limit=1] generic.movement_speed base set 0.75
data modify entity @e[type=warden,limit=1] Silent set value 0b
scoreboard players set WardenChoose timer 600
playsound entity.warden.sniff hostile @a ~ ~ ~ 1 1 0
