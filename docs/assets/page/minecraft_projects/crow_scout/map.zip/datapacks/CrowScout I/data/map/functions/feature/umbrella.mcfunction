effect give @s slow_falling 5 2 true
scoreboard players set SlowFalling tmp 1
