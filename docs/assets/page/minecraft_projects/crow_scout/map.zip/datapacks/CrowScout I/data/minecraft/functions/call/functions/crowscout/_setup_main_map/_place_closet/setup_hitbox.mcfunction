data merge entity @s {Tags: ["crowscout", "closet"], width: 1.01f, height: 2f, response: 1b}
tp @s ~ ~ ~ ~ ~
