setblock -9 0 80 coarse_dirt
playsound block.rooted_dirt.place block @a -9 0 79 1 1 1
