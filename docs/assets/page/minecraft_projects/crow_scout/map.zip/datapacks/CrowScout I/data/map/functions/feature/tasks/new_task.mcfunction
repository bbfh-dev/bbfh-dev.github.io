scoreboard players set TaskCooldown timer -1

scoreboard players set ^From tmp 1
scoreboard players set ^To tmp 100
function common:random/get_random_range

kill @e[type=item_display,tag=task]
execute store result score #Daytime tmp run time query daytime

execute if score #Daytime tmp matches 0..12000 run function map:feature/tasks/_new_task/_daytime
execute if score #Daytime tmp matches 12001..24000 run function map:feature/tasks/_new_task/_nighttime
kill @e[type=marker,tag=random_task]

execute store result score TaskCooldown timer run scoreboard players operation TaskTimer timer = Time tmp
scoreboard players add TaskCooldown timer 300

team join neighbor @e[type=item_display,tag=task]
playsound entity.ender_dragon.hurt block @a[team=neighbor] ~ ~ ~ 1024 1 1
execute store result bossbar task max run scoreboard players get Time tmp
execute store result bossbar task value run scoreboard players get Time tmp
bossbar set task visible true
bossbar set task color red
