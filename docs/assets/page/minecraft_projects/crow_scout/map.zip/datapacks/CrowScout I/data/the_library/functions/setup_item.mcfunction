execute store result score Y tmp run data get entity @s Pos[1]
execute if score Y tmp matches ..-12 run kill @s
