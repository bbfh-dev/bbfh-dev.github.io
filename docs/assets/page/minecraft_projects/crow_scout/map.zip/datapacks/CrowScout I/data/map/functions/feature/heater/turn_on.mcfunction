scoreboard players set Heater status 1
setblock 3 27 40 beehive[facing=east,honey_level=2]
fill -19 15 42 -13 15 48 water replace packed_ice

stopsound @a * block.beacon.activate
playsound block.beacon.activate block @a 3 27 40 1 1 0
playsound block.lava.pop block @a 3 27 40 1 1 0
