scoreboard players set #Limit tmp 0
scoreboard players set #Spawned tmp 1
summon item_display ~ ~.5 ~ {Tags: ["crowscout", "map", "bear_trap"], item: {id: "spawner", Count: 1b, tag: {CustomModelData: 12}}, width: 1f, height: 1f, shadow_radius: 0.5f, shadow_strength: 0.5f}
summon interaction ~ ~ ~ {Tags: ["crowscout", "map", "bear_trap"], width: 0.6f, height: 0.1f, response: 1b}
