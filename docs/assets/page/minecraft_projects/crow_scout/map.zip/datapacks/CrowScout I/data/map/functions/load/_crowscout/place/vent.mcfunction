execute summon item_display run function map:load/_crowscout/_place/vent/display
execute summon interaction run function map:load/_crowscout/_place/vent/hitbox
