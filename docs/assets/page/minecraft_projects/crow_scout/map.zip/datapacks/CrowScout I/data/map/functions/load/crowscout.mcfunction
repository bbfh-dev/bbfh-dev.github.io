kill @e[tag=crowscout]

# ::: Cameras / Monitors
scoreboard players set #CameraID tmp 0
execute positioned -6 5 50 rotated 135 25 run function map:load/_crowscout/place/camera
execute positioned -9 6 32 rotated -135 25 run function map:load/_crowscout/place/camera
execute positioned 12 6 57 rotated -135 25 run function map:load/_crowscout/place/camera
execute positioned -12 10 47 rotated -45 25 run function map:load/_crowscout/place/camera
execute positioned 13 15 40 rotated 45 25 run function map:load/_crowscout/place/camera
execute positioned 5 20 34 rotated 135 25 run function map:load/_crowscout/place/camera
execute positioned 1 20 46 rotated 45 25 run function map:load/_crowscout/place/camera
execute positioned 18 20 50 rotated 135 25 run function map:load/_crowscout/place/camera
execute positioned -6 24 44 rotated 135 25 run function map:load/_crowscout/place/camera
execute positioned 18 26 61 rotated 135 25 run function map:load/_crowscout/place/camera

scoreboard players set #MonitorID tmp 0
execute positioned -28 -3 46 rotated -90 0 run function map:load/_crowscout/place/camera_monitor
execute positioned -28 -3 45 rotated -90 0 run function map:load/_crowscout/place/camera_monitor
execute positioned -28 -3 44 rotated -90 0 run function map:load/_crowscout/place/camera_monitor
execute positioned -28 -3 43 rotated -90 0 run function map:load/_crowscout/place/camera_monitor
execute positioned -28 -3 42 rotated -90 0 run function map:load/_crowscout/place/camera_monitor
execute positioned -28 -4 46 rotated -90 0 run function map:load/_crowscout/place/camera_monitor
execute positioned -28 -4 45 rotated -90 0 run function map:load/_crowscout/place/camera_monitor
execute positioned -28 -4 44 rotated -90 0 run function map:load/_crowscout/place/camera_monitor
execute positioned -28 -4 43 rotated -90 0 run function map:load/_crowscout/place/camera_monitor
execute positioned -28 -4 42 rotated -90 0 run function map:load/_crowscout/place/camera_monitor

# ::: Closets
execute positioned -11 2 39 rotated 180 0 run function map:load/_crowscout/place/closet
execute positioned 7 2 -18 rotated 90 0 run function map:load/_crowscout/place/closet
execute positioned -2 7 -14 rotated -90 0 run function map:load/_crowscout/place/closet
execute positioned 0 2 40 rotated 180 0 run function map:load/_crowscout/place/closet
execute positioned -3 7 41 rotated 90 0 run function map:load/_crowscout/place/closet
execute positioned 12 12 52 rotated -90 0 run function map:load/_crowscout/place/closet
execute positioned -7 12 37 rotated 0 0 run function map:load/_crowscout/place/closet
execute positioned 14 17 46 rotated 0 0 run function map:load/_crowscout/place/closet
execute positioned 12 22 40 rotated 0 0 run function map:load/_crowscout/place/closet
execute positioned -9 22 38 rotated 0 0 run function map:load/_crowscout/place/closet
execute positioned -10 17 44 rotated 180 0 run function map:load/_crowscout/place/closet
execute positioned 16 3 59 rotated 90 0 run function map:load/_crowscout/place/closet

# ::: Vents
execute positioned -8 10 38 rotated 90 0 run function map:load/_crowscout/place/vent
execute positioned 12 14 50 rotated 180 0 run function map:load/_crowscout/place/vent
execute positioned -7 10 35 rotated 180 0 run function map:load/_crowscout/place/vent
execute positioned 16 9 61 rotated 90 0 run function map:load/_crowscout/place/vent
execute positioned 7 15 47 rotated 0 0 run function map:load/_crowscout/place/vent
execute positioned -11 20 42 rotated -90 0 run function map:load/_crowscout/place/vent
execute positioned 4 20 57 rotated 180 0 run function map:load/_crowscout/place/vent
execute positioned 17 25 46 rotated 0 0 run function map:load/_crowscout/place/vent
execute positioned -11 24 44 rotated 180 0 run function map:load/_crowscout/place/vent

# ::: Padlocks
scoreboard players set #PadlockID tmp 1
execute positioned 1 2 45 rotated -90 0 run function map:load/_crowscout/place/padlock
execute positioned 1 2 46 rotated -90 0 run function map:load/_crowscout/place/padlock
scoreboard players set #PadlockID tmp 2
execute positioned 5 17 51 rotated 180 0 run function map:load/_crowscout/place/padlock
execute positioned 6 17 51 rotated 180 0 run function map:load/_crowscout/place/padlock
scoreboard players set #PadlockID tmp 3
execute positioned -3 2 -16 rotated -90 0 run function map:load/_crowscout/place/padlock
scoreboard players set #PadlockID tmp 4
execute positioned -4 1 53 rotated 0 0 run function map:load/_crowscout/place/padlock
scoreboard players set #PadlockID tmp 5
execute positioned 7 22 48 rotated 90 0 run function map:load/_crowscout/place/padlock
scoreboard players set #PadlockID tmp 6
execute positioned -11 22 37 rotated 180 0 run function map:load/_crowscout/place/padlock
scoreboard players set #PadlockID tmp 7
execute positioned -12 2 44 rotated -90 0 run function map:load/_crowscout/place/padlock

# ::: Dreams
summon marker 12 9 60 {Tags: ["crowscout", "map", "dream_point", "the_library"]}
summon marker -24 -5 40 {Tags: ["crowscout", "map", "dream_point", "the_end"]}

# ::: ----
# ::: Misc
# ::: ----

fill -8 0 80 -10 0 79 air

# Guide books
setblock 3 7 -17 air
setblock 3 7 -17 lectern[facing=west,has_book=true,powered=false]{Book: {Count: 1b, id: "minecraft:written_book", tag: {author: "crowscout", pages: ['{"extra":[{"text":"\\n\\n\\n\\n\\n⭐ "},{"bold":true,"text":"Hey Neighbor: Catch"},{"text":" ⭐\\n\\n     "},{"color":"dark_green","text":"[Player guide]"},{"text":"\\n\\n\\n\\n\\n          "},{"color":"dark_gray","text":"by BubbleFish"},{"text":"\\n "}],"text":""}', '{"extra":[{"color":"dark_gray","text":"==================="},{"text":"\\n\\n  "},{"color":"dark_purple","text":"[Table of contents]"},{"text":"\\n\\nGame.........................................3\\n\\nObtaining items.................5\\n\\nBreaking windows..........6\\n\\nLocked doors..................7\\n\\nDreams...................................8\\n "}],"text":""}', '{"extra":[{"color":"dark_aqua","text":"          [Game]"},{"text":"\\n\\n- Break bear traps by punching them;\\n\\n- Your armor bar represents how many lifes you have left;\\n\\n- Falling will cause your legs to be temporarily broken (depending on the height);\\n "}],"text":""}', '{"extra":[{"color":"dark_aqua","text":"          [Game]"},{"text":"\\n\\n- The neighbor needs to hit you in order for you to lose 1 life;\\n\\n- There are no unreachable places to be at;\\n\\n- Punch a camera to break it;"}],"text":""}', '{"extra":[{"color":"dark_aqua","text":"    [Obtaining items]"},{"text":"\\n\\n- Items that can be obtained are always located in:\\n    1. Containers;\\n    2. Item frames;\\n\\n- Neighbor cannot pick up your items;"}],"text":""}', '{"extra":[{"color":"dark_aqua","text":"   [Breaking windows]"},{"text":"\\n\\n- Hold ["},{"color":"gold","keybind":"key.sneak"},{"text":"] while being inside of a window frame to break it;\\n\\n- Windows will automatically repair after 30 seconds;\\n\\n- Neighbor can break windows faster;"}],"text":""}', '{"extra":[{"color":"dark_aqua","text":"     [Locked doors]"},{"text":"\\n\\n- Locked doors are marked with a padlock icon;\\n\\n- Right click to see the color of key required by the door;\\n\\n- Only need to be unlocked once;"}],"text":""}', '{"extra":[{"color":"dark_aqua","text":"         [Dreams]"},{"text":"\\n\\n- By entering certain rooms for the first time you might join a dream;"}],"text":""}'], resolved: 1b, title: "Player Tutorial"}}, Page: 0}
setblock -28 -5 44 air
setblock -28 -5 44 lectern[facing=east,has_book=true,powered=false]{Book: {Count: 1b, id: "minecraft:written_book", tag: {author: "crowscout", pages: ['{"extra":[{"text":"\\n\\n\\n\\n\\n⭐ "},{"bold":true,"text":"Hey Neighbor: Catch"},{"text":" ⭐\\n\\n    "},{"color":"dark_red","text":"[Neighbor guide]"},{"text":"\\n\\n\\n\\n\\n          "},{"color":"dark_gray","text":"by BubbleFish"},{"text":"\\n "}],"text":""}', '{"extra":[{"color":"dark_gray","text":"==================="},{"text":"\\n\\n  "},{"color":"dark_purple","text":"[Table of contents]"},{"text":"\\n\\n"},{"clickEvent":{"action":"change_page","value":"3"},"text":"Game.........................................3"},{"text":"\\n\\n"},{"clickEvent":{"action":"change_page","value":"5"},"text":"Tasks......................................5"},{"text":"\\n\\n"},{"clickEvent":{"action":"change_page","value":"7"},"text":"Catching player.............7"},{"text":"\\n\\n"},{"clickEvent":{"action":"change_page","value":"9"},"text":"Bear Traps.......................9"},{"text":"\\n\\n"},{"clickEvent":{"action":"change_page","value":"11"},"text":"Cameras............................11"},{"text":"\\n "}],"text":""}', '{"extra":[{"color":"dark_red","text":"          [Game]"},{"text":"\\n\\n- Falling will cause your legs to be temporarily broken (depending on the height);\\n\\n- You need to hit player to catch them;\\n\\n- Your role is to protect your house;"}],"text":""}', '{"extra":[{"color":"dark_red","text":"          [Game]"},{"text":"\\n\\n- All doors automatically open in-front of you;\\n\\n- You can\'t kill player if he is outside of your property;\\n\\n- Use vents around your house to get back to this place;"}],"text":""}', '{"extra":[{"color":"dark_red","text":"          [Tasks]"},{"text":"\\n\\n- From time-to-time you must complete tasks;\\n\\n- You get a timer and status of the task on top of your screen;\\n\\n- Not completing the task in time results in a punishment defined by the task itself;"}],"text":""}', '{"extra":[{"color":"dark_red","text":"          [Tasks]"},{"text":"\\n\\n- After completing the task you may rest until the timer runs out and a new task will be selected;\\n\\n- Tasks are made to prevent you from camping the player, as well as give you some fun activities to do;"}],"text":""}', '{"extra":[{"color":"dark_red","text":"    [Catching player]"},{"text":"\\n\\n- Hold shift while being inside of a window frame to break the window;\\n\\n- Windows repair themselves after 30 seconds;\\n\\n- Hit the player to catch them;"}],"text":""}', '{"extra":[{"color":"dark_red","text":"    [Catching player]"},{"text":"\\n\\n- Player lifes are printed on top of the exit from your basement;"}],"text":""}', '{"extra":[{"color":"dark_red","text":"      [Bear Traps]"},{"text":"\\n\\n- You potentially get a bear trap every 30 seconds;\\n\\n- The more bear traps you have in your inventory / placed somewhere, the fewer bear traps you will get regularly;\\n\\n "}],"text":""}', '{"extra":[{"color":"dark_red","text":"      [Bear Traps]"},{"text":"\\n\\n- Player can break the bear trap by punching them, however they will still produce a sound;\\n\\n- Player that got caught into a bear trap won\'t be able to move and will also glow for 3 seconds;"}],"text":""}', '{"extra":[{"color":"dark_red","text":"        [Cameras]"},{"text":"\\n\\n- You can watch cameras by clicking on the monitors;\\n\\n- You can repair cameras by punching them;\\n\\n- Cameras won\'t work in case of power outage;"}],"text":""}'], resolved: 1b, title: "Neighbor Tutorial"}}, Page: 0}

# EXIT Sign
summon text_display -12.0 4.25 44 {Tags: ["crowscout", "map", "misc"], text: '{"text":"EXIT", "color":"green", "bold":true}', shadow: 1b, shadow_radius: 0, background: 0, brightness: {block: 15, sky: 15}, width: 1f, height: 1f, Rotation: [-90f, 0f]}

# PIN-Code lock
execute positioned -6 8 46 rotated 180 0 run function map:load/_crowscout/place/pincode_lock

# Electrical box
execute positioned 11 19 57 rotated -90 0 run function map:load/_crowscout/place/electrical_box

# Camfire on 1st floor
setblock -2 2 43 campfire[lit=true]
setblock -2 1 43 mud_bricks

# Heater
setblock 3 27 40 beehive[facing=east,honey_level=2]
setblock 3 27 41 lever[facing=south,face=wall,powered=true]
fill -19 15 42 -13 15 48 water replace packed_ice

# Safe
fill 9 12 51 7 14 51 barrier replace air
summon item_display 8 13.5 51 {Tags: ["crowscout", "map", "safe"], item: {id: "minecraft:spawner", Count: 1b, tag: {CustomModelData: 15}}, width: 3f, height: 3f, item_display: "head", Rotation: [180f, 0f]}
summon interaction 8 14.75 51.0 {Tags: ["crowscout", "map", "safe", "spot_1"], width: 0.5f, height: 0.25f, response: 1b}
summon interaction 7.125 13.25 50.875 {Tags: ["crowscout", "map", "safe", "spot_2"], width: 0.25f, height: 0.5f, response: 1b}
summon interaction 8 12 51.0 {Tags: ["crowscout", "map", "safe", "spot_3"], width: 0.5f, height: 0.25f, response: 1b}
summon interaction 9.875 13.25 50.875 {Tags: ["crowscout", "map", "safe", "spot_4"], width: 0.25f, height: 0.5f, response: 1b}

# Telescope
summon item_display -1 7.5 -11 {Tags: ["crowscout", "map", "telescope"], item: {id: "minecraft:spawner", Count: 1b, tag: {CustomModelData: 17}}, width: 1f, height: 1f, item_display: "head", Rotation: [5f, 0f]}
summon interaction -1 7 -11 {Tags: ["crowscout", "map", "telescope"], width: 1.5f, height: 2f, response: 1b}
