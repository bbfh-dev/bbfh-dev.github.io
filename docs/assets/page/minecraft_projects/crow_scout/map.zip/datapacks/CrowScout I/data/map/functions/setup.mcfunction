# ::: Basics
gamerule doDaylightCycle true

# ::: Load
scoreboard players set LCG status 1103515245
execute unless score #LCG status matches ..0 unless score #LCG status matches 1.. run function common:random/reset_uuid

tellraw @a ["", {"text":"[Debug]", "color":"yellow", "bold":true}, " Reloading the map..."]
function map:load/random_variation
function map:load/crowscout
function map:load/variables
