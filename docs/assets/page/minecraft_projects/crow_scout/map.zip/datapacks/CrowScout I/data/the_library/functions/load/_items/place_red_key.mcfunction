execute as @s[tag=item_placeholder] run loot replace entity @e[type=item_frame,distance=..2,sort=nearest,limit=1] container.0 loot the_library:item/red_key
execute as @s[tag=container_placeholder] run loot insert ~ ~ ~ loot the_library:item/red_key
data modify entity @s Invulnerable set value 0b
