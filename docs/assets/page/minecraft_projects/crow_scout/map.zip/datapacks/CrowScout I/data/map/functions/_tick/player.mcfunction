execute if block ~ ~-2 ~ magma_block run effect give @s speed 1 50 true
execute as @s[team=player] run function map:player/tick
execute as @s[team=neighbor] run function map:neighbor/tick
scoreboard players reset @s sneak_time

execute unless score SensorCooldown timer matches 1.. positioned ~-4.5 ~-1 ~-4.5 if entity @e[type=interaction,tag=motion_sensor,dx=8,dz=8,dy=1] run function map:feature/motion_sensor
