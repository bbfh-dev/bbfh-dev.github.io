data merge entity @s {Tags: ["crowscout", "map", "closet"], width: 1.01f, height: 2f, response: 1b}
tp @s ~ ~ ~ ~ ~
