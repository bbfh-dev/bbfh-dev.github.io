data merge entity @s {Tags: ["crowscout", "map", "pincode_lock"], item: {id: "minecraft:spawner", Count: 1b, tag: {CustomModelData: 8}}, width: 1f, height: 1f, item_display: "head", brightness: {block: 15, sky: 15}}
tp @s ~ ~ ~ ~ ~
