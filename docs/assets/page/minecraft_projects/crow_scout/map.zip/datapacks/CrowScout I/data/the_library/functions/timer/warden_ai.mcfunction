scoreboard players set WardenAI timer 10
execute unless data entity @s WanderTarget run function the_library:ai/select_new_location
function the_library:ai/step
