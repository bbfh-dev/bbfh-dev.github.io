tag @s remove inside_of_a_window
execute if score @s sneak_time matches 1.. run function map:player/while_sneaking
execute if entity @e[type=interaction,tag=bear_trap,distance=...5] run function map:feature/bear_trap/catch
execute if block ~ ~ ~ #map:doors[open=true] if entity @e[type=interaction,tag=padlock,distance=..1] run function map:player/misc/close_door
execute if entity @e[type=marker,tag=dream_point,distance=...5] run function map:player/enter_dream

scoreboard players set SlowFalling tmp 0
execute if entity @s[nbt={SelectedItem: {id: "minecraft:crossbow"}}] run function map:feature/umbrella_main
execute if entity @s[nbt={Inventory: [{Slot: -106b, id: "minecraft:crossbow"}]}] run function map:feature/umbrella_off
execute if score SlowFalling tmp matches 0 run effect clear @s slow_falling

execute as @e[type=marker,tag=light] at @s run function map:feature/_flash_light/remove
execute unless entity @s[nbt={SelectedItem: {id: "minecraft:ender_eye"}}] run scoreboard players set FlashOn status 0
execute if score FlashOn status matches 0 run bossbar set flash_light visible false
execute if score FlashOn status matches 1 run function map:feature/_flash_light/as_player
