scoreboard players operation @s block_id = #MonitorID block_id
execute as @e[type=cave_spider,tag=security_camera_lens] if score @s block_id = #MonitorID block_id run function call:crowscout/_setup_main_map/_place_monitor/_setup_text/get_floor_number
data merge entity @s {Tags: ["crowscout", "camera_monitor"], width: 1.0f, height: 1.0f, text: '["", {"text":"Camera #", "color":"green", "extra":[{"score":{"name":"@s", "objective":"block_id"}}]}, "\\n", {"text":"Floor #", "extra":[{"score":{"name":"#Floor", "objective":"world"}}]}]', transformation: {scale: [0.5f, 0.5f, 0.5f]}, background: 0, line_width: 70}
tp @s ~ ~ ~ ~ ~
tp @s ^ ^.375 ^-0.24
