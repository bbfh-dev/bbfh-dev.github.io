data merge entity @s {Tags: ["crowscout", "map", "camera_monitor"], item: {id: "minecraft:spawner", Count: 1b, tag: {CustomModelData: 5}}, transformation: {translation: [0f, 0.5f, 0f]}, width: 1.0f, height: 1.0f, item_display: "head"}
scoreboard players operation @s id = #MonitorID tmp
tp @s ~ ~ ~ ~ ~
