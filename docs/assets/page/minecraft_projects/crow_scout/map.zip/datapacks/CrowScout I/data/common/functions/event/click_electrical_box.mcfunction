advancement revoke @s only map:common/click_electrical_box
function common:util/get_hitbox

execute store result score #Model tmp run data get entity @e[type=item_display,tag=electrical_box,limit=1] item.tag.CustomModelData
execute if score #Model tmp matches 10 run function common:event/_click_electrical_box/turn_on
execute if score #Model tmp matches 9 run function common:event/_click_electrical_box/turn_off

playsound ui.button.click block @s ~ ~ ~ 1 1 0

function common:util/end
