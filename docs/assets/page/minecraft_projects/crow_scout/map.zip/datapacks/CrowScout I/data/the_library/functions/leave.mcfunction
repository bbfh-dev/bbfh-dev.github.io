clear @a
item replace entity @p[team=player] hotbar.0 from block 0 -2 0 container.0
item replace entity @p[team=player] hotbar.1 from block 0 -2 0 container.1
item replace entity @p[team=player] hotbar.2 from block 0 -2 0 container.2
item replace entity @p[team=player] hotbar.3 from block 0 -2 0 container.3
item replace entity @p[team=player] hotbar.4 from block 0 -2 0 container.4
item replace entity @p[team=player] hotbar.5 from block 0 -2 0 container.5
item replace entity @p[team=player] hotbar.6 from block 0 -2 0 container.6
item replace entity @p[team=player] hotbar.7 from block 0 -2 0 container.7
item replace entity @p[team=player] hotbar.8 from block 0 -2 0 container.8
item replace entity @p[team=player] inventory.0 from block 0 -2 0 container.9
item replace entity @p[team=player] inventory.1 from block 0 -2 0 container.10
item replace entity @p[team=player] inventory.2 from block 0 -2 0 container.11
item replace entity @p[team=player] inventory.3 from block 0 -2 0 container.12
item replace entity @p[team=player] inventory.4 from block 0 -2 0 container.13
item replace entity @p[team=player] inventory.5 from block 0 -2 0 container.14
item replace entity @p[team=player] inventory.6 from block 0 -2 0 container.15
item replace entity @p[team=player] inventory.7 from block 0 -2 0 container.16
item replace entity @p[team=player] inventory.8 from block 0 -2 0 container.17
item replace entity @p[team=player] inventory.9 from block 0 -2 0 container.18
item replace entity @p[team=player] inventory.10 from block 0 -2 0 container.19
item replace entity @p[team=player] inventory.11 from block 0 -2 0 container.20
item replace entity @p[team=player] inventory.12 from block 0 -2 0 container.21
item replace entity @p[team=player] inventory.13 from block 0 -2 0 container.22
item replace entity @p[team=player] inventory.14 from block 0 -2 0 container.23
item replace entity @p[team=player] inventory.15 from block 0 -2 0 container.24
item replace entity @p[team=player] inventory.16 from block 0 -2 0 container.25
item replace entity @p[team=player] inventory.17 from block 0 -2 0 container.26
item replace entity @p[team=player] inventory.18 from block 1 -2 0 container.0
item replace entity @p[team=player] inventory.19 from block 1 -2 0 container.1
item replace entity @p[team=player] inventory.20 from block 1 -2 0 container.2
item replace entity @p[team=player] inventory.21 from block 1 -2 0 container.3
item replace entity @p[team=player] inventory.22 from block 1 -2 0 container.4
item replace entity @p[team=player] inventory.23 from block 1 -2 0 container.5
item replace entity @p[team=player] inventory.24 from block 1 -2 0 container.6
item replace entity @p[team=player] inventory.25 from block 1 -2 0 container.7
item replace entity @p[team=player] inventory.26 from block 1 -2 0 container.8
item replace entity @p[team=player] armor.feet from block 1 -2 0 container.9
item replace entity @p[team=player] armor.legs from block 1 -2 0 container.10
item replace entity @p[team=player] armor.chest from block 1 -2 0 container.11
item replace entity @p[team=player] armor.head from block 1 -2 0 container.12
item replace entity @p[team=player] weapon.offhand from block 1 -2 0 container.13

item replace entity @p[team=neighbor] hotbar.0 from block 0 -2 1 container.0
item replace entity @p[team=neighbor] hotbar.1 from block 0 -2 1 container.1
item replace entity @p[team=neighbor] hotbar.2 from block 0 -2 1 container.2
item replace entity @p[team=neighbor] hotbar.3 from block 0 -2 1 container.3
item replace entity @p[team=neighbor] hotbar.4 from block 0 -2 1 container.4
item replace entity @p[team=neighbor] hotbar.5 from block 0 -2 1 container.5
item replace entity @p[team=neighbor] hotbar.6 from block 0 -2 1 container.6
item replace entity @p[team=neighbor] hotbar.7 from block 0 -2 1 container.7
item replace entity @p[team=neighbor] hotbar.8 from block 0 -2 1 container.8
item replace entity @p[team=neighbor] inventory.0 from block 0 -2 1 container.9
item replace entity @p[team=neighbor] inventory.1 from block 0 -2 1 container.10
item replace entity @p[team=neighbor] inventory.2 from block 0 -2 1 container.11
item replace entity @p[team=neighbor] inventory.3 from block 0 -2 1 container.12
item replace entity @p[team=neighbor] inventory.4 from block 0 -2 1 container.13
item replace entity @p[team=neighbor] inventory.5 from block 0 -2 1 container.14
item replace entity @p[team=neighbor] inventory.6 from block 0 -2 1 container.15
item replace entity @p[team=neighbor] inventory.7 from block 0 -2 1 container.16
item replace entity @p[team=neighbor] inventory.8 from block 0 -2 1 container.17
item replace entity @p[team=neighbor] inventory.9 from block 0 -2 1 container.18
item replace entity @p[team=neighbor] inventory.10 from block 0 -2 1 container.19
item replace entity @p[team=neighbor] inventory.11 from block 0 -2 1 container.20
item replace entity @p[team=neighbor] inventory.12 from block 0 -2 1 container.21
item replace entity @p[team=neighbor] inventory.13 from block 0 -2 1 container.22
item replace entity @p[team=neighbor] inventory.14 from block 0 -2 1 container.23
item replace entity @p[team=neighbor] inventory.15 from block 0 -2 1 container.24
item replace entity @p[team=neighbor] inventory.16 from block 0 -2 1 container.25
item replace entity @p[team=neighbor] inventory.17 from block 0 -2 1 container.26
item replace entity @p[team=neighbor] inventory.18 from block 1 -2 1 container.0
item replace entity @p[team=neighbor] inventory.19 from block 1 -2 1 container.1
item replace entity @p[team=neighbor] inventory.20 from block 1 -2 1 container.2
item replace entity @p[team=neighbor] inventory.21 from block 1 -2 1 container.3
item replace entity @p[team=neighbor] inventory.22 from block 1 -2 1 container.4
item replace entity @p[team=neighbor] inventory.23 from block 1 -2 1 container.5
item replace entity @p[team=neighbor] inventory.24 from block 1 -2 1 container.6
item replace entity @p[team=neighbor] inventory.25 from block 1 -2 1 container.7
item replace entity @p[team=neighbor] inventory.26 from block 1 -2 1 container.8
item replace entity @p[team=neighbor] armor.feet from block 1 -2 1 container.9
item replace entity @p[team=neighbor] armor.legs from block 1 -2 1 container.10
item replace entity @p[team=neighbor] armor.chest from block 1 -2 1 container.11
item replace entity @p[team=neighbor] armor.head from block 1 -2 1 container.12
item replace entity @p[team=neighbor] weapon.offhand from block 1 -2 1 container.13

kill @e[tag=crowscout,tag=dream]
gamerule doDaylightCycle true
time set day
effect clear @a

kill @e[tag=the_library]
execute as @a[team=player] positioned 12 9 61 rotated 180 0 run function common:action/teleport_here
execute as @a[team=neighbor] positioned -21 -5 44 rotated 90 0 run function common:action/teleport_here
scoreboard players set Mode status 1
stopsound @a * crowscout:music.attack_theme_stay
stopsound @a * crowscout:music.attack_theme
