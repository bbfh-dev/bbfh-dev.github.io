tellraw @a ["", {"text":"[Debug]", "color":"yellow", "bold":true}, " Loading default map..."]
kill @e[type=!player,tag=!dream]
function map:load/chunks/variant_0
summon marker ~ ~ ~ {Tags: ["loading_variant", "variant_1"]}
summon marker ~ ~ ~ {Tags: ["loading_variant", "variant_2"]}
summon marker ~ ~ ~ {Tags: ["loading_variant", "variant_3"]}
summon marker ~ ~ ~ {Tags: ["loading_variant", "variant_4"]}
summon marker ~ ~ ~ {Tags: ["loading_variant", "variant_5"]}
summon marker ~ ~ ~ {Tags: ["loading_variant", "variant_6"]}
tellraw @a ["", {"text":"[Debug]", "color":"yellow", "bold":true}, " Generating random variation..."]
kill @e[type=item_frame,nbt={Item: {id: "minecraft:spyglass"}}]
execute as @e[type=marker,tag=loading_variant,limit=1,sort=random] run function map:load/load_variant
kill @e[type=marker,tag=loading_variant]
execute as @e[type=item_frame,nbt={Invisible: 0b}] run data merge entity @s {Invisible: 1b}
tellraw @a ["", {"text":"[Debug]", "color":"yellow", "bold":true}, " Beginning in 6 seconds..."]
