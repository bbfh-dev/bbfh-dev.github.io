### Cloud Notes ###
# Newton-Raphson, 4 iterations approach

scoreboard players add ^To tmp 1
scoreboard players operation #range tmp = ^To tmp
scoreboard players operation #range tmp -= ^From tmp

scoreboard players operation #m1 tmp = #range tmp
scoreboard players remove #m1 tmp 1
function common:random/_get_random_range/next_int
scoreboard players operation Random tmp += ^From tmp

scoreboard players reset #m1 tmp
scoreboard players remove ^To tmp 1
