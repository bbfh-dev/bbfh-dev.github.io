scoreboard players add #PadlockID block_id 3
execute summon item_display run function call:dream/_play_library/setup_model
execute summon interaction run function call:dream/_play_library/setup_hitbox
