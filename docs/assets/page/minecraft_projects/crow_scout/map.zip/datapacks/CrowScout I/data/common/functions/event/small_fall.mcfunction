advancement revoke @s only map:common/small_fall

playsound crowscout:entity.fall neutral @a ~ ~ ~ 0.5 1 0
effect give @s slowness 3 2 true
effect give @s jump_boost 3 128 true
effect give @s blindness 1 0 true
