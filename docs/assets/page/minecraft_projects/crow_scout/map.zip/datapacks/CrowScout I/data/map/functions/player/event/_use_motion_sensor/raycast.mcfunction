scoreboard players set #Limit tmp 12
scoreboard players set #Spawned tmp 0
function map:player/event/_use_motion_sensor/loop
execute if score #Spawned tmp matches 1 run function map:neighbor/event/_use_bear_trap/remove_item
