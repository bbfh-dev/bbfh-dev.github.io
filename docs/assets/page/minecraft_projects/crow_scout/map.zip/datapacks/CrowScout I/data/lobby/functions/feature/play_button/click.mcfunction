setblock ~ ~ ~ oak_button[facing=east,powered=false,face=wall] replace
execute unless entity @p[team=neighbor] run tellraw @a {"translate":"caption.crowscout.team_missing", "color":"red", "with":[{"translate":"Neighbor"}]}
execute unless entity @p[team=player] run tellraw @a {"translate":"caption.crowscout.team_missing", "color":"red", "with":[{"translate":"Player"}]}
execute if entity @p[team=neighbor] if entity @p[team=player] run function lobby:leave
