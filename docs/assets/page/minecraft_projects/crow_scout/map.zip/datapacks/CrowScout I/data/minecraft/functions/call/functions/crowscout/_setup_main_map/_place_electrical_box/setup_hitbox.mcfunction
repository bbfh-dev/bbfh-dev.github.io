data merge entity @s {Tags: ["crowscout", "electrical_box"], width: 0.75f, height: 1f, response: 1b}
tp @s ~ ~ ~ ~ ~
tp @s ^ ^ ^-0.5
