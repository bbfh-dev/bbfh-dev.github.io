scoreboard players set ClosestBeating timer 5
execute if score WardenChasing timer matches 1.. run playsound entity.warden.step block @a ~ ~ ~ 10 1 0
execute if score WardenChasing timer matches 1.. if entity @p[team=player,distance=..4] run playsound entity.warden.nearby_closest hostile @a ~ ~ ~ 1 1.2 0
