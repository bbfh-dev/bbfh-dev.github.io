data modify entity @s item.tag.CustomModelData set value 4
execute at @s as @p[team=neighbor,gamemode=spectator,distance=..3] run function map:neighbor/event/_click_camera_monitor/leave
playsound crowscout:block.camera_break block @a[distance=..12] ~ ~ ~ 0.25 1 0
particle flash ~ ~ ~ 0 0 0 1 1 normal @a
tag @s add is_broken
