scoreboard players set #isLoaded world 1

execute unless loaded -96 0 -96 run scoreboard players set #isLoaded world 0
execute unless loaded -48 0 -96 run scoreboard players set #isLoaded world 0
execute unless loaded 000 0 -96 run scoreboard players set #isLoaded world 0
execute unless loaded -48 0 -96 run scoreboard players set #isLoaded world 0

execute unless loaded -96 0 -48 run scoreboard players set #isLoaded world 0
execute unless loaded -48 0 -48 run scoreboard players set #isLoaded world 0
execute unless loaded 000 0 -48 run scoreboard players set #isLoaded world 0
execute unless loaded -48 0 -48 run scoreboard players set #isLoaded world 0

execute unless loaded -96 0 000 run scoreboard players set #isLoaded world 0
execute unless loaded -48 0 000 run scoreboard players set #isLoaded world 0
execute unless loaded 000 0 000 run scoreboard players set #isLoaded world 0
execute unless loaded -48 0 000 run scoreboard players set #isLoaded world 0

execute unless loaded -96 0 048 run scoreboard players set #isLoaded world 0
execute unless loaded -48 0 048 run scoreboard players set #isLoaded world 0
execute unless loaded 000 0 048 run scoreboard players set #isLoaded world 0
execute unless loaded -48 0 048 run scoreboard players set #isLoaded world 0

execute if score #isLoaded world matches 1 run function call:crowscout/_load_main_map/complete
execute if score #isLoaded world matches 0 run schedule function call:crowscout/_load_main_map/verify_chunks 1s replace
