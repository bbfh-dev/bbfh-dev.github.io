scoreboard players set Heater status 0
setblock 3 27 40 beehive[facing=east,honey_level=1]
fill -19 15 42 -13 15 48 packed_ice replace water

stopsound @a * block.beacon.deactivate
playsound block.beacon.deactivate block @a 3 27 40 1 1 0
playsound block.lava.extinguish block @a 3 27 40 1 1 0
