execute store result score #Y world run data get entity @s Pos[1]

execute if score #Y world matches ..6 run scoreboard players set #Floor world 1
execute if score #Y world matches 7..11 run scoreboard players set #Floor world 2
execute if score #Y world matches 12..16 run scoreboard players set #Floor world 3
execute if score #Y world matches 17..21 run scoreboard players set #Floor world 4
execute if score #Y world matches 22.. run scoreboard players set #Floor world 5
