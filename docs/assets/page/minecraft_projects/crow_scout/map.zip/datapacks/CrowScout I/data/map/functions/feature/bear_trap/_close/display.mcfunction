data modify entity @s item.tag.CustomModelData set value 13
scoreboard players set @s timer 140
tag @s add used_bear_trap
