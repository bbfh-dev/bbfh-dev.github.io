advancement revoke @s only map:player/click_padlock
function common:util/get_hitbox

scoreboard players set #isLocked tmp 1
execute as @e[type=item_display,distance=..8,tag=padlock] if score @s id = @e[type=interaction,tag=this.hitbox,limit=1] id run data modify storage crowscout Key set from entity @s item.tag.Key
execute if data entity @s SelectedItem store success score #isLocked tmp run data modify storage crowscout Key.id set from entity @s SelectedItem.id
execute if score #isLocked tmp matches 1 run function map:player/event/_click_padlock/locked
execute if score #isLocked tmp matches 0 at @e[type=interaction,tag=this.hitbox,limit=1] run function map:player/event/_click_padlock/unlock
data remove storage crowscout Key

function common:util/end
