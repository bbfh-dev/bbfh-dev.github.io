scoreboard players set #Limit tmp 0
scoreboard players set #Spawned tmp 1
summon item_display ~ ~.5 ~ {Tags: ["crowscout", "map", "motion_sensor"], item: {id: "spawner", Count: 1b, tag: {CustomModelData: 18}}, width: 1f, height: 1f, shadow_radius: 0.5f, shadow_strength: 1f}
summon interaction ~ ~ ~ {Tags: ["crowscout", "map", "motion_sensor"], width: 0.8f, height: 0.8f, response: 1b}
playsound ui.stonecutter.select_recipe block @a ~ ~ ~ 1 1 0
