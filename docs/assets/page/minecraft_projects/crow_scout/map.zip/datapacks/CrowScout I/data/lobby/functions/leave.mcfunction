stopsound @a * crowscout:music.intro_nostalgia
kill @e[tag=crowscout,tag=lobby]
function map:setup
