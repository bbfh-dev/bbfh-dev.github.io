# LCG Seed implementation
#
# x_(n+1) = x_(n)*a + c
#
# a = 1103515245, c = 59172

scoreboard players operation #LCG tmp *= LCG status
scoreboard players add #LCG tmp 59172
scoreboard players operation Random tmp = #LCG tmp
