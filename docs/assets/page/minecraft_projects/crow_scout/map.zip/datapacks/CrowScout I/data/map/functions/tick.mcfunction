execute as @a at @s run function map:_tick/player
scoreboard players enable @a vote_reset
execute as @a[scores={vote_reset=1..}] run function map:feature/vote/vote_up

# ::: Features
execute if score Power status matches 1 positioned 13 23.5 44 run particle dust 1 0 0 1 ~ ~ ~ 1 0.5 0 1 10 normal @a[distance=..8]
execute if block -2 2 43 campfire[waterlogged=true] run function map:feature/extinguish_campfire
execute if score Heater status matches 0 if block 3 27 41 lever[powered=true] run function map:feature/heater/turn_on
execute if score Heater status matches 1 if block 3 27 41 lever[powered=false] run function map:feature/heater/turn_off


# ::: Timers
execute if score FlashlightCooldown timer matches 1.. run scoreboard players remove FlashlightCooldown timer 1
execute if score MotionSensorCooldown timer matches 1.. run scoreboard players remove MotionSensorCooldown timer 1
execute if score SensorCooldown timer matches 1.. run scoreboard players remove SensorCooldown timer 1
execute if score BearTrapCooldown timer matches 1.. run scoreboard players remove BearTrapCooldown timer 1
execute if score AttackCooldown timer matches 1.. run scoreboard players remove AttackCooldown timer 1
execute as @e[type=item_display,tag=used_bear_trap] run function map:feature/bear_trap/timer

scoreboard players remove 1s timer 1
execute if score 1s timer matches ..-1 run function map:timer/1s

scoreboard players remove 5s timer 1
execute if score 5s timer matches ..-1 run function map:timer/5s

scoreboard players remove 30s timer 1
execute if score 30s timer matches ..-1 run function map:timer/30s

# Tasks
execute if score TaskTimer timer matches 1.. run scoreboard players remove TaskTimer timer 1
execute if score TaskTimer timer matches 400 if score Task status matches 1.. run playsound crowscout:block.clock_ticking master @a[team=neighbor] 0 0 0 1024 1 1
execute if score TaskTimer timer matches 200 if score Task status matches 1.. run playsound crowscout:block.clock_ticking master @a[team=neighbor] 0 0 0 1024 1 1
execute if score TaskTimer timer matches 0 as @p[team=neighbor] run function map:feature/tasks/task_timeout
execute if score TaskCooldown timer matches 1.. run scoreboard players remove TaskCooldown timer 1
execute if score TaskCooldown timer matches 0 as @p[team=neighbor] run function map:feature/tasks/new_task
execute store result bossbar task value run scoreboard players get TaskTimer timer

execute as @e[type=item_frame] unless data entity @s Item.id run kill @s
