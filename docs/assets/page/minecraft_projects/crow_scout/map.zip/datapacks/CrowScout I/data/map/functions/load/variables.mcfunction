scoreboard players set PowerOutage status 0
scoreboard players set Power status 1
scoreboard players set Heater status 1
scoreboard players set NoVents status 0
scoreboard players set FlashOn status 0
scoreboard players set FlashBattery status 0
scoreboard players set TaskTimer timer 600
scoreboard players set TaskCooldown timer 1
scoreboard players set FlashlightCooldown timer 0
scoreboard players set MotionSensorCooldown timer 0
scoreboard players set SensorCooldown timer 0
scoreboard players operation Lifes status = RequiredDeaths status
scoreboard players set Task status 0

scoreboard players set Pin0 status 1
scoreboard players set Pin1 status 0
scoreboard players set Pin2 status 0
scoreboard players set Pin3 status 0
scoreboard players set Pin4 status 0

# ::: Secret digit
summon marker 0 0 0 {Tags: ["secret_digit"], data: {number: 0}}
summon marker 0 0 0 {Tags: ["secret_digit"], data: {number: 1}}
summon marker 0 0 0 {Tags: ["secret_digit"], data: {number: 2}}
summon marker 0 0 0 {Tags: ["secret_digit"], data: {number: 3}}
summon marker 0 0 0 {Tags: ["secret_digit"], data: {number: 4}}
summon marker 0 0 0 {Tags: ["secret_digit"], data: {number: 5}}
summon marker 0 0 0 {Tags: ["secret_digit"], data: {number: 6}}
summon marker 0 0 0 {Tags: ["secret_digit"], data: {number: 7}}
summon marker 0 0 0 {Tags: ["secret_digit"], data: {number: 8}}
summon marker 0 0 0 {Tags: ["secret_digit"], data: {number: 9}}

execute as @e[type=marker,tag=secret_digit,limit=1,sort=random] store result score SecretDigit1 status run data get entity @s data.number
execute as @e[type=marker,tag=secret_digit,limit=1,sort=random] store result score SecretDigit2 status run data get entity @s data.number
execute as @e[type=marker,tag=secret_digit,limit=1,sort=random] store result score SecretDigit3 status run data get entity @s data.number
execute as @e[type=marker,tag=secret_digit,limit=1,sort=random] store result score SecretDigit4 status run data get entity @s data.number
kill @e[type=marker,tag=secret_digit]

gamerule sendCommandFeedback false
