scoreboard players set TaskTimer timer -1
bossbar set task visible false
kill @e[type=item_display,tag=task]

execute if score Task status matches 1 run function map:feature/tasks/_punish/kitchen
execute if score Task status matches 2 run function map:feature/tasks/_punish/power_outage
execute if score Task status matches 3 run function map:feature/tasks/_punish/sleep
execute if score Task status matches 4 run function map:feature/tasks/_punish/refresh_water
execute if score Task status matches 5 run function map:feature/tasks/_punish/storage
execute if score Task status matches 6 run function map:feature/tasks/_punish/graveyard

playsound entity.ender_dragon.flap block @s ~ ~ ~ 1024 1 1
effect give @s blindness 1 0 true
scoreboard players set Task status 0
