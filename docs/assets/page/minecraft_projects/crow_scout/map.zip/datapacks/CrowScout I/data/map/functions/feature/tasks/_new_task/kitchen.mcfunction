bossbar set task name {"translate":"task.crowscout.kitchen"}
scoreboard players set Task status 1
scoreboard players set Time tmp 1200

summon item_display -16.5 2.5 30.5 {Tags: ["crowscout", "map", "task"], item: {id: "minecraft:fire_charge", Count: 1b}, billboard: "center", Glowing: 1b}
setblock -17 2 30 blast_furnace[facing=east,lit=true]
data remove block -17 2 30 Lock
data modify block -17 2 30 Items set value [{id: "minecraft:bread", Count: 1b, Slot: 2b}]
