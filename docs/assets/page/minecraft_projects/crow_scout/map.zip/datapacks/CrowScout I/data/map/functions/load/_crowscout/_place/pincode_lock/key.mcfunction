execute store result score @s id run scoreboard players add #PIN_KeyID tmp 1
data merge entity @s {Tags: ["crowscout", "map", "pincode_lock"], width: 0.15f, height: 0.22f, response: 1b}
tp @s ^ ^.125 ^.44 ~ ~
