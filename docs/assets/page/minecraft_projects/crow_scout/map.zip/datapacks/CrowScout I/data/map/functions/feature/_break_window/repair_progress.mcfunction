scoreboard players add @s timer 1
particle ash ~ ~.5 ~ 0.2 0.2 0.2 1 4 normal @a
execute if score @s timer matches 30.. run function map:feature/_break_window/repair
