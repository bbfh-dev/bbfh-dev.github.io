execute at @e[type=interaction,tag=closet,distance=..5,limit=1,sort=nearest] run tp @s ^ ^.4 ^1 ~180 ~
gamemode adventure @s
playsound block.wooden_door.open block @s ~ ~ ~ 1 1 0
playsound entity.horse.saddle block @s ~ ~ ~ 1 1 0
