gamemode spectator @p[tag=this.player]
spectate @s @p[tag=this.player]
playsound entity.horse.saddle block @p[tag=this.player] ~ ~ ~ 1 1 0
