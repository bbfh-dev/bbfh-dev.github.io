execute unless block ~ ~ ~ #minecraft:air run scoreboard players set #Limit tmp 0
execute if entity @p[team=player,distance=...5] run function the_library:ai/_raycast/hit

scoreboard players remove #Limit tmp 1
execute if score #Limit tmp matches 1.. positioned ^ ^ ^.25 run function the_library:ai/raycast
