advancement revoke @s only map:neighbor/task/sleep

function map:feature/tasks/complete_task
