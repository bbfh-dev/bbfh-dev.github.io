scoreboard players add #MonitorID tmp 1
execute summon item_display run function map:load/_crowscout/_place/camera_monitor/display
execute summon interaction run function map:load/_crowscout/_place/camera_monitor/hitbox
execute summon text_display run function map:load/_crowscout/_place/camera_monitor/text
