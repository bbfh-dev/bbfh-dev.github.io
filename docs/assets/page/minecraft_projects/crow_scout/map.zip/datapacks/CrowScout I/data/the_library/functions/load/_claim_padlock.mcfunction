tag @s remove map
tag @s add dream
