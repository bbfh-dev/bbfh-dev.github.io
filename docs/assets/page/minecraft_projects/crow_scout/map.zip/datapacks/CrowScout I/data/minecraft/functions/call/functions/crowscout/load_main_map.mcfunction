tellraw @a ["", {"nbt":"Logger", "storage":"crowscout", "interpret": true}, "Loading the main map..."]

# ::: Bossbar
bossbar set crowscout players @a
bossbar set crowscout value 0
bossbar set crowscout max 2
bossbar set crowscout name "Loading the chunks..."
bossbar set crowscout visible true

forceload add -96 -96 96 96
bossbar set crowscout value 1
bossbar set crowscout name "Verifying the chunks"
function call:crowscout/_load_main_map/verify_chunks
