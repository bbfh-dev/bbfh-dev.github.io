setblock -2 2 43 air
setblock -2 1 43 campfire[lit=false]
