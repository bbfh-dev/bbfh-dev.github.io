data merge entity @s {Tags: ["crowscout", "map", "camera_view"], ActiveEffects: [{Id: 14, Duration: -1, ShowParticles: 0b, Ambient: 0b, Amplifier: 0b}, {Id: 11, Duration: -1, ShowParticles: 0b, Ambient: 0b, Amplifier: 127b}], Silent: 1b, PersistenceRequired: 1b, NoAI: 1b, NoGravity: 1b}
scoreboard players operation @s id = #CameraID tmp
tp @s ~ ~ ~ ~ ~
