execute unless score FlashBattery status matches 1.. run function map:feature/_flash_light/attempt_to_charge
execute if score FlashBattery status matches 1.. anchored eyes positioned ^ ^ ^.5 run function map:feature/flash_light
