advancement revoke @s only map:neighbor/task/refresh_water

function map:feature/tasks/complete_task
