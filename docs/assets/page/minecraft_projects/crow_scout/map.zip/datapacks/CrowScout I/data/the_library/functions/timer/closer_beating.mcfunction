scoreboard players set CloserBeating timer 10
execute if score WardenChasing timer matches 1.. if entity @p[team=player,distance=4.01..8] run playsound entity.warden.nearby_closer hostile @a ~ ~ ~ 1 1.1 0
