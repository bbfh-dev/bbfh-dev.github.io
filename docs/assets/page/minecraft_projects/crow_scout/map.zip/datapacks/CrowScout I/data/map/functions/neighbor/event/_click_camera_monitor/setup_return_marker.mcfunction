tag @s add neighbor_return_marker
execute at @p[tag=this.player] run tp @s ~ ~ ~ ~ ~
