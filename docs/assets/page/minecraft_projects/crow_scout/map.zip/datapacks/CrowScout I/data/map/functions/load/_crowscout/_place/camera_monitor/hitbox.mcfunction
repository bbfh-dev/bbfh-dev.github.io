data merge entity @s {Tags: ["crowscout", "map", "camera_monitor"], width: 0.9f, height: 0.6f, response: 1b}
scoreboard players operation @s id = #MonitorID tmp
tp @s ^ ^.2 ^-0.7 ~ ~
