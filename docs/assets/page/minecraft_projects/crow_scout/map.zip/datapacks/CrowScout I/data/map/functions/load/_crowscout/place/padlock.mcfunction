execute summon item_display run function map:load/_crowscout/_place/padlock/display
execute summon interaction run function map:load/_crowscout/_place/padlock/hitbox
