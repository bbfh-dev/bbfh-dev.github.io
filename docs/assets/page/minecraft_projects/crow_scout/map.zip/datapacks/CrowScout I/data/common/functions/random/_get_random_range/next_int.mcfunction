###
#    public int nextInt(int bound) {
#        if (bound <= 0)
#            throw new IllegalArgumentException(BadBound);
#
#        int r = next(31);
#        int m = bound - 1;
#        if ((bound & m) == 0)  // i.e., bound is a power of 2
#            r = (int)((bound * (long)r) >> 31);
#        else {
#            for (int u = r; u - (r = u % bound) + m < 0; u = next(31));
#        }
#        return r;
#    }

function common:random/_get_random_range/lcg

scoreboard players operation #temp tmp = Random tmp
scoreboard players operation Random tmp %= #range tmp
scoreboard players operation #temp tmp -= Random tmp
scoreboard players operation #temp tmp += #m1 tmp
execute if score #temp tmp matches ..-1 run function common:random/_get_random_range/next_int
