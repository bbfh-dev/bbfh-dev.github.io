execute as @s[tag=variant_1] run function map:load/chunks/variant_1
execute as @s[tag=variant_2] run function map:load/chunks/variant_2
execute as @s[tag=variant_3] run function map:load/chunks/variant_3
execute as @s[tag=variant_4] run function map:load/chunks/variant_4
execute as @s[tag=variant_5] run function map:load/chunks/variant_5
execute as @s[tag=variant_6] run function map:load/chunks/variant_6

# ::: Launch
schedule function map:load/chunks/fix_paintings 10t
schedule function map:load/chunks/clear_paintings 6s
