data merge entity @s {Tags: ["crowscout", "map", "closet"], item: {id: "minecraft:spawner", Count: 1b, tag: {CustomModelData: 7}}, width: 1f, height: 2f, item_display: "head", transformation: {translation: [0f, -1.5f, 0f]}}
tp @s ~ ~1.5 ~ ~ ~
