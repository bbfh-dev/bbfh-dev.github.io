execute if score Power status matches 0 run data modify entity @s item.tag.CustomModelData set value 3
execute if score Power status matches 1 run data modify entity @s item.tag.CustomModelData set value 2
playsound block.anvil.place block @a ~ ~ ~ 0.2 1 0
tag @s remove is_broken
