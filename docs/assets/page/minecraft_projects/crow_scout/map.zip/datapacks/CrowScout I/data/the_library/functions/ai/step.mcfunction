scoreboard players set #Limit tmp 60
execute facing entity @p[team=player] feet run function the_library:ai/raycast
