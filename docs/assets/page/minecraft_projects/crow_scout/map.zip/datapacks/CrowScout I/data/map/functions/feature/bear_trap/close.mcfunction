execute as @e[type=item_display,tag=bear_trap,distance=..1,sort=nearest,limit=1] run function map:feature/bear_trap/_close/display
playsound crowscout:block.bear_trap block @a ~ ~ ~ 1 1 0
particle item spawner{CustomModelData: 12} ~ ~.5 ~ 0.2 0.2 0.2 0.05 25
kill @s
