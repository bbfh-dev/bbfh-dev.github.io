stopsound @a * block.beacon.deactivate
stopsound @a * block.beacon.activate
playsound crowscout:block.light_zap block @a 11 18 57 0.5 1 0.5
playsound block.beacon.activate block @a 11 18 57 0.5 2 0.5

fill -22 0 28 19 26 62 lantern[hanging=true] replace lightning_rod[facing=down]
fill -22 0 28 19 26 62 lantern[hanging=false] replace lightning_rod[facing=up]
fill -20 -2 39 -29 -2 49 redstone_lamp[lit=true] replace redstone_lamp[lit=false]
fill 11 22 44 15 24 44 barrier replace air

execute as @e[type=item_display,tag=camera,nbt={item: {tag: {CustomModelData: 3}}}] run data modify entity @s item.tag.CustomModelData set value 2

scoreboard players set Power status 1
execute if score PowerOutage status matches 1 run function common:event/_click_electrical_box/turn_off
