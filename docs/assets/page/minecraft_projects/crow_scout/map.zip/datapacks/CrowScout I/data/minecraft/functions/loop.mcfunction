execute if score Mode status matches -1 run function map:_end_game/cutscene
execute if score Mode status matches 0 run function lobby:tick
execute if score Mode status matches 1 run function map:tick
execute if score Mode status matches 2 run function the_library:tick
execute as @e[type=item,tag=!marked] run function minecraft:reset_item

scoreboard players reset @a leave_game

effect give @a resistance infinite 255 true
effect give @a regeneration infinite 255 true
effect give @a[tag=!is_hungry] saturation 2 0 true
