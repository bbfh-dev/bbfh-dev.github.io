advancement revoke @s only map:neighbor/task/kitchen

function map:feature/tasks/complete_task

setblock -17 2 30 blast_furnace[facing=east,lit=false]
data modify block -17 2 30 Lock set value "LOCKED"
clear @s bread
