stopsound @a * block.beacon.deactivate
stopsound @a * block.beacon.activate
playsound crowscout:block.light_zap block @a 11 18 57 0.5 1 0.5
playsound block.beacon.deactivate block @a 11 18 57 0.5 2 0.5

fill -22 0 28 19 26 62 lightning_rod[facing=down] replace lantern[hanging=true]
fill -22 0 28 19 26 62 lightning_rod[facing=up] replace lantern[hanging=false]
fill -20 -2 39 -29 -2 49 redstone_lamp[lit=false] replace redstone_lamp[lit=true]
fill 11 22 44 15 24 44 air replace barrier

execute as @e[type=item_display,tag=camera,nbt={item: {tag: {CustomModelData: 2}}}] run data modify entity @s item.tag.CustomModelData set value 3
execute as @a[team=neighbor,gamemode=spectator] run function map:neighbor/event/_click_camera_monitor/leave

scoreboard players set Power status 0
