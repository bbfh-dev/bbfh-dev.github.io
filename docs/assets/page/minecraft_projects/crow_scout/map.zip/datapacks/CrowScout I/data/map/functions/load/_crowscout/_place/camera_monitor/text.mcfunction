scoreboard players operation @s id = #MonitorID tmp
execute as @e[type=cave_spider,tag=camera_view] if score @s id = #MonitorID tmp run function map:load/_crowscout/_place/camera_monitor/_text/get_text_value
data merge entity @s {Tags: ["crowscout", "map", "camera_monitor"], width: 1.0f, height: 1.0f, text: '["", {"text":"Camera #", "color":"green", "extra":[{"score":{"name":"@s", "objective":"id"}}]}, "\\n", {"text":"Floor #", "extra":[{"score":{"name":"#Floor", "objective":"tmp"}}]}]', transformation: {scale: [0.5f, 0.5f, 0.5f]}, background: 0, line_width: 70}
tp @s ^ ^.375 ^-0.24 ~ ~
