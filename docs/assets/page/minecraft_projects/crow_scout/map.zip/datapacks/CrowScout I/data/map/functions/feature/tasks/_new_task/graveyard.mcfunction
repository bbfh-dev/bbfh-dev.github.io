bossbar set task name {"translate":"task.crowscout.graveyard"}
scoreboard players set Task status 6
scoreboard players set Time tmp 1800

summon item_display -9 -3 79 {Tags: ["crowscout", "map", "task"], item: {id: "minecraft:fire_charge", Count: 1b}, billboard: "center", Glowing: 1b}
