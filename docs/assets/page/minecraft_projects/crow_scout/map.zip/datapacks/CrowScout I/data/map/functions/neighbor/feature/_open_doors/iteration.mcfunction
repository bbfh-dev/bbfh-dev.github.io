setblock ~ ~-1 ~ redstone_block
summon marker ~ ~-1 ~ {Tags: ["crowscout", "map", "open_doors_feature"]}
schedule function map:neighbor/feature/_open_doors/close_doors 1s
