scoreboard players set 1s timer 20

# ::: Breaking windows
execute unless entity @p[team=player,tag=inside_of_a_window] run scoreboard players set BreakingWindow timer 0
execute if entity @p[team=player,tag=inside_of_a_window] at @p[team=player,tag=inside_of_a_window] run function map:feature/break_window
execute if entity @p[team=neighbor,tag=inside_of_a_window] at @p[team=neighbor,tag=inside_of_a_window] run function map:feature/_break_window/break
execute as @e[type=marker,tag=broken_glass] at @s run function map:feature/_break_window/repair_progress
