scoreboard players set CloseBeating timer 15
execute if score WardenChasing timer matches 1.. if entity @p[team=player,distance=9..] run playsound entity.warden.nearby_close hostile @a ~ ~ ~ 1 1 0
playsound entity.warden.step block @a ~ ~ ~ 1 1 0
fill ~-2 ~-1 ~-2 ~2 ~-1 ~2 redstone_block replace mud_bricks
fill ~-2 ~-1 ~-2 ~2 ~-1 ~2 mud_bricks replace redstone_block

execute store result score #PosX status run data get entity @s Pos[0] 10
execute store result score #PosY status run data get entity @s Pos[1] 10
execute store result score #PosZ status run data get entity @s Pos[2] 10
execute if score #PosX status = #PosX_Before status if score #PosY status = #PosY_Before status if score #PosZ status = #PosZ_Before status run function the_library:ai/select_new_location
scoreboard players operation #PosX_Before status = #PosX status
scoreboard players operation #PosY_Before status = #PosY status
scoreboard players operation #PosZ_Before status = #PosZ status
