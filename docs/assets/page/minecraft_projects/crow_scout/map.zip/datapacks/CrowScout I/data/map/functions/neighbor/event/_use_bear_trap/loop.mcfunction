execute if block ^ ^ ^.25 #map:bear_trap_suitable align xyz positioned ~.5 ~ ~.5 unless entity @e[type=item_display,tag=bear_trap,distance=..1] run function map:neighbor/event/_use_bear_trap/place

scoreboard players remove #Limit tmp 1
execute if score #Limit tmp matches 1.. positioned ^ ^ ^.25 run function map:neighbor/event/_use_bear_trap/loop
