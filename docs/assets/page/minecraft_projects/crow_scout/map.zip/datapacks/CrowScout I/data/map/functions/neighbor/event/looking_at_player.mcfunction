advancement revoke @s only map:neighbor/looking_at_player

stopsound @a * crowscout:music.main_theme
effect give @p[team=player] glowing 6 0 true
playsound crowscout:music.attack_theme master @a ~ ~ ~ 1024 1 1
effect give @a[team=player] blindness 1 0 true
execute unless score AttackCooldown timer matches 1.. run playsound crowscout:entity.gasp master @a ~ ~ ~ 1024 1 1
scoreboard players set AttackCooldown timer 300
effect give @s speed 6 1 true
