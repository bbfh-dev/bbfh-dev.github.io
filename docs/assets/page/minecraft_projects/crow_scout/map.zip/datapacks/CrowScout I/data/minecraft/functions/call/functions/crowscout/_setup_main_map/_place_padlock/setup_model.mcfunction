scoreboard players set #Model world 12
scoreboard players operation #Model world += #PadlockID block_id
data merge entity @s {Tags: ["crowscout", "padlock"], item: {id: "minecraft:spawner", Count: 1b, tag: {CustomModelData: 13}}, transformation: {translation: [0f, 0.5f, 0f]}, width: 1.0f, height: 1.0f}
execute store result entity @s item.tag.CustomModelData int 1 run scoreboard players get #Model world
scoreboard players operation @s block_id = #PadlockID block_id
tp @s ~ ~ ~ ~180 ~
