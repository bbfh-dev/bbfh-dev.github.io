execute as @e[type=item_display,tag=camera] if score @s id = @e[type=interaction,tag=this.hitbox,limit=1] id store result score #Model tmp run data get entity @s item.tag.CustomModelData
execute if score #Model tmp matches 2 run function map:neighbor/event/_click_camera_monitor/spectate
execute if score #Model tmp matches 3..4 run function map:neighbor/event/_click_camera_monitor/not_available
