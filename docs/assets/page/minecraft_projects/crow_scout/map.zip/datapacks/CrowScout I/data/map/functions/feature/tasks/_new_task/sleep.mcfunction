bossbar set task name {"translate":"task.crowscout.sleep"}
scoreboard players set Task status 3
scoreboard players set Time tmp 1800

summon item_display 16.5 12.0 53.5 {Tags: ["crowscout", "map", "task"], item: {id: "minecraft:fire_charge", Count: 1b}, billboard: "center", Glowing: 1b}
