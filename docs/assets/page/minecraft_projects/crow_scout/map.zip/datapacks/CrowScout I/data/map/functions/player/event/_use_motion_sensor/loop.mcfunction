execute if block ^ ^ ^.25 #map:bear_trap_suitable align xyz positioned ~.5 ~ ~.5 unless entity @e[type=item_display,tag=motion_sensor,distance=..1] run function map:player/event/_use_motion_sensor/place

scoreboard players remove #Limit tmp 1
execute if score #Limit tmp matches 1.. positioned ^ ^ ^.25 run function map:player/event/_use_motion_sensor/loop
