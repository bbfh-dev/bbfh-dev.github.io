advancement revoke @s only map:common/hit_camera

tag @s add this.player
execute anchored eyes positioned ^ ^ ^2 as @e[type=item_display,tag=camera,distance=..2] run function common:event/_hit_camera/check
tag @s remove this.player
