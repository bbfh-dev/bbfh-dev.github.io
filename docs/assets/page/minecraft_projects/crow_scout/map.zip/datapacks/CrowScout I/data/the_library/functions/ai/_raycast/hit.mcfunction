scoreboard players set #Limit tmp 0
execute unless score WardenChasing timer matches 1.. run playsound entity.warden.sonic_boom block @a ^ ^ ^-3 1 1 0
execute unless score WardenTheme timer matches 1.. run stopsound @a * crowscout:music.attack_theme_stay
execute unless score WardenTheme timer matches 1.. run playsound crowscout:music.attack_theme_stay master @a ~ ~ ~ 1 1 1
execute unless score WardenTheme timer matches 1.. run scoreboard players set WardenTheme timer 100
scoreboard players set WardenChasing timer 40
execute as @p[team=player] run function the_library:ai/follow_this_entity
attribute @e[type=wandering_trader,tag=ai,limit=1] generic.movement_speed base set 1.25
data modify entity @e[type=warden,limit=1] Silent set value 1b
