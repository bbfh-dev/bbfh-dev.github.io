tp @e[type=warden] ~ ~ ~ ~ ~
execute positioned ^ ^ ^1 if entity @p[team=player,distance=..2] run function the_library:setup

# ::: Timers
execute if score WardenAI timer matches 1.. run scoreboard players remove WardenAI timer 1
execute if score WardenAI timer matches ..0 run function the_library:timer/warden_ai
execute if score WardenChasing timer matches 1.. run scoreboard players remove WardenChasing timer 1
execute if score WardenTheme timer matches 1.. run scoreboard players remove WardenTheme timer 1
execute if score WardenChoose timer matches 1.. run scoreboard players remove WardenChoose timer 1

execute if score CloseBeating timer matches 1.. run scoreboard players remove CloseBeating timer 1
execute if score CloserBeating timer matches 1.. run scoreboard players remove CloserBeating timer 1
execute if score ClosestBeating timer matches 1.. run scoreboard players remove ClosestBeating timer 1
execute if score CloseBeating timer matches ..0 run function the_library:timer/close_beating
execute if score CloserBeating timer matches ..0 run function the_library:timer/closer_beating
execute if score ClosestBeating timer matches ..0 run function the_library:timer/closest_beating
execute if score WardenChoose timer matches ..0 run function the_library:ai/select_new_location
