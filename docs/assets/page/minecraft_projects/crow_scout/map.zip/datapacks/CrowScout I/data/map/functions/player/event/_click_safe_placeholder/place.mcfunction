data merge entity @s {Tags: ["crowscout", "map", "safe_key"], item: {id: "minecraft:spawner", Count: 1b, tag: {CustomModelData: 16}}, width: 1f, height: 1f, item_display: "head", Rotation: [180f, 0f], brightness: {block: 15, sky: 15}}
execute if entity @e[type=interaction,tag=this.hitbox,tag=spot_1,limit=1] run tp @s ^-.25 ^.5 ^-.5 ~90 ~90
execute if entity @e[type=interaction,tag=this.hitbox,tag=spot_2,limit=1] run tp @s ^-.375 ^.5 ^-.375 ~ ~
execute if entity @e[type=interaction,tag=this.hitbox,tag=spot_3,limit=1] run tp @s ^-.25 ^.5 ^-.5 ~90 ~90
execute if entity @e[type=interaction,tag=this.hitbox,tag=spot_4,limit=1] run tp @s ^-.375 ^.5 ^-.375 ~ ~
