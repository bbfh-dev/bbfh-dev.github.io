advancement revoke @s only map:neighbor/outside_house

effect give @s weakness 1 128 true
