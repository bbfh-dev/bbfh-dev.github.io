advancement revoke @s only map:neighbor/task/storage

function map:feature/tasks/complete_task
