execute store result score #Model tmp run data get entity @s item.tag.CustomModelData
execute if score #Model tmp matches 2..3 if entity @p[tag=this.player,team=player] at @s run function common:event/_hit_camera/break
execute if score #Model tmp matches 4 if entity @p[tag=this.player,team=neighbor] at @s run function common:event/_hit_camera/repair
