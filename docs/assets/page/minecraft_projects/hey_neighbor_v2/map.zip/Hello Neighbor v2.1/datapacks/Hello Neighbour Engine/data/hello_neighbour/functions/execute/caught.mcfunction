effect give @p[team=tm.player] minecraft:slowness 8 128 true
effect give @p[team=tm.player] minecraft:jump_boost 8 128 true
effect give @p[team=tm.player] minecraft:glowing 8 128 true

summon minecraft:evoker_fangs ~ ~ ~

stopsound @a * minecraft:hello_neighbor.rush
playsound minecraft:hello_neighbor.rush voice @a 0 228 0 228 1 1
effect give @a[team=tm.neighbour] minecraft:speed 19 0 true

kill @s
