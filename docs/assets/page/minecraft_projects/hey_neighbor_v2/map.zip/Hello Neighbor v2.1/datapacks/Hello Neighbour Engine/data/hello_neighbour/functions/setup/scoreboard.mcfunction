scoreboard objectives add tm.used minecraft.used:minecraft.carrot_on_a_stick "Использовано"
scoreboard objectives add hello_neighbour dummy "Привет Сосед"
scoreboard objectives add tm.time dummy "Тайминги"
scoreboard objectives add tm.y dummy

team leave @a
scoreboard players set game hello_neighbour 0

scoreboard objectives add neighbour trigger
scoreboard objectives add player trigger

scoreboard objectives add death deathCount
scoreboard players set @a death 0
