execute if score lit hello_neighbour matches 1 run stopsound @a * minecraft:hello_neighbor.rush
execute if score lit hello_neighbour matches 1 run playsound minecraft:hello_neighbor.rush voice @a 0 228 0 228 1 1
execute if score lit hello_neighbour matches 1 run playsound minecraft:hello_neighbor.cam voice @a ~ ~ ~ 228 1 0
execute if score lit hello_neighbour matches 1 run effect give @a[team=tm.neighbour] minecraft:speed 19 0 true
