scoreboard players set @a death -1
kill @a
scoreboard players set game hello_neighbour 1
