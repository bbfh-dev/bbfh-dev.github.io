tag @s remove hiden

execute if entity @e[tag=24_14, distance=..2] run tp @s 23.5 20 14.5 90 0
execute if entity @e[tag=25_-14, distance=..2] run tp @s 25.5 20 -13.5 0 0
execute if entity @e[tag=28_-13, distance=..2] run tp @s 29.5 20 -13.5 -90 0

gamemode adventure @s
