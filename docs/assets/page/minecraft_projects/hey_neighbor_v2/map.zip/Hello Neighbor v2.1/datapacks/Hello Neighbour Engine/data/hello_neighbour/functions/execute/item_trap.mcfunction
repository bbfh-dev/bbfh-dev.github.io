summon minecraft:armor_stand ~.5 ~ ~.5 {Tags:["entity.trap"], Invisible:1, Invulnerable:1, Silent:1, Marker:1, Small:1}
kill @s
