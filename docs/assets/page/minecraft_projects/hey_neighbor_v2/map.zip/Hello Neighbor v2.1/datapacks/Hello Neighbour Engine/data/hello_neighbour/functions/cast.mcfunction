scoreboard players set @e[tag=entity.cast] hello_neighbour 0

execute as @e[tag=entity.cam] at @s run summon minecraft:area_effect_cloud ~ ~ ~ {Duration:999999, Tags:["entity.cast"]}
execute as @e[tag=entity.cast] at @s at @e[tag=entity.cam, limit=1, sort=nearest] anchored eyes positioned ~ ~1 ~ run tp @s ~ ~ ~ ~ ~
execute as @e[tag=entity.cast] at @s run function hello_neighbour:execute/cam

execute as @e[tag=entity.cam] at @s anchored eyes positioned ~ ~1 ~ if entity @e[type=item, distance=...6] run effect give @p[team=tm.player] glowing 2 0 true
execute as @e[tag=entity.cam] at @s anchored eyes positioned ~ ~1 ~ if entity @e[type=item, distance=...6] run playsound minecraft:hello_neighbor.destroy voice @a ~ ~ ~ 228 1 0
execute as @e[tag=entity.cam] at @s anchored eyes positioned ~ ~1 ~ if entity @e[type=item, distance=...6] run kill @s