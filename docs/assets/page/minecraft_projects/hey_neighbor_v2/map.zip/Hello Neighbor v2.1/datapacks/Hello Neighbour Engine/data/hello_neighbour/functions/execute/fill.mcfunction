fill 30 20 0 30 22 0 minecraft:iron_bars[east=true, west=true] replace air
fill 29 20 0 29 22 0 minecraft:iron_bars[east=true, north=true] replace air
fill 29 20 -1 29 22 -1 minecraft:iron_bars[north=true, south=true] replace air
fill 30 20 -2 30 22 -2 minecraft:iron_bars[east=true, west=true] replace air
fill 29 20 -2 29 22 -2 minecraft:iron_bars[east=true, south=true] replace air
