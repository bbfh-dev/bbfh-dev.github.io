# summon minecraft:area_effect_cloud 24.5 20 14.5 {Duration:19999999, Rotation:[90.0f, 0.0f], NoGravity:1, Invulnerable:1, Invisible:1, Tags:["24.20.14", "hide"]}
particle minecraft:dust 1 0.5 0.5 10 ~ ~1 ~ 0 .4 0 0 5 normal

execute if block ~ ~ ~ minecraft:dark_oak_door[open=true, facing=west] run setblock ~ ~ ~ minecraft:dark_oak_door[open=false, facing=west]
execute if block ~ ~ ~ minecraft:dark_oak_door[open=true, facing=east] run setblock ~ ~ ~ minecraft:dark_oak_door[open=false, facing=east]
execute if block ~ ~ ~ minecraft:dark_oak_door[open=true, facing=north] run setblock ~ ~ ~ minecraft:dark_oak_door[open=false, facing=north]
execute if block ~ ~ ~ minecraft:dark_oak_door[open=true, facing=south] run setblock ~ ~ ~ minecraft:dark_oak_door[open=false, facing=south]

tag @s add hiden
gamemode spectator
execute at @e[tag=hide, limit=1, sort=nearest] run tp @s ~ ~ ~ ~ ~
tellraw @s ["",{"text":"\u0418\u0441\u043f\u043e\u043b\u044c\u0437\u0443\u0439\u0442\u0435 ","color":"green"},{"keybind":"key.sneak","color":"yellow"},{"text":" \u0447\u0442\u043e\u0431\u044b \u0432\u044b\u0439\u0442\u0438","color":"green"}]
