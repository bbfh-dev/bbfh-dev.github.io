scoreboard players add @s hello_neighbour 1
execute unless block ^ ^ ^0.5 #hello_neighbour:wall run tp @s ^ ^ ^0.5

scoreboard players set success hello_neighbour 0

particle minecraft:dust 0.4 0.4 0.4 1 ~ ~ ~ 0 0 0 0 0 normal @a[team=tm.neighbour]
execute if score lit hello_neighbour matches 1 at @s as @p[team=tm.player, distance=..1.5, nbt=!{ActiveEffects:[{Id:24b}]}] store success score success hello_neighbour run effect give @s minecraft:glowing 5 0 true
execute at @s if score success hello_neighbour matches 1 run function hello_neighbour:execute/cam_2

execute at @s unless block ^ ^ ^0.5 #hello_neighbour:wall if score @s hello_neighbour matches ..31 run function hello_neighbour:execute/tp
