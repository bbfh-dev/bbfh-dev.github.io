team join tm.player @p
spawnpoint @p -17 28 5
tellraw @a [{"selector":"@p", "color":"yellow"}, {"text":" >> ", "color":"gray"}, {"text":"Стал игроком", "color":"white"}]
scoreboard players reset @s player
tellraw @s [{"text":"Выкинь предмет в камеру чтобы сломать ее\n", "color":"gray"}]
tellraw @s [{"text":"Используй коробки (головы игроков с текстурой коробки) чтобы забиратся в другие места", "color":"gray"}]