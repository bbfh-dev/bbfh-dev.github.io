team join tm.neighbour @p
spawnpoint @p 15 26 15
tellraw @a [{"selector":"@p", "color":"yellow"}, {"text":" >> ", "color":"gray"}, {"text":"Стал соседом", "color":"white"}]
scoreboard players reset @s neighbour
