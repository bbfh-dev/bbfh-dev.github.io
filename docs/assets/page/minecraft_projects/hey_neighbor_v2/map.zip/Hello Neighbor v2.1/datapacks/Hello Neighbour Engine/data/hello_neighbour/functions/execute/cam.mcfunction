execute at @e[tag=entity.cam, limit=1, sort=nearest] anchored eyes positioned ~ ~1 ~ run tp @s ~ ~ ~ ~ ~
function hello_neighbour:execute/tp
kill @s