### give @p minecraft:carrot_on_a_stick{Tags:["item.magnet"], display:{Name:'{"text":"Магнит", "color":"yellow", "italic":false}', Lore:['{"text":"Используйте ПКМ", "color":"gray", "italic":false}', '{"text":"Чтобы притянуть предметы", "color":"gray", "italic":false}']}}
execute as @a[nbt={SelectedItem:{tag:{Tags:["item.magnet"]}}}] if score @s tm.used matches 1.. run tag @s add used.magnet
execute as @a[tag=used.magnet] at @s as @e[type=item, tag=!item, distance=..5] at @s facing entity @p[tag=used.magnet] feet run tp @s ^ ^ ^.5

execute as @a[tag=used.magnet] unless score @s tm.used matches 1.. run tag @s remove used.magnet

### give @p minecraft:scute{Tags:["item.red_key"], display:{Name:'{"text":"Красный Ключ", "color":"gold", "italic":false}', Lore:['{"text":"Выкиньте на замок", "color":"gray", "italic":false}', '{"text":"Чтобы отпереть его", "color":"gray", "italic":false}']}}
### give @p minecraft:scute{Tags:["item.green_key"], display:{Name:'{"text":"Зеленый Ключ", "color":"gold", "italic":false}', Lore:['{"text":"Выкиньте на замок", "color":"gray", "italic":false}', '{"text":"Чтобы отпереть его", "color":"gray", "italic":false}']}}
### give @p minecraft:scute{Tags:["item.yellow_key"], display:{Name:'{"text":"Желтый Ключ", "color":"gold", "italic":false}', Lore:['{"text":"Выкиньте на замок", "color":"gray", "italic":false}', '{"text":"Чтобы отпереть его", "color":"gray", "italic":false}']}}
### give @p minecraft:scute{Tags:["item.blue_key"], display:{Name:'{"text":"Голубой Ключ", "color":"gold", "italic":false}', Lore:['{"text":"Выкиньте на замок", "color":"gray", "italic":false}', '{"text":"Чтобы отпереть его", "color":"gray", "italic":false}']}}

### give @p minecraft:firework_star{Tags:["item.trap"], display:{Name:'{"text":"Ловушка Жопера", "color":"light_purple", "italic":false}', Lore:['{"text":"Установится в точке", "color":"gray", "italic":false}', '{"text":"Падения", "color":"gray", "italic":false}']}}
execute as @e[type=item, nbt={Item:{Count:1b, tag:{Tags:["item.trap"]}}}] align xyz unless entity @e[tag=entity.trap, distance=..1] run tag @s add item
execute as @e[type=item, nbt={Item:{Count:1b, tag:{Tags:["item.trap"]}}, OnGround:1b}, limit=1] at @s align xyz unless entity @e[tag=entity.trap, distance=..1] run function hello_neighbour:execute/item_trap

### give @p minecraft:firework_star{Tags:["item.cam"], display:{Name:'{"text":"Камера Видеонаблюдения", "color":"light_purple", "italic":false}', Lore:['{"text":"Выкиньте чтобы установить", "color":"gray", "italic":false}', '{"text":"Камера примит ваше положение", "color":"gray", "italic":false}', '{"text":"И ваш взгляд", "color":"gray", "italic":false}']}}
execute as @e[type=item, nbt={Item:{Count:1b, tag:{Tags:["item.cam"]}}}, limit=1] at @s at @p[team=tm.neighbour] run function hello_neighbour:execute/item_cam

### give @p minecraft:lantern{Tags:["item.flashlight"], display:{Name:'{"text":"Фонарик", "color":"green", "italic":false}', Lore:['{"text":"* Включите динамическое освещение", "color":"gold", "italic":false}']}}

### give @p minecraft:bucket{Tags:["item.bucket"], display:{Name:'{"text":"Ведро", "color":"yellow", "italic":false}', Lore:['{"text":"Выкиньте в воду", "color":"gray", "italic":false}', '{"text":"Чтобы наполнить", "color":"gray", "italic":false}']}}
execute as @e[type=item, nbt={Item:{tag:{Tags:["item.bucket"]}}}] at @s if block ~ ~-.5 ~ #minecraft:stairs[waterlogged=true] run particle minecraft:bubble ~ ~ ~ 0 0 0 0 1 normal
execute as @e[type=item, nbt={Item:{tag:{Tags:["item.bucket"]}}}] at @s if block ~ ~-.5 ~ #minecraft:stairs[waterlogged=true] run scoreboard players add @s tm.time 1
execute as @e[type=item, nbt={Item:{tag:{Tags:["item.bucket"]}}}, scores={tm.time=200..}] at @s if block ~ ~-.5 ~ #minecraft:stairs[waterlogged=true] run data merge entity @s {Item:{id:"minecraft:water_bucket", tag:{display:{Name:'{"text":"Ведро Воды", "color":"yellow", "italic":false}'}, Tags:["item.water_bucket"]}}}

### give @p minecraft:snowball{Tags:["item.stone"], display:{Name:'{"text":"Камень", "color":"yellow", "italic":false}', Lore:['{"text":"Разбивает окно", "color":"gray", "italic":false}', '{"text":"С неким шансом", "color":"gray", "italic":false}', '{"text":"* По диагонали шанс больше", "color":"gold", "italic":false}']}}
scoreboard players set snowball hello_neighbour 0
execute as @e[type=minecraft:snowball] at @s store success score snowball hello_neighbour run fill ~-.4 ~-.4 ~-.4 ~.4 ~.4 ~.4 air replace white_stained_glass_pane
execute if score snowball hello_neighbour matches 1 run kill @e[type=snowball]

### give @p minecraft:golden_boots{Tags:["slot.boots"], display:{Name:'{"text":"Огнеупорные Ботинки", "color":"gold", "italic":false}', Lore:['{"text":"Если надеть, то", "color":"gray", "italic":false}', '{"text":"Можно и в лаве покупаться", "color":"gray", "italic":false}']}}
execute as @a[nbt={Inventory:[{Slot:100b, tag:{Tags:["slot.boots"]}}]}] at @s run effect give @s minecraft:fire_resistance 1 128 true

### Reset
scoreboard players reset @a tm.used

### Particles
execute as @e[tag=entity.trap] at @s run particle minecraft:witch ~ ~ ~ .2 .2 .2 0 1 normal @a
execute as @e[tag=entity.trap] at @s if entity @p[team=tm.player, distance=...9] run function hello_neighbour:execute/caught

### '{"text":"", "color":"gray", "italic":false}'

### give @p minecraft:player_head{display:{Name:'{"text":"Ящик", "italic":false, "color":"yellow"}', Lore:['{"text":"Используйте чтобы забраться", "italic":false, "color":"gray"}']}, CanDestroy:["player_head"], CanPlaceOn:["grass_block", "spruce_planks", "birch_planks", "player_head"], SkullOwner:{Id:"ab92d0bd-2e1f-4783-821e-00d97b86d93a",Properties:{textures:[{Value:"eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvZWYyNTg0OWU4Y2Q1ZTUzMmMzMGNiYThkZThiZWQwNjQwY2ZiMmVlYzUwOTI5OTk4YjEwNzgzOWJmYjBmMjRkNyJ9fX0="}]}}}

execute as @e[type=item, nbt={Item:{tag:{SkullOwner:{Id:"ab92d0bd-2e1f-4783-821e-00d97b86d93a",Properties:{textures:[{Value:"eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvZWYyNTg0OWU4Y2Q1ZTUzMmMzMGNiYThkZThiZWQwNjQwY2ZiMmVlYzUwOTI5OTk4YjEwNzgzOWJmYjBmMjRkNyJ9fX0="}]}}}}}] run data merge entity @s {Item:{tag:{display:{Name:'{"text":"Ящик", "italic":false, "color":"yellow"}', Lore:['{"text":"Используйте чтобы забраться", "italic":false, "color":"gray"}']}, CanDestroy:["player_head"], CanPlaceOn:["grass_block", "spruce_planks", "birch_planks", "player_head"]}}}
