team add tm.player "Игрок"
team add tm.neighbour "Сосед"
team add tm.entity "Камера"

team modify tm.player color green
team modify tm.player friendlyFire false
team modify tm.player nametagVisibility never
team modify tm.player seeFriendlyInvisibles false

team modify tm.neighbour color red
team modify tm.neighbour friendlyFire false
team modify tm.neighbour nametagVisibility never
team modify tm.neighbour seeFriendlyInvisibles false

team modify tm.entity color yellow
team modify tm.entity friendlyFire false
team modify tm.entity nametagVisibility never
team modify tm.entity seeFriendlyInvisibles false
team modify tm.entity collisionRule never
