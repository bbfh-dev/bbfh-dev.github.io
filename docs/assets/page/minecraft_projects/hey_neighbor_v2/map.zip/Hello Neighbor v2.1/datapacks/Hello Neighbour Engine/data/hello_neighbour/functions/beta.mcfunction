execute as @a[team=tm.player] if score @s death matches 20.. run title @a title {"text":"КОНЕЦ ИГРЫ", "color":"red"}
execute as @a[team=tm.player] if score @s death matches 20.. run tellraw @a [{"text":">> Сосед Победил", "color":"gray"}]
execute as @a[team=tm.player] if score @s death matches 20.. run gamemode spectator @a
execute as @a[team=tm.player] if score @s death matches 20.. run scoreboard players set @s death 0

execute if block 34 12 3 minecraft:redstone_lamp[lit=true] run title @a title {"text":"КОНЕЦ ИГРЫ", "color":"green"}
execute if block 34 12 3 minecraft:redstone_lamp[lit=true] run tellraw @a [{"text":">> Игрок Победил", "color":"gray"}]
execute if block 34 12 3 minecraft:redstone_lamp[lit=true] run gamemode spectator @a
execute if block 34 12 3 minecraft:redstone_lamp[lit=true] run setblock 34 12 3 minecraft:bedrock
