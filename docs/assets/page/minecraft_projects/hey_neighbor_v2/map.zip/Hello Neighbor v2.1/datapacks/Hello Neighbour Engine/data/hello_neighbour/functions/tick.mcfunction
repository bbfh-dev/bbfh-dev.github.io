function hello_neighbour:sound
function hello_neighbour:items
function hello_neighbour:cast
function hello_neighbour:beta

execute as @e[tag=keyhole, tag=north] at @s unless entity @p[team=tm.neighbour, distance=...8, limit=1] run setblock ~ ~ ~ minecraft:iron_door[facing=north,open=false,hinge=left]
execute as @e[tag=keyhole, tag=south] at @s unless entity @p[team=tm.neighbour, distance=...8, limit=1] run setblock ~ ~ ~ minecraft:iron_door[facing=south,open=false,hinge=right]
execute as @e[tag=keyhole, tag=east] at @s unless entity @p[team=tm.neighbour, distance=...8, limit=1] run setblock ~ ~ ~ minecraft:iron_door[facing=east,open=false,hinge=left]
execute as @e[tag=keyhole, tag=west] at @s unless entity @p[team=tm.neighbour, distance=...8, limit=1] run setblock ~ ~ ~ minecraft:iron_door[facing=west,open=false,hinge=right]

execute as @e[tag=keyhole, tag=north] at @s if entity @p[team=tm.neighbour, distance=...8, limit=1] run setblock ~ ~ ~ minecraft:iron_door[facing=north,open=true,hinge=left]
execute as @e[tag=keyhole, tag=south] at @s if entity @p[team=tm.neighbour, distance=...8, limit=1] run setblock ~ ~ ~ minecraft:iron_door[facing=south,open=true,hinge=left]
execute as @e[tag=keyhole, tag=east] at @s if entity @p[team=tm.neighbour, distance=...8, limit=1] run setblock ~ ~ ~ minecraft:iron_door[facing=east,open=true,hinge=left]
execute as @e[tag=keyhole, tag=west] at @s if entity @p[team=tm.neighbour, distance=...8, limit=1] run setblock ~ ~ ~ minecraft:iron_door[facing=west,open=true,hinge=left]

###

effect give @a[team=tm.neighbour] minecraft:haste 1 3 true

###
execute if block 15 31 -11 minecraft:redstone_lamp[lit=false] run scoreboard players set iron_bars hello_neighbour 0
execute if block 15 31 -11 minecraft:redstone_lamp[lit=true] run scoreboard players set iron_bars hello_neighbour 1
execute if block 15 31 -11 minecraft:redstone_lamp[lit=true] run fill 30 20 -2 29 23 0 air replace minecraft:iron_bars
execute if score iron_bars_1 hello_neighbour > iron_bars hello_neighbour run playsound minecraft:block.anvil.place voice @a 0 228 0 50 1 0
execute if score iron_bars_1 hello_neighbour < iron_bars hello_neighbour run playsound minecraft:block.anvil.destroy voice @a 0 228 0 50 1 0
execute store result score iron_bars_1 hello_neighbour run scoreboard players get iron_bars hello_neighbour

execute if block 15 31 -11 minecraft:redstone_lamp[lit=false] run function hello_neighbour:execute/fill

###
execute as @e[tag=blue] at @s run particle minecraft:dust .2 .3 1 2 ~ ~1 ~ 0 0 0 0 0 normal
execute as @e[tag=blue] at @s if entity @e[type=item, nbt={Item:{tag:{Tags:["item.blue_key"]}}}, distance=..1] run playsound minecraft:block.iron_trapdoor.open voice @a ~ ~ ~ 228 1 0
execute as @e[tag=blue] at @s if entity @e[type=item, nbt={Item:{tag:{Tags:["item.blue_key"]}}}, distance=..1] run kill @s

execute as @e[tag=red] at @s run particle minecraft:dust 1 .3 .2 2 ~ ~1 ~ 0 0 0 0 0 normal
execute as @e[tag=red] at @s if entity @e[type=item, nbt={Item:{tag:{Tags:["item.red_key"]}}}, distance=..1] run playsound minecraft:block.iron_trapdoor.open voice @a ~ ~ ~ 228 1 0
execute as @e[tag=red] at @s if entity @e[type=item, nbt={Item:{tag:{Tags:["item.red_key"]}}}, distance=..1] run kill @s

execute as @e[tag=green] at @s run particle minecraft:dust .2 1 .3 2 ~ ~1 ~ 0 0 0 0 0 normal
execute as @e[tag=green] at @s if entity @e[type=item, nbt={Item:{tag:{Tags:["item.green_key"]}}}, distance=..1] run playsound minecraft:block.iron_trapdoor.open voice @a ~ ~ ~ 228 1 0
execute as @e[tag=green] at @s if entity @e[type=item, nbt={Item:{tag:{Tags:["item.green_key"]}}}, distance=..1] run kill @s

execute as @e[tag=yellow] at @s run particle minecraft:dust 1 1 .3 2 ~ ~1 ~ 0 0 0 0 0 normal
execute as @e[tag=yellow] at @s if entity @e[type=item, nbt={Item:{tag:{Tags:["item.yellow_key"]}}}, distance=..1] run playsound minecraft:block.iron_trapdoor.open voice @a ~ ~ ~ 228 1 0
execute as @e[tag=yellow] at @s if entity @e[type=item, nbt={Item:{tag:{Tags:["item.yellow_key"]}}}, distance=..1] run kill @s

###

execute as @a[team=tm.player] at @s if block ~ ~ ~ minecraft:black_carpet run effect give @s minecraft:invisibility 1 0 true
execute as @a[team=tm.player] at @s if block ~ ~ ~ minecraft:black_carpet run effect clear @s minecraft:glowing

execute if block 19 26 -11 minecraft:redstone_lamp[lit=false] run scoreboard players set lit hello_neighbour 0
execute if block 19 26 -11 minecraft:redstone_lamp[lit=true] run scoreboard players set lit hello_neighbour 1

execute if score lit_old hello_neighbour > lit hello_neighbour run playsound minecraft:block.beacon.deactivate voice @a 0 228 0 50 1 0
execute if score lit_old hello_neighbour < lit hello_neighbour run playsound minecraft:block.beacon.activate voice @a 0 228 0 50 1 0
execute store result score lit_old hello_neighbour run scoreboard players get lit hello_neighbour

effect give @a minecraft:saturation 228 228 true

###

execute as @a[team=tm.player] at @p[team=tm.neighbour] unless score game hello_neighbour matches 1 run tellraw @a ["",{"text":"\n\n\n\u0422\u0435\u043f\u0435\u0440\u044c \u0442\u044b \u043c\u043e\u0436\u0435\u0448\u044c ","color":"green","clickEvent":{"action":"run_command","value":"/function _lobby:game"}},{"text":">>","color":"gray","clickEvent":{"action":"run_command","value":"/function _lobby:game"}},{"text":" \u041d\u0430\u0447\u0430\u0442\u044c \u0438\u0433\u0440\u0443","clickEvent":{"action":"run_command","value":"/execute at @s run function _lobby:game"}}]
execute as @a[team=tm.player] at @p[team=tm.neighbour] unless score game hello_neighbour matches 1 run scoreboard players set game hello_neighbour 1

execute unless score game hello_neighbour matches 1 run scoreboard players enable @a player
execute unless score game hello_neighbour matches 1 run scoreboard players enable @a neighbour

execute as @a[scores={player=1..}] at @s run function _lobby:player
execute as @a[scores={neighbour=1..}] at @s run function _lobby:neighbour


title @a actionbar ["",{"text":"\u041a\u043e\u043b\u0438\u0447\u0435\u0441\u0442\u0432\u043e \u0421\u043c\u0435\u0440\u0442\u0435\u0439:","bold":true,"color":"dark_aqua"},{"text":" ","color":"dark_aqua"},{"score":{"name":"@p[team=tm.player]","objective":"death"},"color":"gold"},{"text":" / ","color":"dark_aqua"},{"text":"20","color":"gold"}]

###

scoreboard players add score.cam hello_neighbour 1
scoreboard players add score.trap hello_neighbour 1
scoreboard players add score.glass hello_neighbour 1

execute as @a[team=tm.neighbour] if score game hello_neighbour matches 1 if score score.cam hello_neighbour matches 2600.. run give @s minecraft:firework_star{Tags:["item.cam"], display:{Name:'{"text":"Камера Видеонаблюдения", "color":"light_purple", "italic":false}', Lore:['{"text":"Выкиньте чтобы установить", "color":"gray", "italic":false}', '{"text":"Камера примит ваше положение", "color":"gray", "italic":false}', '{"text":"И ваш взгляд", "color":"gray", "italic":false}']}}

execute as @a[team=tm.neighbour] if score game hello_neighbour matches 1 if score score.trap hello_neighbour matches 6000.. run give @s minecraft:firework_star{Tags:["item.trap"], display:{Name:'{"text":"Ловушка Жопера", "color":"light_purple", "italic":false}', Lore:['{"text":"Установится в точке", "color":"gray", "italic":false}', '{"text":"Падения", "color":"gray", "italic":false}']}}

execute as @a[team=tm.neighbour] if score game hello_neighbour matches 1 if score score.glass hello_neighbour matches 7200.. run give @s minecraft:gray_stained_glass_pane{display:{Name:'{"text":"Стекло", "color":"light_purple", "italic":false}'}, CanPlaceOn:["white_stained_glass_pane", "yellow_concrete", "red_concrete", "blue_concrete", "light_blue_concrete", "orange_concrete"]}

execute as @a[team=tm.neighbour] if score game hello_neighbour matches 1 if score score.cam hello_neighbour matches 2600.. run scoreboard players set score.cam hello_neighbour 0
execute as @a[team=tm.neighbour] if score game hello_neighbour matches 1 if score score.trap hello_neighbour matches 6000.. run scoreboard players set score.trap hello_neighbour 0
execute as @a[team=tm.neighbour] if score game hello_neighbour matches 1 if score score.glass hello_neighbour matches 7200.. run scoreboard players set score.glass hello_neighbour 0

effect give @a[team=tm.neighbour] minecraft:strength 228 9 true
