fill ~ ~ ~ ~ ~1 ~ air
setblock ~ ~ ~ birch_door[facing=east, half=lower]
setblock ~ ~1 ~ birch_door[facing=east, half=upper]
kill @s
