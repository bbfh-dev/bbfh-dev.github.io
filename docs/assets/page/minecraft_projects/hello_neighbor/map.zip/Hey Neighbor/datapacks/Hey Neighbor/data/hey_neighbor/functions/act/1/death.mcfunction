scoreboard players set act_part hey_neighbor 4
playsound minecraft:sfx.cardio_monitor master @a 2223.5 58.5 -6.5 228 1 0
scoreboard players set dialog hey_neighbor 200
