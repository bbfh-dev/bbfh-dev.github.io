scoreboard players set act_part hey_neighbor 3
fill 2221 66 3 2236 65 3 minecraft:air
fill 2236 66 3 2236 65 -23 minecraft:air
fill 2236 66 -23 2222 65 -23 minecraft:air
fill 2222 66 -23 2222 65 -3 minecraft:air
fill 2222 66 -3 2221 65 -3 minecraft:air

time set 2228
execute as @p[team=newcomer] run function hey_neighbor:catch
tp @p[team=newcomer] 2246.5 65 0.5 90 0
title @a subtitle [{"text":">> ", "color":"yellow", "bold":false}, {"text":"Догонялки", "color":"gray", "bold":false}, {"text":" <<", "color":"yellow", "bold":false}]
title @a title {"text":"АКТ 1", "color":"yellow", "bold":true}
tellraw @a[team=newcomer] ["",{"text":"\u0426\u0435\u043b\u044c","bold":true,"color":"yellow"},{"text":"\n"},{"text":"\u0427\u0442\u043e\u0431\u044b \u043f\u043e\u0439\u043c\u0430\u0442\u044c \u0441\u043e\u0441\u0435\u0434\u0430 \u043d\u0443\u0436\u043d\u043e \u0434\u043e\u0442\u0440\u043e\u043d\u0443\u0442\u044c\u0441\u044f \u0434\u043e \u043d\u0435\u0433\u043e, \u043d\u0435 \u0434\u0430\u0439 \u0435\u043c\u0443 \u043f\u0440\u043e\u0431\u0440\u0430\u0442\u044c\u0441\u044f \u043d\u0430 \u0442\u0432\u043e\u0439 \u0447\u0435\u0440\u0434\u0430\u043a, \u0438\u043d\u0430\u0447\u0435 \u043f\u0440\u043e\u0438\u0433\u0440\u0430\u0435\u0448\u044c, \u0438 \u0442\u0435\u0431\u0435 \u043f\u0440\u0438\u0434\u0435\u0442\u0441\u044f \u0433\u043e\u0442\u043e\u0432\u0438\u0442\u044c \u0431\u043b\u0438\u043d\u044b!","color":"gray"}]
tellraw @a[team=neighbor] ["",{"text":"\u0426\u0435\u043b\u044c","bold":true,"color":"yellow"},{"text":"\n"},{"text":"\u0422\u0435\u0431\u0435 \u043d\u0443\u0436\u043d\u043e \u043f\u0440\u043e\u0431\u0440\u0430\u0442\u044c\u0441\u044f \u043d\u0430 \u043a\u0440\u044b\u0448\u0443 \u0447\u0442\u043e\u0431\u044b \u043d\u0435 \u0433\u043e\u0442\u043e\u0432\u0438\u0442\u044c \u0431\u043b\u0438\u043d\u044b, \u043f\u0440\u044f\u0447\u044c\u0441\u044f \u0432 \u0448\u043a\u0430\u0444\u0430\u0445 \u0438 \u0443\u0431\u0435\u0433\u0430\u0439 \u043e\u0442 \u043f\u0440\u0438\u0435\u0437\u0436\u0435\u0433\u043e!","color":"gray"}]
