scoreboard players set act_part hey_neighbor 7
scoreboard players set dialog hey_neighbor 360
playsound minecraft:sfx.attack_theme_stay master @a 0 228 0 228 1 1
