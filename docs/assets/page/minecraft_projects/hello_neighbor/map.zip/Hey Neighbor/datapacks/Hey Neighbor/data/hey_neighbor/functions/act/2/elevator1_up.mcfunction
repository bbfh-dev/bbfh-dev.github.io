scoreboard players set elevator1_old hey_neighbor 0
playsound minecraft:sfx.dummy_catch_1 master @a 0 228 0 228 1 0
clone 0 20 0 1 30 2 35 64 3
execute as @a[x=36, y=66, z=4, distance=..2] at @s run tp @s ~ ~12 ~