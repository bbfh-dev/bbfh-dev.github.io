execute as @e[tag=door, tag=east] at @s if entity @e[tag=keyhole, distance=..1] unless block ~ ~ ~ iron_door run fill ~ ~ ~ ~ ~1 ~ air
execute as @e[tag=door, tag=east] at @s if entity @e[tag=keyhole, distance=..1] run setblock ~ ~ ~ iron_door[facing=east, open=false]
execute as @e[tag=door, tag=east] at @s if entity @e[tag=keyhole, distance=..1] unless block ~ ~1 ~ iron_door run setblock ~ ~1 ~ iron_door[half=upper]
execute as @e[tag=door, tag=east] at @s unless entity @e[tag=keyhole, distance=..1] run function zero_neighbor:locked_door/east_close

execute as @e[tag=door, tag=west] at @s if entity @e[tag=keyhole, distance=..1] unless block ~ ~ ~ iron_door run fill ~ ~ ~ ~ ~1 ~ air
execute as @e[tag=door, tag=west] at @s if entity @e[tag=keyhole, distance=..1] run setblock ~ ~ ~ iron_door[facing=west, open=false]
execute as @e[tag=door, tag=west] at @s if entity @e[tag=keyhole, distance=..1] unless block ~ ~1 ~ iron_door run setblock ~ ~1 ~ iron_door[half=upper]
execute as @e[tag=door, tag=west] at @s unless entity @e[tag=keyhole, distance=..1] run function zero_neighbor:locked_door/west_close

execute as @e[tag=door, tag=north] at @s if entity @e[tag=keyhole, distance=..1] unless block ~ ~ ~ iron_door run fill ~ ~ ~ ~ ~1 ~ air
execute as @e[tag=door, tag=north] at @s if entity @e[tag=keyhole, distance=..1] run setblock ~ ~ ~ iron_door[facing=north, open=false]
execute as @e[tag=door, tag=north] at @s if entity @e[tag=keyhole, distance=..1] unless block ~ ~1 ~ iron_door run setblock ~ ~1 ~ iron_door[half=upper]
execute as @e[tag=door, tag=north] at @s unless entity @e[tag=keyhole, distance=..1] run function zero_neighbor:locked_door/north_close

execute as @e[tag=door, tag=south] at @s if entity @e[tag=keyhole, distance=..1] unless block ~ ~ ~ iron_door run fill ~ ~ ~ ~ ~1 ~ air
execute as @e[tag=door, tag=south] at @s if entity @e[tag=keyhole, distance=..1] run setblock ~ ~ ~ iron_door[facing=south, open=false]
execute as @e[tag=door, tag=south] at @s if entity @e[tag=keyhole, distance=..1] unless block ~ ~1 ~ iron_door run setblock ~ ~1 ~ iron_door[half=upper]
execute as @e[tag=door, tag=south] at @s unless entity @e[tag=keyhole, distance=..1] run function zero_neighbor:locked_door/south_close

execute as @a[team=newcomer, scores={game_keyhole=1..}] at @s as @e[tag=door, limit=1, sort=nearest] at @s run function zero_neighbor:locked_door/open
