scoreboard players set elevator1_old hey_neighbor 1
playsound minecraft:sfx.dummy_catch_3 master @a 0 228 0 228 1 0
clone 5 20 0 6 30 2 35 64 3