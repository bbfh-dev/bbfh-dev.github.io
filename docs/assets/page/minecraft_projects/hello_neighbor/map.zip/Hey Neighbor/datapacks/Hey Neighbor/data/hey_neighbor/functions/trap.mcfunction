summon minecraft:area_effect_cloud ~ ~ ~ {Duration:19999999, Tags:["trap"]}
kill @s
