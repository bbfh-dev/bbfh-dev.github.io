scoreboard players set act_part hey_neighbor 6
scoreboard players set dialog hey_neighbor 20
