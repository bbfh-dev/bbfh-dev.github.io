scoreboard players reset @a game_keyhole

execute if entity @pnbt={SelectedItem:{id:"minecraft:red_dye"}}] if entity @e[distance=..1, tag=red] run particle minecraft:cloud ~ ~1 ~ .25 .5 .25 0 200
execute if entity @pnbt={SelectedItem:{id:"minecraft:red_dye"}}] if entity @e[distance=..1, tag=red] run tp @e[tag=red] 0 -228 0

execute if entity @pnbt={SelectedItem:{id:"minecraft:green_dye"}}] if entity @e[distance=..1, tag=green] run particle minecraft:cloud ~ ~1 ~ .25 .5 .25 0 200
execute if entity @pnbt={SelectedItem:{id:"minecraft:green_dye"}}] if entity @e[distance=..1, tag=green] run tp @e[tag=green] 0 -228 0

execute if entity @pnbt={SelectedItem:{id:"minecraft:purple_dye"}}] if entity @e[distance=..1, tag=purple] run particle minecraft:cloud ~ ~1 ~ .25 .5 .25 0 200
execute if entity @pnbt={SelectedItem:{id:"minecraft:purple_dye"}}] if entity @e[distance=..1, tag=purple] run tp @e[tag=purple] 0 -228 0

execute if entity @pnbt={SelectedItem:{id:"minecraft:cyan_dye"}}] if entity @e[distance=..1, tag=cyan] run particle minecraft:cloud ~ ~1 ~ .25 .5 .25 0 200
execute if entity @pnbt={SelectedItem:{id:"minecraft:cyan_dye"}}] if entity @e[distance=..1, tag=cyan] run tp @e[tag=cyan] 0 -228 0

execute if entity @pnbt={SelectedItem:{id:"minecraft:light_gray_dye"}}] if entity @e[distance=..1, tag=light_gray] run particle minecraft:cloud ~ ~1 ~ .25 .5 .25 0 200
execute if entity @pnbt={SelectedItem:{id:"minecraft:light_gray_dye"}}] if entity @e[distance=..1, tag=light_gray] run tp @e[tag=light_gray] 0 -228 0

execute if entity @pnbt={SelectedItem:{id:"minecraft:gray_dye"}}] if entity @e[distance=..1, tag=gray] run particle minecraft:cloud ~ ~1 ~ .25 .5 .25 0 200
execute if entity @pnbt={SelectedItem:{id:"minecraft:gray_dye"}}] if entity @e[distance=..1, tag=gray] run tp @e[tag=gray] 0 -228 0

execute if entity @pnbt={SelectedItem:{id:"minecraft:pink_dye"}}] if entity @e[distance=..1, tag=pink] run particle minecraft:cloud ~ ~1 ~ .25 .5 .25 0 200
execute if entity @pnbt={SelectedItem:{id:"minecraft:pink_dye"}}] if entity @e[distance=..1, tag=pink] run tp @e[tag=pink] 0 -228 0

execute if entity @pnbt={SelectedItem:{id:"minecraft:lime_dye"}}] if entity @e[distance=..1, tag=lime] run particle minecraft:cloud ~ ~1 ~ .25 .5 .25 0 200
execute if entity @pnbt={SelectedItem:{id:"minecraft:lime_dye"}}] if entity @e[distance=..1, tag=lime] run tp @e[tag=lime] 0 -228 0

execute if entity @pnbt={SelectedItem:{id:"minecraft:yellow_dye"}}] if entity @e[distance=..1, tag=yellow] run particle minecraft:cloud ~ ~1 ~ .25 .5 .25 0 200
execute if entity @pnbt={SelectedItem:{id:"minecraft:yellow_dye"}}] if entity @e[distance=..1, tag=yellow] run tp @e[tag=yellow] 0 -228 0

execute if entity @pnbt={SelectedItem:{id:"minecraft:light_blue_dye"}}] if entity @e[distance=..1, tag=light_blue] run particle minecraft:cloud ~ ~1 ~ .25 .5 .25 0 200
execute if entity @pnbt={SelectedItem:{id:"minecraft:light_blue_dye"}}] if entity @e[distance=..1, tag=light_blue] run tp @e[tag=light_blue] 0 -228 0

execute if entity @pnbt={SelectedItem:{id:"minecraft:magenta_dye"}}] if entity @e[distance=..1, tag=magenta] run particle minecraft:cloud ~ ~1 ~ .25 .5 .25 0 200
execute if entity @pnbt={SelectedItem:{id:"minecraft:magenta_dye"}}] if entity @e[distance=..1, tag=magenta] run tp @e[tag=magenta] 0 -228 0

execute if entity @pnbt={SelectedItem:{id:"minecraft:orange_dye"}}] if entity @e[distance=..1, tag=orange] run particle minecraft:cloud ~ ~1 ~ .25 .5 .25 0 200
execute if entity @pnbt={SelectedItem:{id:"minecraft:orange_dye"}}] if entity @e[distance=..1, tag=orange] run tp @e[tag=orange] 0 -228 0

execute if entity @pnbt={SelectedItem:{id:"minecraft:blue_dye"}}] if entity @e[distance=..1, tag=blue] run particle minecraft:cloud ~ ~1 ~ .25 .5 .25 0 200
execute if entity @pnbt={SelectedItem:{id:"minecraft:blue_dye"}}] if entity @e[distance=..1, tag=blue] run tp @e[tag=blue] 0 -228 0

execute if entity @pnbt={SelectedItem:{id:"minecraft:brown_dye"}}] if entity @e[distance=..1, tag=brown] run particle minecraft:cloud ~ ~1 ~ .25 .5 .25 0 200
execute if entity @pnbt={SelectedItem:{id:"minecraft:brown_dye"}}] if entity @e[distance=..1, tag=brown] run tp @e[tag=brown] 0 -228 0

execute if entity @pnbt={SelectedItem:{id:"minecraft:black_dye"}}] if entity @e[distance=..1, tag=black] run particle minecraft:cloud ~ ~1 ~ .25 .5 .25 0 200
execute if entity @pnbt={SelectedItem:{id:"minecraft:black_dye"}}] if entity @e[distance=..1, tag=black] run tp @e[tag=black] 0 -228 0

execute if entity @pnbt={SelectedItem:{id:"minecraft:white_dye"}}] if entity @e[distance=..1, tag=white] run particle minecraft:cloud ~ ~1 ~ .25 .5 .25 0 200
execute if entity @pnbt={SelectedItem:{id:"minecraft:white_dye"}}] if entity @e[distance=..1, tag=white] run tp @e[tag=white] 0 -228 0

execute if entity @e[distance=..1, tag=red] run title @p actionbar ["",{"text":"Требуется ","color":"yellow"},{"text":"> ","color":"gray"},{"text":"Красный Ключ","color":"dark_red"},{"text":" <","color":"gray"},{"text":" Требуется","color":"yellow"}]
execute if entity @e[distance=..1, tag=green] run title @p actionbar ["",{"text":"Требуется ","color":"yellow"},{"text":"> ","color":"gray"},{"text":"Зеленый Ключ","color":"dark_green"},{"text":" <","color":"gray"},{"text":" Требуется","color":"yellow"}]
execute if entity @e[distance=..1, tag=purple] run title @p actionbar ["",{"text":"Требуется ","color":"yellow"},{"text":"> ","color":"gray"},{"text":"Фиолетовый Ключ","color":"dark_purple"},{"text":" <","color":"gray"},{"text":" Требуется","color":"yellow"}]
execute if entity @e[distance=..1, tag=cyan] run title @p actionbar ["",{"text":"Требуется ","color":"yellow"},{"text":"> ","color":"gray"},{"text":"Бирюзовый Ключ","color":"cyan"},{"text":" <","color":"gray"},{"text":" Требуется","color":"yellow"}]
execute if entity @e[distance=..1, tag=light_gray] run title @p actionbar ["",{"text":"Требуется ","color":"yellow"},{"text":"> ","color":"gray"},{"text":"Светло-Серый Ключ","color":"gray"},{"text":" <","color":"gray"},{"text":" Требуется","color":"yellow"}]
execute if entity @e[distance=..1, tag=gray] run title @p actionbar ["",{"text":"Требуется ","color":"yellow"},{"text":"> ","color":"gray"},{"text":"Серый Ключ","color":"dark_gray"},{"text":" <","color":"gray"},{"text":" Требуется","color":"yellow"}]
execute if entity @e[distance=..1, tag=pink] run title @p actionbar ["",{"text":"Требуется ","color":"yellow"},{"text":"> ","color":"gray"},{"text":"Розовый Ключ","color":"light_purple"},{"text":" <","color":"gray"},{"text":" Требуется","color":"yellow"}]
execute if entity @e[distance=..1, tag=lime] run title @p actionbar ["",{"text":"Требуется ","color":"yellow"},{"text":"> ","color":"gray"},{"text":"Лаймовый Ключ","color":"green"},{"text":" <","color":"gray"},{"text":" Требуется","color":"yellow"}]
execute if entity @e[distance=..1, tag=yellow] run title @p actionbar ["",{"text":"Требуется ","color":"yellow"},{"text":"> ","color":"gray"},{"text":"Желтый Ключ","color":"yellow"},{"text":" <","color":"gray"},{"text":" Требуется","color":"yellow"}]
execute if entity @e[distance=..1, tag=light_blue] run title @p actionbar ["",{"text":"Требуется ","color":"yellow"},{"text":"> ","color":"gray"},{"text":"Голубой Ключ","color":"blue"},{"text":" <","color":"gray"},{"text":" Требуется","color":"yellow"}]
execute if entity @e[distance=..1, tag=magenta] run title @p actionbar ["",{"text":"Требуется ","color":"yellow"},{"text":"> ","color":"gray"},{"text":"Пурпурный Ключ","color":"red"},{"text":" <","color":"gray"},{"text":" Требуется","color":"yellow"}]
execute if entity @e[distance=..1, tag=orange] run title @p actionbar ["",{"text":"Требуется ","color":"yellow"},{"text":"> ","color":"gray"},{"text":"Оранжевый Ключ","color":"gold"},{"text":" <","color":"gray"},{"text":" Требуется","color":"yellow"}]
execute if entity @e[distance=..1, tag=blue] run title @p actionbar ["",{"text":"Требуется ","color":"yellow"},{"text":"> ","color":"gray"},{"text":"Синий Ключ","color":"dark_blue"},{"text":" <","color":"gray"},{"text":" Требуется","color":"yellow"}]
execute if entity @e[distance=..1, tag=brown] run title @p actionbar ["",{"text":"Требуется ","color":"yellow"},{"text":"> ","color":"gray"},{"text":"Коричневый Ключ","color":"brown"},{"text":" <","color":"gray"},{"text":" Требуется","color":"yellow"}]
execute if entity @e[distance=..1, tag=black] run title @p actionbar ["",{"text":"Требуется ","color":"yellow"},{"text":"> ","color":"gray"},{"text":"Черный Ключ","color":"black"},{"text":" <","color":"gray"},{"text":" Требуется","color":"yellow"}]
execute if entity @e[distance=..1, tag=white] run title @p actionbar ["",{"text":"Требуется ","color":"yellow"},{"text":"> ","color":"gray"},{"text":"Белый Ключ","color":"white"},{"text":" <","color":"gray"},{"text":" Требуется","color":"yellow"}]
