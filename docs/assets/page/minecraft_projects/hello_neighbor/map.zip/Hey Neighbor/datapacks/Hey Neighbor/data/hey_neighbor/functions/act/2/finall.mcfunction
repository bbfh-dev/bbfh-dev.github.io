scoreboard players set act_part hey_neighbor 8
scoreboard players set act hey_neighbor 3

tp @p[team=newcomer] -2211 65 12
execute as @a[team=neighbor] at @s run tp @s -2222 65 34

time set 18000
execute as @p[team=newcomer] run function hey_neighbor:catch
title @a subtitle [{"text":">> ", "color":"yellow", "bold":false}, {"text":"Подвал", "color":"gray", "bold":false}, {"text":" <<", "color":"yellow", "bold":false}]
title @a title {"text":"АКТ 3", "color":"yellow", "bold":true}
stopsound @a
