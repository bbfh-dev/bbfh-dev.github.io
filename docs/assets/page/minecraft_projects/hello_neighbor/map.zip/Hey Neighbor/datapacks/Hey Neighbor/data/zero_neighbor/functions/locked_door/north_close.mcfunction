fill ~ ~ ~ ~ ~1 ~ air
setblock ~ ~ ~ birch_door[facing=north, half=lower]
setblock ~ ~1 ~ birch_door[facing=north, half=upper]
kill @s
