scoreboard players set act_part hey_neighbor 2
scoreboard players set dialog hey_neighbor 300
