scoreboard players set ladder1_old hey_neighbor 0
fill 9 68 -6 9 66 -6 minecraft:ladder[facing=west]
playsound minecraft:sfx.dummy_catch_1 master @a 9 67 -6 10 1 0
