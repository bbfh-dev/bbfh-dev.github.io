effect give @p[team=newcomer] blindness 5 0 true
effect give @p[team=newcomer] slowness 3 128 true
effect give @p[team=newcomer] jump_boost 3 128 true
effect give @p[team=newcomer] glowing 5 0 true
kill @s
playsound minecraft:sfx.attack_theme_2 master @a 0 100 0 2228 1 1
