tp @a 0.5 49 0.5
tellraw @a "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nСпасибо за прохождение карты!"
