scoreboard players set iron_door_old hey_neighbor 0
fill 2251 70 4 2251 72 1 iron_bars[north=true, south=true]
playsound minecraft:sfx.dummy_catch_3 master @a 2251.56 71.37 4.04 5 1 0
