scoreboard players set dialog hey_neighbor 240
