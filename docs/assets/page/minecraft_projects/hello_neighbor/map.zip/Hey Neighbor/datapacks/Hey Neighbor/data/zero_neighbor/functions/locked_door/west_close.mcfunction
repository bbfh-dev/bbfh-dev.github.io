fill ~ ~ ~ ~ ~1 ~ air
setblock ~ ~ ~ birch_door[facing=west, half=lower]
setblock ~ ~1 ~ birch_door[facing=west, half=upper]
kill @s
