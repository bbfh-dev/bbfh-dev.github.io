scoreboard players set iron_door3_old hey_neighbor 0
fill 13 75 7 13 78 5 iron_bars[south=true, north=true]
playsound minecraft:sfx.dummy_catch_3 master @a 13 76 6 10 1 0
