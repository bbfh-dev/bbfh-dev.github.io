scoreboard players set act hey_neighbor 4
scoreboard players set dialog hey_neighbor 1200
tp @a[team=newcomer] -2211.5 85 -24.5
