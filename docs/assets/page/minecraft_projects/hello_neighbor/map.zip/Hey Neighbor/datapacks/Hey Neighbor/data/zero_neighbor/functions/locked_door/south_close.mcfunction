fill ~ ~ ~ ~ ~1 ~ air
setblock ~ ~ ~ birch_door[facing=south, half=lower]
setblock ~ ~1 ~ birch_door[facing=south, half=upper]
kill @s
