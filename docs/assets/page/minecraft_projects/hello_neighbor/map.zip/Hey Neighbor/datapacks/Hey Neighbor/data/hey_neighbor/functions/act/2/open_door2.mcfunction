scoreboard players set iron_door2_old hey_neighbor 1
fill 21 70 0 21 72 2 air
playsound minecraft:sfx.dummy_catch_4 master @a 21 71 1 10 1 0
