scoreboard players set act hey_neighbor 1
scoreboard players set act_part hey_neighbor 1
tp @p[team=newcomer] 2230 64 -21 0 0

fill 2221 66 3 2236 65 3 minecraft:barrier
fill 2236 66 3 2236 65 -23 minecraft:barrier
fill 2236 66 -23 2222 65 -23 minecraft:barrier
fill 2222 66 -23 2222 65 -3 minecraft:barrier
fill 2222 66 -3 2221 65 -3 minecraft:barrier

time set 2228
gamemode adventure @a
