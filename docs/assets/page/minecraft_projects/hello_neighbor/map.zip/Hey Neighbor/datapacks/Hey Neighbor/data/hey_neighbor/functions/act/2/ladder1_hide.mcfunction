scoreboard players set ladder1_old hey_neighbor 1
fill 9 68 -6 9 66 -6 air
playsound minecraft:sfx.dummy_catch_5 master @a 9 67 -6 10 1 0
