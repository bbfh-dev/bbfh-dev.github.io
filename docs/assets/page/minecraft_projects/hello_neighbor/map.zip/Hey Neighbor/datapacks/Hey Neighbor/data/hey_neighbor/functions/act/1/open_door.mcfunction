scoreboard players set iron_door_old hey_neighbor 1
fill 2251 70 4 2251 72 1 air
playsound minecraft:sfx.dummy_catch_4 master @a 2251.56 71.37 4.04 5 1 0
