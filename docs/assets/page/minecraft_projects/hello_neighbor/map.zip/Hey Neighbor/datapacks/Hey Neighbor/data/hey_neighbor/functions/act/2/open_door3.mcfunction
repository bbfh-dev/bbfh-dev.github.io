scoreboard players set iron_door3_old hey_neighbor 1
fill 13 75 7 13 78 5 air
playsound minecraft:sfx.dummy_catch_4 master @a 13 76 6 10 1 0
