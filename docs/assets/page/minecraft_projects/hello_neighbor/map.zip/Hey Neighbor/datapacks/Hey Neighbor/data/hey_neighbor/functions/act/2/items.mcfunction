execute as @e[type=item, nbt={Item:{id:"minecraft:red_sand"}}] run data merge entity @s {Item:{tag:{display:{Name:'{"text":"Коробка", "color":"yellow", "italic":false}', Lore:['{"text":"Используйте", "color":"green", "italic":false}', '{"text":"Чтобы добраться до необходимого места", "color":"gray", "italic":false}', '{"text":"", "color":"gray", "italic":false}', '{"text":"Может ставиться", "color":"green", "italic":false}', '{"text":"На крышу, пол и землю", "color":"gray", "italic":false}']}, CanPlaceOn:["grass_block", "dirt", "red_sand", "smooth_quartz", "quartz_block", "grass_path", "dark_oak_slab", "dark_oak_stairs"], CanDestroy:["red_sand", "white_stained_glass_pane"]}}}

replaceitem entity @a[team=newcomer] hotbar.8 minecraft:golden_shovel{CanDestroy:["red_sand"], display:{Name:'{"text":"Я тебя за-ка-па-ю", "color":"yellow", "italic":false}', Lore:['{"text":"Используйте чтобы добывать коробки", "color":"gray", "italic":false}']}}

execute as @e[type=item, nbt={Item:{id:"minecraft:firework_star"}}] at @s as @p[team=neighbor, distance=..16] at @s facing entity @p[team=newcomer] eyes run tp @s ^ ^ ^-3
execute as @e[type=item, nbt={Item:{id:"minecraft:firework_star"}}] run kill @s

execute as @a[nbt={SelectedItem:{id:"minecraft:clock"}}] run time add 6000

execute as @a[nbt={SelectedItem:{id:"minecraft:firework_rocket"}}] at @s run effect give @s slow_falling 1 0 true
effect give @a saturation 99999 0 true
