setworldspawn 0 49 0
execute if score act hey_neighbor matches 1 run spawnpoint @a 2228 65 0
execute if score act hey_neighbor matches 2 run spawnpoint @a 0 65 0
execute if score act hey_neighbor matches 3 run spawnpoint @a -2211 66 12
execute if score act hey_neighbor matches 4 run spawnpoint @a 0 100 0
effect give @a resistance 10 128 true


execute if score act hey_neighbor matches 3 if score item hey_neighbor matches 1.. run scoreboard players remove item hey_neighbor 1
execute if score act hey_neighbor matches 3 if score item hey_neighbor matches 0 run give @p[team=neighbor] minecraft:bat_spawn_egg{EntityTag:{id:"minecraft:armor_stand", Tags:["trap_old"], Invisible:1}}
execute if score act hey_neighbor matches 3 if score item hey_neighbor matches 0 run scoreboard players set item hey_neighbor 1200

execute as @e[tag=trap_old, nbt={OnGround:1b}] at @s run function hey_neighbor:trap
execute as @e[tag=trap] at @s run particle minecraft:witch ~ ~ ~ .125 .125 .125 0 1
execute as @e[tag=trap] at @s positioned ~ ~-.5 ~ if entity @p[team=newcomer, distance=...9] run function hey_neighbor:trap_active

#---/ Функции Обновления /---#
function zero_neighbor:locked_door/tick
function hey_neighbor:act/2/items
execute if score act hey_neighbor matches 2 as @p[team=newcomer, x=24, y=62, z=-3.0, distance=...5] run function hey_neighbor:act/2/finall
#---/ Постоянное обновление /---#
execute if score act hey_neighbor matches 2 as @a[team=newcomer] at @s if entity @p[team=neighbor, distance=..1] run function hey_neighbor:catch
execute if score act hey_neighbor matches 3 as @a[team=newcomer] at @s if entity @p[team=neighbor, distance=..1] run function hey_neighbor:catch
#-/ Шкаф /-#
execute as @a[team=newcomer] at @s if block ~ ~ ~ jungle_door[open=false] run effect give @s minecraft:invisibility 1 0 true

execute if score act hey_neighbor matches 2 run scoreboard players set x hey_neighbor 0
execute if score act hey_neighbor matches 2 store result score pos_x hey_neighbor run data get entity @p[team=neighbor] Pos[0] 10
execute if score act hey_neighbor matches 2 run execute as @a[team=neighbor] at @s if score pos_x hey_neighbor <= x hey_neighbor run tp @s ~1 ~ ~
execute if score act hey_neighbor matches 2 run effect give @a[team=neighbor] speed 1 1 true

#---/ АКТ 1 /---#
execute if block -2219 66 17 minecraft:lever[powered=false] run fill -2220 65 16 -2222 67 16 minecraft:iron_bars[east=true, west=true]
execute if block -2219 66 17 minecraft:lever[powered=true] run fill -2220 65 16 -2222 67 16 air
#-/ Железная Решетка На Чердаке /-#
execute if score act hey_neighbor matches 1 if block 2274 66 8 lever[powered=true] run scoreboard players set iron_door hey_neighbor 1
execute if score act hey_neighbor matches 1 unless block 2274 66 8 lever[powered=true] run scoreboard players set iron_door hey_neighbor 0
execute if score act hey_neighbor matches 1 unless score iron_door hey_neighbor = iron_door_old hey_neighbor if score iron_door hey_neighbor matches 1 run function hey_neighbor:act/1/open_door
execute if score act hey_neighbor matches 1 unless score iron_door hey_neighbor = iron_door_old hey_neighbor if score iron_door hey_neighbor matches 0 run function hey_neighbor:act/1/close_door
#-/ Диалоги /-#
execute unless score act hey_neighbor matches 4 if score dialog hey_neighbor matches 1.. run scoreboard players remove dialog hey_neighbor 1
execute if score act hey_neighbor matches 4 run scoreboard players remove dialog hey_neighbor 1
execute if score act_part hey_neighbor matches 1 as @p[team=newcomer, x=2210, y=66, z=7, distance=..4] run function hey_neighbor:act/1/dialog_1

execute if score act_part hey_neighbor matches 2 if score dialog hey_neighbor matches 299 run tellraw @a ["",{"text":"\u041c\u0430\u043c\u0430","color":"yellow"},{"text":" >","color":"gray"},{"text":" \u041f\u0440\u0438\u0432\u0435\u0442, \u0442\u044b \u0443\u0436\u0435 \u043f\u0440\u043e\u0441\u043d\u0443\u043b\u0441\u044f?"}]
execute if score act_part hey_neighbor matches 2 if score dialog hey_neighbor matches 240 run tellraw @a ["",{"text":"\u0422\u044b","color":"gray"},{"text":" >","color":"gray"},{"text":" \u041d\u0443 \u0434\u0430, \u043d\u043e\u0440\u043c\u0430\u043b\u044c\u043d\u043e"}]
execute if score act_part hey_neighbor matches 2 if score dialog hey_neighbor matches 180 run tellraw @a ["",{"text":"\u041f\u0430\u043f\u0430","color":"red"},{"text":" >","color":"gray"},{"text":" \u041c\u044b \u0442\u0443\u0442 \u043f\u043e\u043e\u0431\u0449\u0430\u043b\u0438\u0441\u044c \u0441 \u0441\u043e\u0441\u0435\u0434\u043e\u043c, \u0438 \u0440\u0435\u0448\u0438\u043b\u0438 \u0443\u0441\u0442\u0440\u043e\u0438\u0442\u044c \u0441\u043e\u0440\u0435\u0432\u043d\u043e\u0432\u0430\u043d\u0438\u0435. \u0414\u0430\u0432\u0430\u0439\u0442\u0435 \u0432\u044b \u043f\u043e\u0438\u0433\u0440\u0430\u0435\u0442\u0435 \u0432 \u0434\u043e\u0433\u043e\u043d\u044f\u043b\u043a\u0438, \u0430 \u043f\u0440\u043e\u0438\u0433\u0440\u0430\u0432\u0448\u0438\u0439 \u0431\u0443\u0434\u0435\u0442 \u0433\u043e\u0442\u043e\u0432\u0438\u0442\u044c \u0431\u043b\u0438\u043d\u044b?"}]
execute if score act_part hey_neighbor matches 2 if score dialog hey_neighbor matches 120 run tellraw @a ["",{"text":"\u0421\u043e\u0441\u0435\u0434","color":"green"},{"text":" >","color":"gray"},{"text":" \u0414\u0430, \u044f \u0442\u043e\u043b\u044c\u043a\u043e \u0437\u0430!"}]
execute if score act_part hey_neighbor matches 2 if score dialog hey_neighbor matches 60 run tellraw @a ["",{"text":"\u0422\u044b","color":"gray"},{"text":" >","color":"gray"},{"text":" \u0425\u043e\u0440\u043e\u0448\u043e, \u044f \u0434\u043e\u0433\u043e\u043d\u044f\u044e!"}]
execute if score act_part hey_neighbor matches 2 if score dialog hey_neighbor matches 0 run function hey_neighbor:act/1/hide_and_seek
#-/ Цель /-#
execute if score act_part hey_neighbor matches 1 run title @a[team=newcomer] actionbar [{"text":"ЦЕЛЬ ","color":"yellow"},{"text":">","color":"gray"},{"text":" Пройти В Гостиную","color":"white"},{"text":" <","color":"gray"},{"text":" ЦЕЛЬ","color":"yellow"}]
execute if score act_part hey_neighbor matches 3 run title @a[team=newcomer] actionbar [{"text":"ЦЕЛЬ ","color":"red"},{"text":">","color":"gray"},{"text":" Не Дай Соседу Пробраться На Чердак","color":"white"},{"text":" <","color":"gray"},{"text":" ЦЕЛЬ","color":"red"}]
execute if score act_part hey_neighbor matches 3 run title @a[team=neighbor] actionbar [{"text":"ЦЕЛЬ ","color":"yellow"},{"text":">","color":"gray"},{"text":" Проберись На Чердак","color":"white"},{"text":" <","color":"gray"},{"text":" ЦЕЛЬ","color":"yellow"}]
execute if score act_part hey_neighbor matches 5 run title @a[team=newcomer] actionbar [{"text":"ЦЕЛЬ ","color":"yellow"},{"text":">","color":"gray"},{"text":" Проверь гостиную","color":"white"},{"text":" <","color":"gray"},{"text":" ЦЕЛЬ","color":"yellow"}]
execute if score act_part hey_neighbor matches 6 run title @a[team=newcomer] actionbar [{"text":"ЦЕЛЬ ","color":"yellow"},{"text":">","color":"gray"},{"text":" Проверь кухню","color":"white"},{"text":" <","color":"gray"},{"text":" ЦЕЛЬ","color":"yellow"}]
#-/ Catch /-#
execute if score act_part hey_neighbor matches 3 as @a[team=neighbor] at @s if entity @p[team=newcomer, distance=..1] run function hey_neighbor:catch
execute if score act_part hey_neighbor matches 3 run scoreboard players set x hey_neighbor 22300
execute if score act_part hey_neighbor matches 3 store result score pos_x hey_neighbor run data get entity @p[team=newcomer] Pos[0] 10
execute if score act_part hey_neighbor matches 3 run execute as @a[team=newcomer] at @s if score pos_x hey_neighbor <= x hey_neighbor run tp @s ~1 ~ ~
#-/ TP CUTSCENE /-#
execute if score act_part hey_neighbor matches 1 run tp @p[team=neighbor] 2208.5 65 8.5 -90 0
execute if score act_part hey_neighbor matches 2 run tp @p[team=neighbor] 2208.5 65 8.5 -90 0
execute if score act_part hey_neighbor matches 3 if entity @p[team=neighbor, x=2245, y=75, z=-2, distance=..3] run function hey_neighbor:act/1/roof

execute if score act_part hey_neighbor matches 4 run tp @p[team=neighbor] 2223.5 56.5 -5.5 -90 -90
execute if score act_part hey_neighbor matches 4 run tp @p[team=newcomer] 2228.6 57 0.7 145 1
#-/ DEATH /-#
execute if score act_part hey_neighbor matches 3 if score dialog hey_neighbor matches 1..100 run tp @p[team=newcomer] 2248.5 74 0 -100 3
execute if score act_part hey_neighbor matches 3 if score dialog hey_neighbor matches 50..100 run tp @p[team=neighbor] 2268.5 74 -3.5 85 0
execute if score act_part hey_neighbor matches 3 if score dialog hey_neighbor matches 45 run tp @p[team=neighbor] 2270.3 73.9 -4 80 0
execute if score act_part hey_neighbor matches 3 if score dialog hey_neighbor matches 30 run function hey_neighbor:act/1/death
execute if score act_part hey_neighbor matches 4 if score dialog hey_neighbor matches 1 run function hey_neighbor:act/1/finall
#-/ PARENTS /-#
execute if score act_part hey_neighbor matches 1 run tp @e[tag=dad, limit=1] 2209.5 64.8 9.5 -150 0
execute if score act_part hey_neighbor matches 1 run tp @e[tag=mom, limit=1] 2211.5 64.8 9.5 160 0
execute if score act_part hey_neighbor matches 4 run tp @e[tag=dad, limit=1] 2228 40 0
execute if score act_part hey_neighbor matches 4 run tp @e[tag=mom, limit=1] 2228 40 0
execute if score act_part hey_neighbor matches 0 run tp @e[tag=dad, limit=1] 2228 40 0
execute if score act_part hey_neighbor matches 0 run tp @e[tag=mom, limit=1] 2228 40 0



#---/ АКТ 2 /---#
execute if score act hey_neighbor matches 2 if block 26 71 -1 minecraft:lever[powered=false] run scoreboard players set iron_door2 hey_neighbor 0
execute if score act hey_neighbor matches 2 if block 26 71 -1 minecraft:lever[powered=true] run scoreboard players set iron_door2 hey_neighbor 1
execute if score act hey_neighbor matches 2 unless score iron_door2 hey_neighbor = iron_door2_old hey_neighbor if score iron_door2 hey_neighbor matches 1 run function hey_neighbor:act/2/open_door2
execute if score act hey_neighbor matches 2 unless score iron_door2 hey_neighbor = iron_door2_old hey_neighbor if score iron_door2 hey_neighbor matches 0 run function hey_neighbor:act/2/close_door2

execute if score act hey_neighbor matches 2 if block 14 80 3 minecraft:lever[powered=false] run scoreboard players set iron_door3 hey_neighbor 0
execute if score act hey_neighbor matches 2 if block 14 80 3 minecraft:lever[powered=true] run scoreboard players set iron_door3 hey_neighbor 1
execute if score act hey_neighbor matches 2 unless score iron_door3 hey_neighbor = iron_door3_old hey_neighbor if score iron_door3 hey_neighbor matches 1 run function hey_neighbor:act/2/open_door3
execute if score act hey_neighbor matches 2 unless score iron_door3 hey_neighbor = iron_door3_old hey_neighbor if score iron_door3 hey_neighbor matches 0 run function hey_neighbor:act/2/close_door3

execute if score act hey_neighbor matches 2 if block 26 77 18 minecraft:redstone_lamp[lit=false] run scoreboard players set ladder1 hey_neighbor 0
execute if score act hey_neighbor matches 2 if block 26 77 18 minecraft:redstone_lamp[lit=true] run scoreboard players set ladder1 hey_neighbor 1
execute if score act hey_neighbor matches 2 unless score ladder1 hey_neighbor = ladder1_old hey_neighbor if score ladder1 hey_neighbor matches 1 run function hey_neighbor:act/2/ladder1_hide
execute if score act hey_neighbor matches 2 unless score ladder1 hey_neighbor = ladder1_old hey_neighbor if score ladder1 hey_neighbor matches 0 run function hey_neighbor:act/2/ladder1_show

execute if score act hey_neighbor matches 2 if block 34 73 6 minecraft:lever[powered=false] run scoreboard players set elevator1 hey_neighbor 0
execute if score act hey_neighbor matches 2 if block 34 73 6 minecraft:lever[powered=true] run scoreboard players set elevator1 hey_neighbor 1
execute if score act hey_neighbor matches 2 unless score elevator1 hey_neighbor = elevator1_old hey_neighbor if score elevator1 hey_neighbor matches 1 run function hey_neighbor:act/2/elevator1_down
execute if score act hey_neighbor matches 2 unless score elevator1 hey_neighbor = elevator1_old hey_neighbor if score elevator1 hey_neighbor matches 0 run function hey_neighbor:act/2/elevator1_up



execute if score act_part hey_neighbor matches 5 as @p[team=newcomer, x=-20, y=66, z=7, distance=..4] run function hey_neighbor:act/2/dialog_1
execute if score act_part hey_neighbor matches 6 if score dialog hey_neighbor matches 15 run tellraw @a ["",{"text":"\u0422\u044b >","color":"gray"},{"text":" \u041c\u0430\u0430\u0430\u043c.. \u041f\u0430\u0430\u0430\u0430\u043f"}]
execute if score act_part hey_neighbor matches 6 as @p[team=newcomer, x=-13, y=65, z=5, distance=..3] run function hey_neighbor:act/2/dialog_2
execute if score act_part hey_neighbor matches 7 if score dialog hey_neighbor matches 320..359 run tp @p[team=newcomer] -13.5 65 4.5 -98 2
execute if score act_part hey_neighbor matches 7 if score dialog hey_neighbor matches 320..359 run setblock 23 62 -4 minecraft:iron_door[facing=east, open=true, half=lower]
execute if score act_part hey_neighbor matches 7 if score dialog hey_neighbor matches 320..359 run setblock 23 63 -4 minecraft:iron_door[facing=east, open=true, half=upper]
execute if score act_part hey_neighbor matches 7 if score dialog hey_neighbor matches 320..359 run setblock 23 62 -3 minecraft:iron_door[facing=east, half=lower,hinge=right,open=true]
execute if score act_part hey_neighbor matches 7 if score dialog hey_neighbor matches 320..359 run setblock 23 63 -3 minecraft:iron_door[facing=east, half=upper,hinge=right,open=true]
execute if score act_part hey_neighbor matches 7 if score dialog hey_neighbor matches 280..319 run tp @p[team=newcomer] -6.5 65 3.5 -98 2
execute if score act_part hey_neighbor matches 7 if score dialog hey_neighbor matches 240..279 run tp @p[team=newcomer] 4.2 65 2.2 -98 2
execute if score act_part hey_neighbor matches 7 if score dialog hey_neighbor matches 200..239 run tp @p[team=newcomer] 10.7 65 1.1 -98 2
execute if score act_part hey_neighbor matches 7 if score dialog hey_neighbor matches 160..199 run tp @p[team=newcomer] 15.5 65 0.5 -98 2
execute if score act_part hey_neighbor matches 7 if score dialog hey_neighbor matches 40..159 run tp @p[team=newcomer] 21.5 63.8 -2.5 -153 42
execute if score act_part hey_neighbor matches 7 if score dialog hey_neighbor matches 80..119 run setblock 23 62 -4 minecraft:iron_door[facing=east, open=true, half=lower]
execute if score act_part hey_neighbor matches 7 if score dialog hey_neighbor matches 80..119 run setblock 23 63 -4 minecraft:iron_door[facing=east, open=true, half=upper]
execute if score act_part hey_neighbor matches 7 if score dialog hey_neighbor matches 80..119 run setblock 23 62 -3 minecraft:iron_door[facing=east, half=lower,hinge=right,open=true]
execute if score act_part hey_neighbor matches 7 if score dialog hey_neighbor matches 80..119 run setblock 23 63 -3 minecraft:iron_door[facing=east, half=upper,hinge=right,open=true]
execute if score act_part hey_neighbor matches 7 if score dialog hey_neighbor matches 40..79 run effect give @a blindness 3 0 true
execute if score act_part hey_neighbor matches 7 if score dialog hey_neighbor matches 0..39 run tp @p[team=newcomer] -13.5 65 4.4
execute if score act_part hey_neighbor matches 7 if score dialog hey_neighbor matches 1..359 run tp @p[team=neighbor] 22.5 62 -3.5 -88 13
execute if score act_part hey_neighbor matches 7 if score dialog hey_neighbor matches 1..359 run tp @e[tag=dad, limit=1] 23.9 61.5 -2.5 100 0
execute if score act_part hey_neighbor matches 7 if score dialog hey_neighbor matches 1..359 run tp @e[tag=mom, limit=1] 23.9 61.5 -3.5 40 0
execute if score act_part hey_neighbor matches 7 if score dialog hey_neighbor matches 0 run tp @e[tag=dad, limit=1] 0 0 0 100 0
execute if score act_part hey_neighbor matches 7 if score dialog hey_neighbor matches 0 run tp @e[tag=mom, limit=1] 0 0 0 40 0
execute if score act_part hey_neighbor matches 7 if score dialog hey_neighbor matches 0 run setblock 23 62 -4 minecraft:iron_door[facing=east, open=false, half=lower]
execute if score act_part hey_neighbor matches 7 if score dialog hey_neighbor matches 0 run setblock 23 63 -4 minecraft:iron_door[facing=east, open=false, half=upper]
execute if score act_part hey_neighbor matches 7 if score dialog hey_neighbor matches 0 run setblock 23 62 -3 minecraft:iron_door[facing=east, half=lower,hinge=right,open=false]
execute if score act_part hey_neighbor matches 7 if score dialog hey_neighbor matches 0 run setblock 23 63 -3 minecraft:iron_door[facing=east, half=upper,hinge=right,open=false]
execute if score act_part hey_neighbor matches 7 if score dialog hey_neighbor matches 0 run fill -15 65 -1 -15 66 -1 air
execute if score act_part hey_neighbor matches 7 if score dialog hey_neighbor matches 0 run fill 22 63 -4 22 63 -3 minecraft:nether_brick_wall[north=true,south=true,up=false]
execute if score act_part hey_neighbor matches 7 if score dialog hey_neighbor matches 0 run tp @p[team=neighbor] 19 66 -1
execute if score act_part hey_neighbor matches 7 if score dialog hey_neighbor matches 0 run summon area_effect_cloud 23.5 62 -3.5 {Duration:19999999, Tags:["door", "east"]}
execute if score act_part hey_neighbor matches 7 if score dialog hey_neighbor matches 0 run summon minecraft:villager 23.2 61.2 -3.5 {Tags:["keyhole", "black"], Invulnerable:1, Rotation:[90.0f, 0.0f], NoAI:1, Silent:1, NoGravity:1, ActiveEffects:[{Id:14, Duration:19999999, ShowParticles:0b}], ArmorItems:[{},{},{},{id:"minecraft:player_head",Count:1b,tag:{SkullOwner:{Id:"18a9931f-8983-424a-85b8-26895d3d4a8d",Properties:{textures:[{Value:"eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvM2Q4NzZmODJkNTNjNmIxM2Q4OGViMjFiZTMyMTE5ZjFhYWI2MzFkZGY2ZjZhZTlkNmJjMzc0MmVkMWRlYSJ9fX0="}]}}}}]}

execute if score act_part hey_neighbor matches 7 if score dialog hey_neighbor matches 0 run tellraw @a[team=newcomer] ["",{"text":">> ","color":"gray"},{"text":"\u041a\u0430\u043a \u0438\u0433\u0440\u0430\u0442\u044c \u0437\u0430 \u043f\u0440\u0438\u0435\u0437\u0436\u0435\u0433\u043e","color":"yellow"},{"text":" <<","color":"gray"},{"text":"\n"},{"text":"\u0421\u043e\u0431\u0438\u0440\u0430\u0439 \u043a\u043e\u0440\u043e\u0431\u043a\u0438 \u0438 \u043b\u043e\u043c\u0430\u0439 \u0438\u043c\u0438 \u043e\u043a\u043d\u0430, \u043d\u0443 \u0438\u043b\u0438 \u0441\u0442\u0440\u043e\u0439\u0441\u044f \u043d\u0430 \u0432\u0435\u0440\u0445! \u041d\u0430\u0445\u043e\u0434\u0438 \u043a\u043e\u043c\u043d\u0430\u0442\u044b \u0438 \u043f\u0440\u0435\u0434\u043c\u0435\u0442\u044b, \u043e\u0442\u043a\u0440\u043e\u0439 \u043f\u043e\u0434\u0432\u0430\u043b \u0438 \u0441\u043f\u0430\u0441\u0438 \u0441\u0432\u043e\u0438\u0445 \u0440\u043e\u0434\u0438\u0442\u0435\u043b\u0435\u0439 \u0438\u0437 \u043f\u043e\u0434\u0432\u0430\u043b\u0430!","color":"gray"},{"text":"\n\n"},{"text":"\u041f\u0440\u044f\u0447\u044c\u0441\u044f \u0432 \u0431\u0435\u043b\u044b\u0445 \u0448\u043a\u0430\u0444\u0430\u0445!","color":"yellow"}]
execute if score act_part hey_neighbor matches 7 if score dialog hey_neighbor matches 0 run tellraw @a[team=neighbor] ["",{"text":">> ","color":"gray"},{"text":"\u041a\u0430\u043a \u0438\u0433\u0440\u0430\u0442\u044c \u0437\u0430 \u0441\u043e\u0441\u0435\u0434\u0430","color":"yellow"},{"text":" <<","color":"gray"},{"text":"\n"},{"text":"\u0414\u043e\u0433\u043e\u043d\u044f\u0439 \u0441\u043e\u0441\u0435\u0434\u0430, \u043d\u0435 \u0434\u0430\u0439 \u0435\u043c\u0443 \u043e\u0442\u043a\u0440\u044b\u0442\u044c \u043f\u043e\u0434\u0432\u0430\u043b! \u041d\u0435 \u043f\u043e\u0434\u0431\u0438\u0440\u0430\u0439 \u043f\u0440\u0435\u0434\u043c\u0435\u0442\u044b \u0438\u0433\u0440\u043e\u043a\u0430, \u0438 \u0442\u044b \u043d\u0435 \u043c\u043e\u0436\u0435\u0448\u044c \u0431\u0438\u0442\u044c \u0438\u0433\u0440\u043e\u043a\u0430 \u043a\u043e\u0433\u0434\u0430 \u043e\u043d \u0432 \u0448\u043a\u0430\u0444\u0443, \u0442\u043e\u043b\u044c\u043a\u043e \u0435\u0441\u043b\u0438 \u0442\u044b \u0432\u0438\u0434\u0435\u043b \u043a\u0430\u043a \u043e\u043d \u0442\u0443\u0434\u0430 \u0437\u0430\u0431\u0435\u0436\u0430\u043b","color":"gray"}]
execute if score act_part hey_neighbor matches 7 if score dialog hey_neighbor matches 0 run scoreboard players set dialog hey_neighbor -1

execute if score act hey_neighbor matches 3 as @a[team=newcomer, x=-2225, y=65, z=-2, distance=..1] run function hey_neighbor:act/3/end



execute if score act hey_neighbor matches 3 if score dialog hey_neighbor matches 239 run tellraw @a ["",{"text":"\u0422\u044b >","color":"gray"},{"text":" \u041c\u0430\u0430\u0430\u043c... \u041f\u0430\u0430\u0430\u043f.. \u0433\u0434\u0435 \u0432\u044b?!"}]
execute if score act hey_neighbor matches 3 if score dialog hey_neighbor matches 239 run effect give @a slowness 12 128 true
execute if score act hey_neighbor matches 3 if score dialog hey_neighbor matches 239 run effect give @a jump_boost 12 128 true
execute if score act hey_neighbor matches 3 if score dialog hey_neighbor matches 239 run playsound minecraft:sfx.attack_theme_stay master @a 0 228 0 228 1 1
execute if score act hey_neighbor matches 3 if score dialog hey_neighbor matches 10 run function hey_neighbor:act/3/next

execute if score act hey_neighbor matches 4 if score dialog hey_neighbor matches 1199 run tellraw @a ["",{"text":"\u041f\u0430\u043f\u0430","color":"yellow"},{"text":" >","color":"gray"},{"text":" \u0421\u044b\u043d, \u0447\u0442\u043e \u0442\u044b \u0434\u0435\u043b\u0430\u0435\u0448\u044c?"}]
execute if score act hey_neighbor matches 4 if score dialog hey_neighbor matches 1080 run tellraw @a ["",{"text":"\u0422\u044b","color":"gray"},{"text":" >","color":"gray"},{"text":" \u042d\u043c\u043c... \u0427\u0442\u043e? \u042f \u0425\u041e\u0427\u0423 \u0421\u041f\u0410\u0421\u0422\u0418 \u0412\u0410\u0421!","color":"gray"}]
execute if score act hey_neighbor matches 4 if score dialog hey_neighbor matches 960 run tellraw @a ["",{"text":"\u041c\u0430\u043c\u0430","color":"yellow"},{"text":" >","color":"gray"},{"text":" \u041d\u0435 \u043d\u0443\u0436\u043d\u043e \u043d\u0430\u0441 \u0441\u043f\u0430\u0441\u0430\u0442\u044c"}]
execute if score act hey_neighbor matches 4 if score dialog hey_neighbor matches 840 run tellraw @a ["",{"text":"\u0422\u044b","color":"gray"},{"text":" >","color":"gray"},{"text":" \u041d\u043e \u043c\u043d\u0435 \u0432\u0430\u0441 \u043d\u0435\u0445\u0432\u0430\u0442\u0430\u0435\u0442! \u0418... \u0447\u0442\u043e \u044d\u0442\u043e \u0437\u0430 \u043c\u0435\u0441\u0442\u043e?!","color":"gray"}]
execute if score act hey_neighbor matches 4 if score dialog hey_neighbor matches 720 run tellraw @a ["",{"text":"\u041f\u0430\u043f\u0430","color":"yellow"},{"text":" >","color":"gray"},{"text":" \u042d\u0442\u043e твоя \u0433\u043e\u043b\u043e\u0432\u0430, \u0442\u044b \u0441\u043e\u0432\u0441\u0435\u043c \u043f\u043e\u0435\u0445\u0430\u043b, \u0438 \u043c\u044b \u0445\u043e\u0442\u0435\u043b\u0438 \u0432\u0437\u044f\u0442\u044c \u0441\u0430\u043c\u043e\u0435 \u043b\u0443\u0447\u0448\u0435\u0435 \u0442\u0432\u043e\u0435 \u0432\u043e\u0441\u043f\u043e\u043c\u0438\u043d\u0430\u043d\u0438\u0435, \u0447\u0442\u043e\u0431\u044b \u0442\u0435\u0431\u0435 \u0431\u044b\u043b\u043e \u043f\u0440\u0438\u044f\u0442\u043d\u043e \u043d\u0430\u0445\u043e\u0434\u0438\u0442\u0441\u044f \u0437\u0434\u0435\u0441\u044c, \u043d\u043e \u0442\u0432\u043e\u0435 \u0441\u0430\u043c\u043e\u0435 \u043b\u0443\u0447\u0448\u0435\u0435 \u0432\u043e\u0441\u043f\u043e\u043c\u0438\u043d\u0430\u043d\u0438\u0435..."}]
execute if score act hey_neighbor matches 4 if score dialog hey_neighbor matches 600 run tellraw @a ["",{"text":"\u041c\u0430\u043c\u0430","color":"yellow"},{"text":" >","color":"gray"},{"text":" \u042d\u0442\u043e \u043c\u044b, \u0438 \u043f\u043e \u044d\u0442\u043e\u043c\u0443 \u043c\u044b \u0440\u0435\u0448\u0438\u043b\u0438 \u043f\u0440\u0438\u0439\u0442\u0438 \u043a \u0442\u0435\u0431\u0435"}]
execute if score act hey_neighbor matches 4 if score dialog hey_neighbor matches 480 run tellraw @a ["",{"text":"\u0422\u044b >","color":"gray"},{"text":" \u0412\u0435\u0440\u043d\u0438\u0442\u0435\u0441\u044c, \u044f \u0445\u043e\u0447\u0443 \u0447\u0442\u043e\u0431\u044b \u0432\u044b \u0431\u044b\u043b\u0438 \u0440\u044f\u0434\u043e\u043c!","color":"gray"}]
execute if score act hey_neighbor matches 4 if score dialog hey_neighbor matches 360 run tellraw @a ["",{"text":"\u041f\u0430\u043f\u0430","color":"yellow"},{"text":" >","color":"gray"},{"text":" \u041c\u044b \u043f\u043e\u0433\u0438\u0431\u043b\u0438 \u0432 \u0430\u0432\u0430\u0440\u0438\u0438, \u0438 \u0435\u0434\u0438\u043d\u0441\u0442\u0432\u0435\u043d\u043d\u044b\u0439 \u0442\u0432\u043e\u0439 \u043b\u0443\u0447\u0448\u0438\u0439 \u0434\u0440\u0443\u0433 \u044d\u0442\u043e \u0441\u043e\u0441\u0435\u0434, \u043e\u043d \u043e \u0442\u0435\u0431\u0435 \u043f\u043e\u0437\u0430\u0431\u043e\u0442\u0438\u0442\u0441\u044f, \u043e\u043d \u0445\u043e\u0440\u043e\u0448\u0438\u0439 \u0447\u0435\u043b\u043e\u0432\u0435\u043a, \u0438 \u0438\u0434\u0438 \u043a \u043d\u0435\u043c\u0443. \u041e\u043d \u0441\u0430\u043c\u044b\u0439 \u043b\u0443\u0447\u0448\u0438\u0439 \u0434\u0440\u0443\u0433 \u043d\u0430\u0448\u0435\u0439 \u0441\u0435\u043c\u044c\u0438, \u043e\u043d \u0431\u044b\u043b \u0441 \u043d\u0430\u043c\u0438 13 \u043b\u0435\u0442, \u0438 \u0443\u0436\u0435 \u0441\u0442\u0430\u043b \u0434\u043b\u044f \u043d\u0430\u0441 \u0440\u043e\u0434\u043d\u044b\u043c \u0438 \u0434\u043e\u0432\u0435\u0440\u0435\u043d\u043d\u044b\u043c \u0447\u0435\u043b\u043e\u0432\u0435\u043a\u043e\u043c"}]
execute if score act hey_neighbor matches 4 if score dialog hey_neighbor matches 240 run tellraw @a ["",{"text":"\u041c\u0430\u043c\u0430 ","color":"yellow"},{"text":">","color":"gray"},{"text":" \u0414\u0430, \u044d\u0442\u043e \u0442\u0430\u043a, \u043d\u043e \u043d\u0435\u043b\u044c\u0437\u044f \u043f\u0440\u044f\u0442\u0430\u0442\u044c\u0441\u044f \u043e\u0442 \u043f\u0440\u043e\u0431\u043b\u0435\u043c, \u043f\u0440\u043e\u0431\u043b\u0435\u043c\u044b \u043d\u0443\u0436\u043d\u043e \u0440\u0435\u0448\u0430\u0442\u044c, \u0438 \u043f\u043e \u044d\u0442\u043e\u043c\u0443\n"},{"text":"\u041f\u0430\u043f\u0430 \u0438 \u041c\u0430\u043c\u0430 ","color":"yellow"},{"text":">","color":"gray"},{"text":" \u041f\u0420\u041e\u0421\u041d\u0418\u0421\u042c!"}]
execute if score act hey_neighbor matches 4 if score dialog hey_neighbor matches 120 run tellraw @a ["",{"text":"\u041f\u0430\u043f\u0430 \u0438 \u041c\u0430\u043c\u0430 ","color":"yellow"},{"text":">","color":"gray"},{"text":" \u041f\u0420\u041e\u0421\u041d\u0418\u0421\u042c!"}]
execute if score act hey_neighbor matches 4 if score dialog hey_neighbor matches 100 run execute as @p[team=newcomer] run function hey_neighbor:catch
execute if score act hey_neighbor matches 4 if score dialog hey_neighbor matches 2 run playsound minecraft:sfx.clap master @a 2228 228 0 228 1 1
execute if score act hey_neighbor matches 4 if score dialog hey_neighbor matches 2 run setblock 2217 65 0 minecraft:birch_door[open=false,facing=east]
execute if score act hey_neighbor matches 4 if score dialog hey_neighbor matches ..2 run tp @a[team=neighbor] 2223.5 64 0.5 90 0
execute if score act hey_neighbor matches 4 if score dialog hey_neighbor matches ..2 if block 2217 65 0 minecraft:birch_door[open=true] run function hey_neighbor:lobby
