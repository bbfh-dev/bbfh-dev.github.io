scoreboard players set iron_door2_old hey_neighbor 0
fill 21 70 0 21 72 2 iron_bars[south=true, north=true]
playsound minecraft:sfx.dummy_catch_3 master @a 21 71 1 10 1 0
