scoreboard players set act_part hey_neighbor 5
scoreboard players set act hey_neighbor 2

tp @p[team=newcomer] -16.5 70 -1.5 0 0
time set 18000
execute as @p[team=newcomer] run function hey_neighbor:catch
title @a subtitle [{"text":">> ", "color":"yellow", "bold":false}, {"text":"Жизнь после трагедии", "color":"gray", "bold":false}, {"text":" <<", "color":"yellow", "bold":false}]
title @a title {"text":"АКТ 2", "color":"yellow", "bold":true}
execute as @a[team=neighbor] at @s run tp @s 0 100000 0
stopsound @a
playsound minecraft:sfx.voice_ohhh master @a 0 228 0 228 1 0
fill -15 65 -1 -15 66 -1 minecraft:barrier
