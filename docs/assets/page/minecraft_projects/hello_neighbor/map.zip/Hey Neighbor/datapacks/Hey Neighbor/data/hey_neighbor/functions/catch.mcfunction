#---/ Поймать Игрока /---#
playsound minecraft:sfx.catch master @a 0 228 0 228 1 1
effect give @s blindness 5 0 true
effect give @s slowness 3 128 true
effect give @s jump_boost 3 128 true

#---/ АКТ 1 /---#
execute if score act hey_neighbor matches 1 run tp @p[team=neighbor] 2219.5 65 0.5 -90 0

#---/ АКТ 2 /---#
execute if score act hey_neighbor matches 2 run tp @p[team=newcomer] -22.5 65 -6.5

#---/ АКТ 3 /---#
execute if score act hey_neighbor matches 3 run tp @p[team=newcomer] -2211 65 12
execute if score act hey_neighbor matches 3 run tp @p[team=neighbor] -2222 65 34

execute if score act hey_neighbor matches 4 run tp @p[team=newcomer] 2208.5 65 -5.5
execute if score act hey_neighbor matches 4 run tp @p[team=neighbor] -2222 65 34
