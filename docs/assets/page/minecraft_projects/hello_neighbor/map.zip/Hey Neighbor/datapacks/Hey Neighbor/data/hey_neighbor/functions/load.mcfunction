#--/ Скорборды /--#
scoreboard objectives add game_keyhole minecraft.custom:minecraft.talked_to_villager
scoreboard objectives add hey_neighbor dummy

#--/ Команды /--#
team add newcomer
team add neighbor
